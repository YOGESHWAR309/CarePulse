package com.carepulse.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * CarePulse - Eureka Discovery Server
 * <p>
 * This service acts as the Service Registry for all CarePulse microservices
 * (API Gateway, Auth Service, Hospital Service, Notification Service).
 * Every microservice registers itself here on startup, and the API Gateway
 * uses this registry to dynamically discover and route requests to healthy
 * service instances.
 * <p>
 * Runs on port 8761 by default.
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    /**
     * Entry point. Starts the embedded Eureka registry server so that
     * downstream microservices (Gateway, Auth, Hospital, Notification)
     * have a registry to register with and discover each other through.
     */
    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}
