package com.carepulse.auth.controller;

import com.carepulse.auth.dto.request.CreateStaffRequest;
import com.carepulse.auth.dto.response.ApiResponse;
import com.carepulse.auth.dto.response.UserSummaryResponse;
import com.carepulse.auth.service.AdminUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Admin-exclusive user management. Locked down twice over: coarsely by
 * {@link com.carepulse.auth.config.SecurityConfig} ("/api/auth/admin/**"
 * requires ROLE_ADMIN), and again per-method here via {@code @PreAuthorize}
 * for defense-in-depth and clearer self-documentation.
 */
@RestController
@RequestMapping("/api/auth/admin")
@RequiredArgsConstructor
@Tag(name = "Admin - User Management", description = "Admin-only staff creation and account lifecycle management")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final AdminUserService adminUserService;

    /** Creates a Doctor/Receptionist/Pharmacist/Pathologist/Radiologist/Dietician/Nutritionist account. Temp password is emailed, never returned here. */
    @Operation(summary = "Create a staff account (Doctor, Receptionist, Pharmacist, etc.)")
    @PostMapping("/staff")
    public ResponseEntity<ApiResponse<UserSummaryResponse>> createStaff(@Valid @RequestBody CreateStaffRequest request) {
        UserSummaryResponse response = adminUserService.createStaff(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Staff account created. Login credentials have been emailed.", response));
    }

    /** Reactivates a deactivated doctor/staff account. */
    @Operation(summary = "Activate a doctor/staff account")
    @PatchMapping("/users/{userId}/activate")
    public ResponseEntity<ApiResponse<UserSummaryResponse>> activateUser(@PathVariable Long userId) {
        UserSummaryResponse response = adminUserService.activateUser(userId);
        return ResponseEntity.ok(ApiResponse.success("Account activated successfully", response));
    }

    /** Deactivates a doctor/staff account, blocking further login. */
    @Operation(summary = "Deactivate a doctor/staff account")
    @PatchMapping("/users/{userId}/deactivate")
    public ResponseEntity<ApiResponse<UserSummaryResponse>> deactivateUser(@PathVariable Long userId) {
        UserSummaryResponse response = adminUserService.deactivateUser(userId);
        return ResponseEntity.ok(ApiResponse.success("Account deactivated successfully", response));
    }

    /** Issues a new temporary password to a locked-out staff member and emails it to them. */
    @Operation(summary = "Reset a staff member's password")
    @PostMapping("/users/{userId}/reset-password")
    public ResponseEntity<ApiResponse<Void>> resetStaffPassword(@PathVariable Long userId) {
        adminUserService.resetStaffPassword(userId);
        return ResponseEntity.ok(ApiResponse.success("Temporary password generated and emailed to the user"));
    }

    /** Lists every patient in the system. */
    @Operation(summary = "View all patients")
    @GetMapping("/patients")
    public ResponseEntity<ApiResponse<List<UserSummaryResponse>>> getAllPatients() {
        return ResponseEntity.ok(ApiResponse.success("Patients fetched successfully", adminUserService.getAllPatients()));
    }

    /** Lists every doctor in the system. */
    @Operation(summary = "View all doctors")
    @GetMapping("/doctors")
    public ResponseEntity<ApiResponse<List<UserSummaryResponse>>> getAllDoctors() {
        return ResponseEntity.ok(ApiResponse.success("Doctors fetched successfully", adminUserService.getAllDoctors()));
    }

    /** Lists every non-patient, non-doctor staff member (receptionists, pharmacists, pathologists, radiologists, dieticians, nutritionists). */
    @Operation(summary = "View all staff")
    @GetMapping("/staff")
    public ResponseEntity<ApiResponse<List<UserSummaryResponse>>> getAllStaff() {
        return ResponseEntity.ok(ApiResponse.success("Staff fetched successfully", adminUserService.getAllStaff()));
    }

    /** Fetches a single user's summary by id - useful for Admin detail views. */
    @Operation(summary = "Get a single user by id")
    @GetMapping("/users/{userId}")
    public ResponseEntity<ApiResponse<UserSummaryResponse>> getUserById(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("User fetched successfully", adminUserService.getUserById(userId)));
    }
}
