package com.carepulse.auth.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Published to RabbitMQ (routing key {@code notification.email}) for
 * generic transactional emails that aren't OTP-based - e.g. "your staff
 * account was created", "password changed successfully".
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SendEmailEvent implements Serializable {
    private String recipientEmail;
    private String recipientName;
    private String subject;
    private String body;
}
