package com.carepulse.auth.controller;

import com.carepulse.auth.dto.response.ApiResponse;
import com.carepulse.auth.dto.response.UserSummaryResponse;
import com.carepulse.auth.service.AdminUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * NOT for the frontend. Called only by other microservices (primarily
 * Hospital Service via OpenFeign) that need to validate a userId exists,
 * fetch its basic identity, or confirm its role - e.g. before letting a
 * doctorId be attached to a new Appointment. Protected not by a user JWT
 * but by {@link com.carepulse.auth.config.InternalApiKeyFilter}, since the
 * caller here is a service, not an end user.
 */
@RestController
@RequestMapping("/api/auth/internal")
@RequiredArgsConstructor
@Tag(name = "Internal - Service to Service", description = "Feign-only endpoints for inter-service user validation")
public class InternalUserController {

    private final AdminUserService adminUserService;

    /** Validates a userId exists and returns its identity/role - used by Hospital Service before attaching a userId to clinical data. */
    @Operation(summary = "[Internal] Fetch basic user info by id")
    @GetMapping("/users/{userId}")
    public ResponseEntity<ApiResponse<UserSummaryResponse>> getUserById(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("User fetched successfully", adminUserService.getUserById(userId)));
    }
}
