package com.carepulse.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * CarePulse - Auth Service
 * <p>
 * Owns identity for every role in the system: patient self-registration,
 * login for all roles, JWT issuance/refresh, OTP-based email verification,
 * forgot/reset/change password, profile management, and Admin-only staff
 * account creation. Backed by its own {@code auth_db} MySQL database -
 * no other service is allowed to read/write this schema directly.
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class AuthServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthServiceApplication.class, args);
    }
}
