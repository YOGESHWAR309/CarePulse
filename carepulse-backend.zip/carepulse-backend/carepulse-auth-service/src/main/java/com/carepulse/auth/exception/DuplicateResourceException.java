package com.carepulse.auth.exception;

/** Thrown when trying to create a record that would violate a uniqueness rule (e.g. email already registered) - mapped to HTTP 409. */
public class DuplicateResourceException extends RuntimeException {
    public DuplicateResourceException(String message) {
        super(message);
    }
}
