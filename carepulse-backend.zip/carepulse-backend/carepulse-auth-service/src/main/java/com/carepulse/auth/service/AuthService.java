package com.carepulse.auth.service;

import com.carepulse.auth.dto.request.*;
import com.carepulse.auth.dto.response.AuthResponse;
import com.carepulse.auth.dto.response.UserProfileResponse;

/**
 * Core authentication use cases available to EVERY role - registration
 * (patients only), login, token refresh, and the full forgot/reset/change
 * password lifecycle.
 */
public interface AuthService {

    /** Self-registers a new PATIENT account (disabled until OTP-verified) and triggers a registration OTP email. */
    void registerPatient(PatientRegisterRequest request);

    /** Authenticates email/password, and if valid, issues a fresh access + refresh token pair. */
    AuthResponse login(LoginRequest request);

    /** Validates a refresh token and, if still valid/unrevoked, issues a brand new access token. */
    AuthResponse refreshToken(RefreshTokenRequest request);

    /** Sends a password-reset OTP to the given email, if an account exists (always responds the same either way to avoid email enumeration). */
    void forgotPassword(ForgotPasswordRequest request);

    /** Verifies a submitted OTP for either REGISTRATION (activates the account) or PASSWORD_RESET (unlocks reset-password). */
    void verifyOtp(VerifyOtpRequest request);

    /** Re-sends a fresh OTP for a given email/purpose, invalidating the ability to use the previous code. */
    void resendOtp(ForgotPasswordRequest request, com.carepulse.auth.enums.OtpPurpose purpose);

    /** Final step of forgot-password: sets a new password, but only if the OTP for this email was already verified. */
    void resetPassword(ResetPasswordRequest request);

    /** Lets an already-authenticated user change their own password by proving they know the current one. */
    void changePassword(Long userId, ChangePasswordRequest request);

    /** Returns the logged-in user's own profile. */
    UserProfileResponse getProfile(Long userId);

    /** Updates the logged-in user's own basic profile fields (name, phone). */
    UserProfileResponse updateProfile(Long userId, UpdateProfileRequest request);
}
