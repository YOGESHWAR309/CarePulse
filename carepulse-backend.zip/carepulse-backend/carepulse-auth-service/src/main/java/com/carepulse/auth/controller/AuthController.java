package com.carepulse.auth.controller;

import com.carepulse.auth.dto.request.*;
import com.carepulse.auth.dto.response.ApiResponse;
import com.carepulse.auth.dto.response.AuthResponse;
import com.carepulse.auth.enums.OtpPurpose;
import com.carepulse.auth.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Public authentication endpoints - registration, login, refresh, and the
 * full forgot/verify/reset password lifecycle. Everything here is on the
 * open (no-JWT-required) allowlist in {@link com.carepulse.auth.config.SecurityConfig}.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Registration, login, token refresh, OTP and password management")
public class AuthController {

    private final AuthService authService;

    /** Patient self-registration. Account stays disabled until OTP verification completes. */
    @Operation(summary = "Register a new patient account")
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Void>> register(@Valid @RequestBody PatientRegisterRequest request) {
        authService.registerPatient(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Registration successful. Please check your email for an OTP to verify your account."));
    }

    /** Authenticates any role (Admin, Patient, Doctor, or staff) and issues JWT access + refresh tokens. */
    @Operation(summary = "Log in and receive an access token + refresh token")
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest request) {
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(ApiResponse.success("Login successful", response));
    }

    /** Exchanges a still-valid refresh token for a brand-new access token, without re-entering credentials. */
    @Operation(summary = "Refresh an expired access token")
    @PostMapping("/refresh-token")
    public ResponseEntity<ApiResponse<AuthResponse>> refreshToken(@Valid @RequestBody RefreshTokenRequest request) {
        AuthResponse response = authService.refreshToken(request);
        return ResponseEntity.ok(ApiResponse.success("Token refreshed successfully", response));
    }

    /** Kicks off the forgot-password flow by emailing a one-time OTP code. */
    @Operation(summary = "Request a password-reset OTP")
    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<Void>> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        authService.forgotPassword(request);
        return ResponseEntity.ok(ApiResponse.success("If an account exists with this email, a password reset OTP has been sent."));
    }

    /** Verifies an OTP for either REGISTRATION (activates the account) or PASSWORD_RESET (unlocks reset-password). */
    @Operation(summary = "Verify an OTP code")
    @PostMapping("/verify-otp")
    public ResponseEntity<ApiResponse<Void>> verifyOtp(@Valid @RequestBody VerifyOtpRequest request) {
        authService.verifyOtp(request);
        return ResponseEntity.ok(ApiResponse.success("OTP verified successfully"));
    }

    /** Re-sends a fresh OTP for registration verification, superseding any previously issued code. */
    @Operation(summary = "Resend a registration-verification OTP")
    @PostMapping("/resend-otp")
    public ResponseEntity<ApiResponse<Void>> resendRegistrationOtp(@Valid @RequestBody ForgotPasswordRequest request) {
        authService.resendOtp(request, OtpPurpose.REGISTRATION);
        return ResponseEntity.ok(ApiResponse.success("A new OTP has been sent to your email."));
    }

    /** Final step of forgot-password - only succeeds if the email's PASSWORD_RESET OTP was already verified. */
    @Operation(summary = "Reset password after OTP verification")
    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<Void>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        authService.resetPassword(request);
        return ResponseEntity.ok(ApiResponse.success("Password reset successfully. Please log in with your new password."));
    }
}
