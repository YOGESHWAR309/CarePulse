package com.carepulse.auth.messaging.event;

import com.carepulse.auth.enums.OtpPurpose;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Published to RabbitMQ (routing key {@code notification.otp}) whenever a
 * fresh OTP is generated. Notification Service consumes this and sends the
 * actual OTP email - Auth Service never sends email itself.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SendOtpEvent implements Serializable {
    private String recipientEmail;
    private String recipientName;
    private String otpCode;
    private OtpPurpose purpose;
    private int validityMinutes;
}
