package com.carepulse.auth.controller;

import com.carepulse.auth.dto.request.ChangePasswordRequest;
import com.carepulse.auth.dto.request.UpdateProfileRequest;
import com.carepulse.auth.dto.response.ApiResponse;
import com.carepulse.auth.dto.response.UserProfileResponse;
import com.carepulse.auth.security.UserPrincipal;
import com.carepulse.auth.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * Self-service endpoints available to ANY logged-in user regardless of
 * role - view/update their own profile, change their own password. The
 * acting user's id always comes from the validated JWT
 * ({@link UserPrincipal}), never from a request parameter, so nobody can
 * view or edit someone else's profile by guessing an id.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Profile", description = "Self-service profile and password management for the logged-in user")
@SecurityRequirement(name = "bearerAuth")
public class ProfileController {

    private final AuthService authService;

    /** Returns the calling user's own profile. */
    @Operation(summary = "Get my profile")
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<UserProfileResponse>> getProfile(@AuthenticationPrincipal UserPrincipal principal) {
        UserProfileResponse response = authService.getProfile(principal.getId());
        return ResponseEntity.ok(ApiResponse.success("Profile fetched successfully", response));
    }

    /** Updates the calling user's own name/phone (email and role are not editable here). */
    @Operation(summary = "Update my profile")
    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<UserProfileResponse>> updateProfile(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody UpdateProfileRequest request) {
        UserProfileResponse response = authService.updateProfile(principal.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Profile updated successfully", response));
    }

    /**
     * Changes the calling user's own password. Used both for a normal
     * voluntary password change and for the mandatory first-login password
     * change flow for staff/doctors created by Admin.
     */
    @Operation(summary = "Change my password")
    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<Void>> changePassword(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody ChangePasswordRequest request) {
        authService.changePassword(principal.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully"));
    }
}
