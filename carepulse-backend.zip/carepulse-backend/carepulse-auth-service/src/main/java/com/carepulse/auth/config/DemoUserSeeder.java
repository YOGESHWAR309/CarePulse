package com.carepulse.auth.config;

import com.carepulse.auth.entity.User;
import com.carepulse.auth.enums.UserRole;
import com.carepulse.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Runs once on every application startup (right after {@link AdminSeeder})
 * and guarantees one ready-to-use, already-verified account exists for
 * EVERY role in the system, so the whole app (every dashboard) can be
 * logged into immediately in local/dev environments without going through
 * Admin's "create staff" flow by hand.
 * <p>
 * Idempotent - skips any email that already exists. Controlled by
 * {@code demo.seed-users.enabled} so it can be turned off in production
 * (see application.properties). Every seeded account uses the SAME
 * password, {@code demo.seed-users.password}, purely for convenience in
 * local testing - change it in application.properties, or better, delete
 * these accounts before deploying anywhere real.
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Order(2)
public class DemoUserSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${demo.seed-users.enabled:true}")
    private boolean enabled;

    @Value("${demo.seed-users.password:CarePulse@123}")
    private String defaultPassword;

    private record DemoUser(String firstName, String lastName, String email, UserRole role) {}

    private static final List<DemoUser> DEMO_USERS = List.of(
            new DemoUser("Priya", "Patient", "patient@carepulse.com", UserRole.PATIENT),
            new DemoUser("Rohan", "Doctor", "doctor@carepulse.com", UserRole.DOCTOR),
            new DemoUser("Anita", "Reception", "receptionist@carepulse.com", UserRole.RECEPTIONIST),
            new DemoUser("Sameer", "Pharmacist", "pharmacist@carepulse.com", UserRole.PHARMACIST),
            new DemoUser("Kavita", "Pathologist", "pathologist@carepulse.com", UserRole.PATHOLOGIST),
            new DemoUser("Arjun", "Radiologist", "radiologist@carepulse.com", UserRole.RADIOLOGIST),
            new DemoUser("Meera", "Dietician", "dietician@carepulse.com", UserRole.DIETICIAN),
            new DemoUser("Vikram", "Nutritionist", "nutritionist@carepulse.com", UserRole.NUTRITIONIST),
            new DemoUser("Sunita", "Canteen", "canteen@carepulse.com", UserRole.CANTEEN_STAFF)
    );

    @Override
    public void run(String... args) {
        if (!enabled) {
            log.info("Demo user seeding disabled (demo.seed-users.enabled=false)");
            return;
        }

        for (DemoUser demo : DEMO_USERS) {
            if (userRepository.existsByEmail(demo.email())) {
                continue;
            }

            User user = User.builder()
                    .firstName(demo.firstName())
                    .lastName(demo.lastName())
                    .email(demo.email())
                    .password(passwordEncoder.encode(defaultPassword))
                    .phoneNumber("9000000000")
                    .role(demo.role())
                    .enabled(true)
                    .accountLocked(false)
                    .firstLogin(false)
                    .build();

            userRepository.save(user);
            log.warn("Demo account seeded: {} / role={} - FOR LOCAL DEV ONLY, remove before production", demo.email(), demo.role());
        }
    }
}
