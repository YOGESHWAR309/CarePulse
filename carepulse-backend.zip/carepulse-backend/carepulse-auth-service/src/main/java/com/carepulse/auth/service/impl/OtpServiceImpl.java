package com.carepulse.auth.service.impl;

import com.carepulse.auth.entity.OtpVerification;
import com.carepulse.auth.enums.OtpPurpose;
import com.carepulse.auth.exception.InvalidOtpException;
import com.carepulse.auth.messaging.NotificationEventPublisher;
import com.carepulse.auth.messaging.event.SendOtpEvent;
import com.carepulse.auth.repository.OtpVerificationRepository;
import com.carepulse.auth.service.OtpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class OtpServiceImpl implements OtpService {

    private static final int OTP_LENGTH = 6;
    private static final int OTP_VALIDITY_MINUTES = 10;
    private static final int MAX_ATTEMPTS = 5;

    private final OtpVerificationRepository otpVerificationRepository;
    private final NotificationEventPublisher notificationEventPublisher;
    private final SecureRandom secureRandom = new SecureRandom();

    /**
     * Generates a cryptographically random 6-digit code (never Math.random,
     * which is predictable), saves it with a 10-minute expiry, and hands off
     * to RabbitMQ so Notification Service can email it.
     */
    @Override
    @Transactional
    public void generateAndSendOtp(String email, String recipientName, OtpPurpose purpose) {
        String otpCode = String.format("%06d", secureRandom.nextInt(1_000_000));

        OtpVerification otp = OtpVerification.builder()
                .email(email)
                .otpCode(otpCode)
                .purpose(purpose)
                .expiryTime(LocalDateTime.now().plusMinutes(OTP_VALIDITY_MINUTES))
                .verified(false)
                .attemptCount(0)
                .build();

        otpVerificationRepository.save(otp);

        notificationEventPublisher.publishOtpEvent(
                SendOtpEvent.builder()
                        .recipientEmail(email)
                        .recipientName(recipientName)
                        .otpCode(otpCode)
                        .purpose(purpose)
                        .validityMinutes(OTP_VALIDITY_MINUTES)
                        .build()
        );

        log.info("OTP generated for {} (purpose={})", email, purpose);
    }

    /**
     * Looks up the latest unverified OTP for this email/purpose, then checks
     * (in order): does one exist, has it expired, has it exceeded the max
     * attempt count, and finally does the submitted code match. Any failed
     * match increments the attempt counter so brute-forcing a 6-digit code
     * gets locked out after {@value #MAX_ATTEMPTS} tries.
     */
    @Override
    @Transactional
    public void verifyOtp(String email, String otpCode, OtpPurpose purpose) {
        OtpVerification otp = otpVerificationRepository
                .findTopByEmailAndPurposeAndVerifiedFalseOrderByCreatedAtDesc(email, purpose)
                .orElseThrow(() -> new InvalidOtpException("No OTP request found for this email. Please request a new OTP."));

        if (otp.getExpiryTime().isBefore(LocalDateTime.now())) {
            throw new InvalidOtpException("OTP has expired. Please request a new one.");
        }

        if (otp.getAttemptCount() >= MAX_ATTEMPTS) {
            throw new InvalidOtpException("Maximum verification attempts exceeded. Please request a new OTP.");
        }

        if (!otp.getOtpCode().equals(otpCode)) {
            otp.setAttemptCount(otp.getAttemptCount() + 1);
            otpVerificationRepository.save(otp);
            throw new InvalidOtpException("Invalid OTP code.");
        }

        otp.setVerified(true);
        otpVerificationRepository.save(otp);
        log.info("OTP verified for {} (purpose={})", email, purpose);
    }

    /** Used by resetPassword to confirm the OTP gate was actually passed before allowing the password change. */
    @Override
    public boolean isOtpVerified(String email, OtpPurpose purpose) {
        return otpVerificationRepository
                .findTopByEmailAndPurposeAndVerifiedTrueOrderByCreatedAtDesc(email, purpose)
                .isPresent();
    }
}
