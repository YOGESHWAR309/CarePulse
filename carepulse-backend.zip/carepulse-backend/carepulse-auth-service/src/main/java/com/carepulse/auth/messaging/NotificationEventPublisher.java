package com.carepulse.auth.messaging;

import com.carepulse.auth.config.RabbitMQConfig;
import com.carepulse.auth.messaging.event.PatientRegisteredEvent;
import com.carepulse.auth.messaging.event.SendEmailEvent;
import com.carepulse.auth.messaging.event.SendOtpEvent;
import com.carepulse.auth.messaging.event.StaffCreatedEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/**
 * Single point through which Auth Service talks to RabbitMQ. Keeps all
 * publishing logic (exchange name, routing keys) out of the service layer,
 * so {@code AuthServiceImpl}/{@code AdminUserServiceImpl} just call a
 * plain Java method and don't need to know about AMQP at all.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class NotificationEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    /** Publishes an OTP so Notification Service can email it (registration verification or password reset). */
    public void publishOtpEvent(SendOtpEvent event) {
        log.info("Publishing SendOtpEvent for {} (purpose={})", event.getRecipientEmail(), event.getPurpose());
        rabbitTemplate.convertAndSend(
                RabbitMQConfig.NOTIFICATION_EXCHANGE, RabbitMQConfig.OTP_ROUTING_KEY, event);
    }

    /** Publishes a generic transactional email (e.g. password-changed confirmation). */
    public void publishEmailEvent(SendEmailEvent event) {
        log.info("Publishing SendEmailEvent for {} (subject={})", event.getRecipientEmail(), event.getSubject());
        rabbitTemplate.convertAndSend(
                RabbitMQConfig.NOTIFICATION_EXCHANGE, RabbitMQConfig.EMAIL_ROUTING_KEY, event);
    }

    /** Publishes the newly created staff member's login credentials for Notification Service to email out. */
    public void publishStaffCreatedEvent(StaffCreatedEvent event) {
        log.info("Publishing StaffCreatedEvent for {} (role={})", event.getRecipientEmail(), event.getRole());
        rabbitTemplate.convertAndSend(
                RabbitMQConfig.NOTIFICATION_EXCHANGE, RabbitMQConfig.STAFF_CREATED_ROUTING_KEY, event);
    }

    /** Publishes patient activation so Hospital Service can auto-provision a clinical Patient profile row. */
    public void publishPatientRegisteredEvent(PatientRegisteredEvent event) {
        log.info("Publishing PatientRegisteredEvent for userId={}", event.getUserId());
        rabbitTemplate.convertAndSend(
                RabbitMQConfig.NOTIFICATION_EXCHANGE, RabbitMQConfig.PATIENT_REGISTERED_ROUTING_KEY, event);
    }
}
