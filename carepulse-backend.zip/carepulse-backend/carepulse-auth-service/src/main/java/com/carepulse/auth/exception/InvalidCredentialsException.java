package com.carepulse.auth.exception;

/** Thrown on login when the email/password pair doesn't match, or the account is disabled/locked - mapped to HTTP 401. */
public class InvalidCredentialsException extends RuntimeException {
    public InvalidCredentialsException(String message) {
        super(message);
    }
}
