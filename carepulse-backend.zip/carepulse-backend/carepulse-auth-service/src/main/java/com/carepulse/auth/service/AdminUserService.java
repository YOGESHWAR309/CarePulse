package com.carepulse.auth.service;

import com.carepulse.auth.dto.request.CreateStaffRequest;
import com.carepulse.auth.dto.response.UserSummaryResponse;
import com.carepulse.auth.enums.UserRole;

import java.util.List;

/**
 * Admin-only user-management operations. Everything here is guarded by
 * {@code hasRole("ADMIN")} at the controller layer - Admin is the only
 * role that can create, deactivate, or reset passwords for other staff.
 */
public interface AdminUserService {

    /** Creates a DOCTOR/RECEPTIONIST/PHARMACIST/PATHOLOGIST/RADIOLOGIST/DIETICIAN/NUTRITIONIST account with a generated temp password. */
    UserSummaryResponse createStaff(CreateStaffRequest request);

    /** Reactivates a previously deactivated staff/doctor account. */
    UserSummaryResponse activateUser(Long userId);

    /** Soft-deactivates a staff/doctor account (login blocked, history preserved). */
    UserSummaryResponse deactivateUser(Long userId);

    /** Generates a new temporary password for a staff member who's locked out, and emails it to them. */
    void resetStaffPassword(Long userId);

    /** Returns every user with role PATIENT - backs Admin's "View All Patients" screen. */
    List<UserSummaryResponse> getAllPatients();

    /** Returns every user with role DOCTOR - backs Admin's "View All Doctors" screen. */
    List<UserSummaryResponse> getAllDoctors();

    /** Returns every non-patient, non-doctor staff member - backs Admin's "View All Staff" screen. */
    List<UserSummaryResponse> getAllStaff();

    /** Fetches a single user's summary by id - used both by Admin screens and the internal Feign validation endpoint. */
    UserSummaryResponse getUserById(Long userId);

    /** Fetches every user of a given role - the general-purpose version behind the three convenience methods above. */
    List<UserSummaryResponse> getUsersByRole(UserRole role);
}
