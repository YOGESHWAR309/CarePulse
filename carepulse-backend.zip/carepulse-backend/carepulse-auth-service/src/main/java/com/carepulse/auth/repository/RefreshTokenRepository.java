package com.carepulse.auth.repository;

import com.carepulse.auth.entity.RefreshToken;
import com.carepulse.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

/**
 * Data access for {@link RefreshToken}. Backs the "stay logged in without
 * re-entering credentials" flow at POST /api/auth/refresh-token.
 */
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    /** Looks up the token supplied by the client to mint a new access token. */
    Optional<RefreshToken> findByToken(String token);

    /** Called on logout / password change so old refresh tokens can no longer be used. */
    @Modifying
    @Query("UPDATE RefreshToken r SET r.revoked = true WHERE r.user = :user")
    void revokeAllByUser(@Param("user") User user);
}
