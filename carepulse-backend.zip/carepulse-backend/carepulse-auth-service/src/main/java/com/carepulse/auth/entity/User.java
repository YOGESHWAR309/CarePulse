package com.carepulse.auth.entity;

import com.carepulse.auth.enums.UserRole;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Central identity record for EVERY person who can log into CarePulse -
 * admin, patient, doctor, receptionist, pharmacist, pathologist, radiologist,
 * dietician, and nutritionist. Role-specific professional data (e.g. a
 * doctor's department, specialization, availability) lives in Hospital
 * Service and is linked back here only by {@code userId} - this table's job
 * is authentication/authorization only, never clinical data.
 */
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(name = "uk_users_email", columnNames = "email")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String firstName;

    @Column(nullable = false, length = 100)
    private String lastName;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(length = 15)
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private UserRole role;

    /** False until email/OTP verification completes (patients) or admin activates the account. */
    @Column(nullable = false)
    @Builder.Default
    private boolean enabled = false;

    /** Used by Admin to soft-deactivate a doctor/staff member without deleting history. */
    @Column(nullable = false)
    @Builder.Default
    private boolean accountLocked = false;

    /** True for staff created by Admin who must change their temp password before doing anything else. */
    @Column(nullable = false)
    @Builder.Default
    private boolean firstLogin = false;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
