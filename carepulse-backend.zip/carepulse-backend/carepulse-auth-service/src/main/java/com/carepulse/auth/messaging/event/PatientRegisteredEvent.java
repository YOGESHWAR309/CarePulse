package com.carepulse.auth.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Published once a patient's OTP verification completes and their account
 * becomes enabled. Hospital Service consumes this to auto-provision a
 * clinical Patient profile row in {@code hospital_db} linked by userId -
 * Auth Service never writes clinical data itself.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PatientRegisteredEvent implements Serializable {
    private Long userId;
    private String email;
    private String firstName;
    private String lastName;
    private String phoneNumber;
}
