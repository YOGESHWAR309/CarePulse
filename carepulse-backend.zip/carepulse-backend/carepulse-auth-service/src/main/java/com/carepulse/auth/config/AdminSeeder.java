package com.carepulse.auth.config;

import com.carepulse.auth.entity.User;
import com.carepulse.auth.enums.UserRole;
import com.carepulse.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Runs once on every application startup and guarantees exactly one ADMIN
 * account exists, so there's always a way to log into a freshly deployed
 * CarePulse instance. Idempotent - if an admin with this email already
 * exists, does nothing.
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Order(1)
public class AdminSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${admin.default.email}")
    private String defaultAdminEmail;

    @Value("${admin.default.password}")
    private String defaultAdminPassword;

    /**
     * Executed automatically by Spring Boot after the context loads. Checks
     * for an existing admin by email before inserting, so restarting the
     * service never creates duplicate admins or resets the password of an
     * admin who's already changed it.
     */
    @Override
    public void run(String... args) {
        if (userRepository.existsByEmail(defaultAdminEmail)) {
            log.info("Default admin already exists, skipping seed: {}", defaultAdminEmail);
            return;
        }

        User admin = User.builder()
                .firstName("System")
                .lastName("Administrator")
                .email(defaultAdminEmail)
                .password(passwordEncoder.encode(defaultAdminPassword))
                .phoneNumber("0000000000")
                .role(UserRole.ADMIN)
                .enabled(true)
                .accountLocked(false)
                .firstLogin(true)
                .build();

        userRepository.save(admin);
        log.warn("Default admin account seeded: {} - CHANGE THE DEFAULT PASSWORD IMMEDIATELY IN PRODUCTION", defaultAdminEmail);
    }
}
