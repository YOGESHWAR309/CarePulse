package com.carepulse.auth.security;

import com.carepulse.auth.entity.User;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/**
 * Adapts our {@link User} entity to the shape Spring Security expects.
 * The role is exposed as a "ROLE_" prefixed authority (e.g. ROLE_DOCTOR) so
 * {@code hasRole("DOCTOR")} checks work out of the box in security config
 * and {@code @PreAuthorize} annotations.
 */
@Getter
public class UserPrincipal implements UserDetails {

    private final Long id;
    private final String email;
    private final String password;
    private final String role;
    private final boolean enabled;
    private final boolean accountLocked;

    public UserPrincipal(User user) {
        this.id = user.getId();
        this.email = user.getEmail();
        this.password = user.getPassword();
        this.role = user.getRole().name();
        this.enabled = user.isEnabled();
        this.accountLocked = user.isAccountLocked();
    }

    /** Exposes the single role as a Spring Security GrantedAuthority, prefixed with ROLE_ by convention. */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role));
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /** Locked accounts (deactivated doctors/staff) cannot authenticate. */
    @Override
    public boolean isAccountNonLocked() {
        return !accountLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /** Unverified patients (pending OTP confirmation) cannot log in until enabled. */
    @Override
    public boolean isEnabled() {
        return enabled;
    }
}
