package com.carepulse.auth.exception;

/** Thrown when a submitted OTP code is wrong, expired, or already used - mapped to HTTP 400. */
public class InvalidOtpException extends RuntimeException {
    public InvalidOtpException(String message) {
        super(message);
    }
}
