package com.carepulse.auth.dto.response;

import com.carepulse.auth.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Returned by POST /api/auth/login and POST /api/auth/refresh-token.
 * The frontend stores {@code accessToken} in memory and attaches it as
 * {@code Authorization: Bearer <accessToken>} on every subsequent request;
 * {@code refreshToken} is used only against /api/auth/refresh-token.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {

    private Long userId;
    private String email;
    private String firstName;
    private String lastName;
    private UserRole role;
    private String accessToken;
    private String refreshToken;

    /** Access token lifetime in seconds, so the frontend knows when to proactively refresh. */
    private Long expiresIn;

    /** True for staff who must change their temp password before doing anything else. */
    private boolean firstLogin;
}
