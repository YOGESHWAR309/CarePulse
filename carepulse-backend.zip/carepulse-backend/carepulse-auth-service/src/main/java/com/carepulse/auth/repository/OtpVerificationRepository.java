package com.carepulse.auth.repository;

import com.carepulse.auth.entity.OtpVerification;
import com.carepulse.auth.enums.OtpPurpose;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Data access for {@link OtpVerification}. Supports both the registration
 * email-verification flow and the forgot-password flow off the same table.
 */
public interface OtpVerificationRepository extends JpaRepository<OtpVerification, Long> {

    /**
     * Fetches the most recent, not-yet-verified OTP for an email/purpose pair.
     * Used to validate the code the user submits at /api/auth/verify-otp.
     */
    Optional<OtpVerification> findTopByEmailAndPurposeAndVerifiedFalseOrderByCreatedAtDesc(
            String email, OtpPurpose purpose);

    /**
     * Fetches the most recent VERIFIED OTP for an email/purpose pair. Used as
     * a gate before allowing /api/auth/reset-password to actually change the password.
     */
    Optional<OtpVerification> findTopByEmailAndPurposeAndVerifiedTrueOrderByCreatedAtDesc(
            String email, OtpPurpose purpose);
}
