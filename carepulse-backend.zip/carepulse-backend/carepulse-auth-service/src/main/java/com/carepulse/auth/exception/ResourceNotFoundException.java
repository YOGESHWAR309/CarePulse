package com.carepulse.auth.exception;

/** Thrown when a lookup (by id, email, etc.) finds nothing - mapped to HTTP 404. */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
