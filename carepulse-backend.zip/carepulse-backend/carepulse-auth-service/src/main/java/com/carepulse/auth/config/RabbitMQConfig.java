package com.carepulse.auth.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Declares the shared topic exchange that Auth Service PUBLISHES events to
 * and Notification Service CONSUMES from. Auth Service declares the queues
 * too (rather than assuming they pre-exist) so either service can be the
 * first one started without message loss.
 * <p>
 * Routing key scheme: {@code notification.<event-type>}, e.g.
 * {@code notification.otp}, {@code notification.email}.
 */
@Configuration
public class RabbitMQConfig {

    public static final String NOTIFICATION_EXCHANGE = "carepulse.notification.exchange";

    public static final String OTP_QUEUE = "carepulse.notification.otp.queue";
    public static final String OTP_ROUTING_KEY = "notification.otp";

    public static final String EMAIL_QUEUE = "carepulse.notification.email.queue";
    public static final String EMAIL_ROUTING_KEY = "notification.email";

    public static final String STAFF_CREATED_QUEUE = "carepulse.notification.staff-created.queue";
    public static final String STAFF_CREATED_ROUTING_KEY = "notification.staff-created";

    // ---- Hospital Service consumer queues (profile auto-provisioning) ----
    // Same topic exchange, different queues bound to the same/adjacent routing keys.
    // A topic exchange delivers an independent copy of each message to every
    // bound queue, so Notification Service and Hospital Service can each
    // consume the "staff created" event for entirely different purposes
    // (emailing credentials vs. provisioning a clinical profile row) without
    // competing with each other.
    public static final String PATIENT_REGISTERED_QUEUE = "carepulse.hospital.patient-registered.queue";
    public static final String PATIENT_REGISTERED_ROUTING_KEY = "hospital.patient-registered";

    public static final String HOSPITAL_STAFF_CREATED_QUEUE = "carepulse.hospital.staff-created.queue";

    /** Topic exchange so future event types can be added with new routing keys without changing existing bindings. */
    @Bean
    public TopicExchange notificationExchange() {
        return new TopicExchange(NOTIFICATION_EXCHANGE, true, false);
    }

    /** Durable queue Notification Service listens on for SendOtpEvent messages. */
    @Bean
    public Queue otpQueue() {
        return new Queue(OTP_QUEUE, true);
    }

    /** Durable queue Notification Service listens on for generic SendEmailEvent messages. */
    @Bean
    public Queue emailQueue() {
        return new Queue(EMAIL_QUEUE, true);
    }

    /** Durable queue Notification Service listens on for StaffCreatedEvent messages (login credentials email). */
    @Bean
    public Queue staffCreatedQueue() {
        return new Queue(STAFF_CREATED_QUEUE, true);
    }

    @Bean
    public Binding staffCreatedBinding() {
        return BindingBuilder.bind(staffCreatedQueue()).to(notificationExchange()).with(STAFF_CREATED_ROUTING_KEY);
    }

    /** Durable queue Hospital Service listens on to auto-provision a clinical Patient profile row after registration. */
    @Bean
    public Queue patientRegisteredQueue() {
        return new Queue(PATIENT_REGISTERED_QUEUE, true);
    }

    @Bean
    public Binding patientRegisteredBinding() {
        return BindingBuilder.bind(patientRegisteredQueue()).to(notificationExchange()).with(PATIENT_REGISTERED_ROUTING_KEY);
    }

    /**
     * Second, independent queue bound to the SAME staff-created routing key
     * so Hospital Service also receives a copy of every StaffCreatedEvent,
     * used to auto-provision a Doctor/Receptionist/Pharmacist/etc profile
     * row - entirely separate from Notification Service's copy of the same message.
     */
    @Bean
    public Queue hospitalStaffCreatedQueue() {
        return new Queue(HOSPITAL_STAFF_CREATED_QUEUE, true);
    }

    @Bean
    public Binding hospitalStaffCreatedBinding() {
        return BindingBuilder.bind(hospitalStaffCreatedQueue()).to(notificationExchange()).with(STAFF_CREATED_ROUTING_KEY);
    }

    @Bean
    public Binding otpBinding() {
        return BindingBuilder.bind(otpQueue()).to(notificationExchange()).with(OTP_ROUTING_KEY);
    }

    @Bean
    public Binding emailBinding() {
        return BindingBuilder.bind(emailQueue()).to(notificationExchange()).with(EMAIL_ROUTING_KEY);
    }

    /** JSON (not Java-serialization) message converter, so messages are language-agnostic and human-readable on the RabbitMQ dashboard. */
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}
