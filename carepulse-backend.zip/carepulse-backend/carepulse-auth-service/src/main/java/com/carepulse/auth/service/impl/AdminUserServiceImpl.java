package com.carepulse.auth.service.impl;

import com.carepulse.auth.dto.request.CreateStaffRequest;
import com.carepulse.auth.dto.response.UserSummaryResponse;
import com.carepulse.auth.entity.User;
import com.carepulse.auth.enums.UserRole;
import com.carepulse.auth.exception.DuplicateResourceException;
import com.carepulse.auth.exception.ResourceNotFoundException;
import com.carepulse.auth.mapper.UserMapper;
import com.carepulse.auth.messaging.NotificationEventPublisher;
import com.carepulse.auth.messaging.event.StaffCreatedEvent;
import com.carepulse.auth.repository.RefreshTokenRepository;
import com.carepulse.auth.repository.UserRepository;
import com.carepulse.auth.service.AdminUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AdminUserServiceImpl implements AdminUserService {

    private static final String TEMP_PASSWORD_CHARS =
            "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#$%";
    private static final int TEMP_PASSWORD_LENGTH = 12;

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;
    private final NotificationEventPublisher notificationEventPublisher;
    private final SecureRandom secureRandom = new SecureRandom();

    /**
     * Creates a staff account (any role except PATIENT/ADMIN) that is
     * ENABLED immediately (no self-verification needed, since Admin vouches
     * for them) but flagged firstLogin=true so they're forced to set their
     * own password before doing anything else. The temp password is emailed
     * via RabbitMQ -> Notification Service, never returned in the API response.
     */
    @Override
    @Transactional
    public UserSummaryResponse createStaff(CreateStaffRequest request) {
        if (request.getRole() == UserRole.ADMIN || request.getRole() == UserRole.PATIENT) {
            throw new IllegalArgumentException("This endpoint can only create staff roles, not ADMIN or PATIENT");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("An account with this email already exists");
        }

        String tempPassword = generateTemporaryPassword();

        User staff = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(tempPassword))
                .phoneNumber(request.getPhoneNumber())
                .role(request.getRole())
                .enabled(true)
                .accountLocked(false)
                .firstLogin(true)
                .build();

        User saved = userRepository.save(staff);

        notificationEventPublisher.publishStaffCreatedEvent(
                StaffCreatedEvent.builder()
                        .userId(saved.getId())
                        .recipientEmail(saved.getEmail())
                        .recipientName(saved.getFirstName())
                        .role(saved.getRole())
                        .temporaryPassword(tempPassword)
                        .qualification(request.getQualification())
                        .specialization(request.getSpecialization())
                        .build());

        log.info("Staff account created by Admin: {} (role={})", saved.getEmail(), saved.getRole());
        return userMapper.toSummaryResponse(saved);
    }

    /** Flips accountLocked back to false, restoring login access without touching any clinical history. */
    @Override
    @Transactional
    public UserSummaryResponse activateUser(Long userId) {
        User user = findStaffOrDoctor(userId);
        user.setAccountLocked(false);
        User saved = userRepository.save(user);
        log.info("User activated: {}", saved.getEmail());
        return userMapper.toSummaryResponse(saved);
    }

    /** Sets accountLocked=true (login blocked) and revokes any live refresh tokens immediately. */
    @Override
    @Transactional
    public UserSummaryResponse deactivateUser(Long userId) {
        User user = findStaffOrDoctor(userId);
        user.setAccountLocked(true);
        User saved = userRepository.save(user);
        refreshTokenRepository.revokeAllByUser(saved);
        log.info("User deactivated: {}", saved.getEmail());
        return userMapper.toSummaryResponse(saved);
    }

    /**
     * Used when a staff member is locked out and can't self-serve via
     * forgot-password (e.g. their email issue is the actual problem).
     * Generates a new temp password, forces firstLogin again, and emails it.
     */
    @Override
    @Transactional
    public void resetStaffPassword(Long userId) {
        User user = findStaffOrDoctor(userId);
        String tempPassword = generateTemporaryPassword();

        user.setPassword(passwordEncoder.encode(tempPassword));
        user.setFirstLogin(true);
        userRepository.save(user);
        refreshTokenRepository.revokeAllByUser(user);

        notificationEventPublisher.publishStaffCreatedEvent(
                StaffCreatedEvent.builder()
                        .userId(user.getId())
                        .recipientEmail(user.getEmail())
                        .recipientName(user.getFirstName())
                        .role(user.getRole())
                        .temporaryPassword(tempPassword)
                        .build());

        log.info("Password reset by Admin for: {}", user.getEmail());
    }

    @Override
    public List<UserSummaryResponse> getAllPatients() {
        return getUsersByRole(UserRole.PATIENT);
    }

    @Override
    public List<UserSummaryResponse> getAllDoctors() {
        return getUsersByRole(UserRole.DOCTOR);
    }

    /** Aggregates every role EXCEPT patient and doctor (which have their own dedicated screens) into one "staff" list. */
    @Override
    public List<UserSummaryResponse> getAllStaff() {
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() != UserRole.PATIENT && u.getRole() != UserRole.DOCTOR && u.getRole() != UserRole.ADMIN)
                .map(userMapper::toSummaryResponse)
                .toList();
    }

    @Override
    public UserSummaryResponse getUserById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        return userMapper.toSummaryResponse(user);
    }

    @Override
    public List<UserSummaryResponse> getUsersByRole(UserRole role) {
        return userRepository.findByRole(role).stream()
                .map(userMapper::toSummaryResponse)
                .toList();
    }

    /** Shared lookup for activate/deactivate/reset-password - all three only make sense for non-patient, non-admin accounts. */
    private User findStaffOrDoctor(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        if (user.getRole() == UserRole.ADMIN) {
            throw new IllegalArgumentException("Admin accounts cannot be managed through this endpoint");
        }
        return user;
    }

    /** Builds a random 12-character password mixing letters, digits, and symbols - meets the same policy patients' self-chosen passwords must meet. */
    private String generateTemporaryPassword() {
        StringBuilder sb = new StringBuilder(TEMP_PASSWORD_LENGTH);
        for (int i = 0; i < TEMP_PASSWORD_LENGTH; i++) {
            sb.append(TEMP_PASSWORD_CHARS.charAt(secureRandom.nextInt(TEMP_PASSWORD_CHARS.length())));
        }
        return sb.toString();
    }
}
