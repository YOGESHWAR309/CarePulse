package com.carepulse.auth.service;

import com.carepulse.auth.enums.OtpPurpose;

/**
 * Generates, sends, and verifies one-time-passwords. Shared by both the
 * registration-verification flow and the forgot-password flow.
 */
public interface OtpService {

    /** Generates a new 6-digit OTP for the given email/purpose, persists it, and publishes a SendOtpEvent. */
    void generateAndSendOtp(String email, String recipientName, OtpPurpose purpose);

    /**
     * Validates a submitted OTP against the most recent unverified one on file.
     * Marks it verified on success. Throws InvalidOtpException on mismatch,
     * expiry, or if too many attempts have already been made.
     */
    void verifyOtp(String email, String otpCode, OtpPurpose purpose);

    /** Checks whether the given email has a successfully verified OTP for this purpose (used as a gate before reset-password). */
    boolean isOtpVerified(String email, OtpPurpose purpose);
}
