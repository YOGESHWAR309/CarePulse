package com.carepulse.auth.messaging.event;

import com.carepulse.auth.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Published (routing key {@code notification.email}, reusing the generic
 * email queue) when Admin creates a new staff account, so Notification
 * Service can email the staff member their login email + temporary password.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffCreatedEvent implements Serializable {
    private Long userId;
    private String recipientEmail;
    private String recipientName;
    private UserRole role;
    private String temporaryPassword;
    private String qualification;
    private String specialization;
}
