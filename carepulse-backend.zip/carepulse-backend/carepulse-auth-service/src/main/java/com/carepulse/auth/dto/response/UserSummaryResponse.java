package com.carepulse.auth.dto.response;

import com.carepulse.auth.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Lightweight user record returned in list form to Admin screens
 * (View All Patients / View All Doctors / View All Staff) and to
 * other microservices calling this service via OpenFeign to validate
 * a user or fetch basic identity info.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSummaryResponse {

    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private UserRole role;
    private boolean enabled;
    private boolean accountLocked;
    private LocalDateTime createdAt;
}
