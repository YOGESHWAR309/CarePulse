package com.carepulse.auth.mapper;

import com.carepulse.auth.dto.response.UserProfileResponse;
import com.carepulse.auth.dto.response.UserSummaryResponse;
import com.carepulse.auth.entity.User;
import org.mapstruct.Mapper;

/**
 * MapStruct mapper - converts between the {@link User} entity and its
 * outward-facing DTOs. Never exposes the entity (and therefore never the
 * password hash) directly from any controller.
 */
@Mapper(componentModel = "spring")
public interface UserMapper {

    /** Used by GET /api/auth/profile. */
    UserProfileResponse toProfileResponse(User user);

    /** Used by Admin list endpoints (View All Patients/Doctors/Staff) and internal Feign lookups. */
    UserSummaryResponse toSummaryResponse(User user);
}
