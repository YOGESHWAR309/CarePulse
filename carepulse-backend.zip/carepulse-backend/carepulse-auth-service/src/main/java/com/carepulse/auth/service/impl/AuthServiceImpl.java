package com.carepulse.auth.service.impl;

import com.carepulse.auth.dto.request.*;
import com.carepulse.auth.dto.response.AuthResponse;
import com.carepulse.auth.dto.response.UserProfileResponse;
import com.carepulse.auth.entity.RefreshToken;
import com.carepulse.auth.entity.User;
import com.carepulse.auth.enums.OtpPurpose;
import com.carepulse.auth.enums.UserRole;
import com.carepulse.auth.exception.DuplicateResourceException;
import com.carepulse.auth.exception.InvalidCredentialsException;
import com.carepulse.auth.exception.InvalidOtpException;
import com.carepulse.auth.exception.ResourceNotFoundException;
import com.carepulse.auth.exception.TokenRefreshException;
import com.carepulse.auth.mapper.UserMapper;
import com.carepulse.auth.messaging.NotificationEventPublisher;
import com.carepulse.auth.messaging.event.SendEmailEvent;
import com.carepulse.auth.repository.RefreshTokenRepository;
import com.carepulse.auth.repository.UserRepository;
import com.carepulse.auth.security.JwtService;
import com.carepulse.auth.service.AuthService;
import com.carepulse.auth.service.OtpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final OtpService otpService;
    private final UserMapper userMapper;
    private final NotificationEventPublisher notificationEventPublisher;

    @Value("${jwt.refresh-token-expiration}")
    private long refreshTokenExpirationMs;

    /**
     * Creates a disabled PATIENT record (only patients may self-register -
     * doctors/staff are created exclusively by Admin), hashes the password
     * with BCrypt, then kicks off the registration-OTP email. The account
     * stays disabled until {@link #verifyOtp} succeeds.
     */
    @Override
    @Transactional
    public void registerPatient(PatientRegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("An account with this email already exists");
        }

        User patient = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phoneNumber(request.getPhoneNumber())
                .role(UserRole.PATIENT)
                .enabled(false)
                .accountLocked(false)
                .firstLogin(false)
                .build();

        userRepository.save(patient);

        otpService.generateAndSendOtp(
                patient.getEmail(), patient.getFirstName(), OtpPurpose.REGISTRATION);

        log.info("Patient registered (pending OTP verification): {}", patient.getEmail());
    }

    /**
     * Delegates credential checking to Spring Security's AuthenticationManager
     * (which uses CustomUserDetailsService + BCrypt under the hood), then on
     * success issues a fresh access token + a new persisted refresh token.
     */
    @Override
    @Transactional
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new InvalidCredentialsException("Invalid email or password"));

        if (user.isAccountLocked()) {
            throw new InvalidCredentialsException("This account has been deactivated. Please contact the hospital administrator.");
        }

        if (!user.isEnabled()) {
            throw new InvalidCredentialsException("Account is not verified yet. Please complete OTP verification.");
        }

        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        } catch (Exception ex) {
            throw new InvalidCredentialsException("Invalid email or password");
        }

        String accessToken = jwtService.generateAccessToken(user.getId(), user.getEmail(), user.getRole().name());
        String refreshTokenValue = createRefreshToken(user);

        log.info("User logged in: {} (role={})", user.getEmail(), user.getRole());

        return AuthResponse.builder()
                .userId(user.getId())
                .email(user.getEmail())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .role(user.getRole())
                .accessToken(accessToken)
                .refreshToken(refreshTokenValue)
                .expiresIn(jwtService.getAccessTokenExpirationMs() / 1000)
                .firstLogin(user.isFirstLogin())
                .build();
    }

    /**
     * Looks up the presented refresh token, rejects it if revoked or past its
     * expiry, and otherwise mints a brand-new access token for the same user
     * without requiring their password again.
     */
    @Override
    @Transactional
    public AuthResponse refreshToken(RefreshTokenRequest request) {
        RefreshToken storedToken = refreshTokenRepository.findByToken(request.getRefreshToken())
                .orElseThrow(() -> new TokenRefreshException("Refresh token not found. Please log in again."));

        if (storedToken.isRevoked()) {
            throw new TokenRefreshException("Refresh token has been revoked. Please log in again.");
        }

        if (storedToken.getExpiryDate().isBefore(Instant.now())) {
            throw new TokenRefreshException("Refresh token has expired. Please log in again.");
        }

        User user = storedToken.getUser();
        String newAccessToken = jwtService.generateAccessToken(user.getId(), user.getEmail(), user.getRole().name());

        return AuthResponse.builder()
                .userId(user.getId())
                .email(user.getEmail())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .role(user.getRole())
                .accessToken(newAccessToken)
                .refreshToken(storedToken.getToken())
                .expiresIn(jwtService.getAccessTokenExpirationMs() / 1000)
                .firstLogin(user.isFirstLogin())
                .build();
    }

    /**
     * Always logs the same outcome to the caller regardless of whether the
     * email exists, to avoid leaking which emails are registered. Internally,
     * only sends the OTP if a matching enabled account is actually found.
     */
    @Override
    @Transactional
    public void forgotPassword(ForgotPasswordRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent(user -> {
            if (user.isEnabled() && !user.isAccountLocked()) {
                otpService.generateAndSendOtp(user.getEmail(), user.getFirstName(), OtpPurpose.PASSWORD_RESET);
            }
        });
        log.info("Forgot-password requested for: {}", request.getEmail());
    }

    /**
     * Delegates to OtpService for the actual code check. On successful
     * REGISTRATION verification, additionally flips the account to enabled
     * so the patient can now log in.
     */
    @Override
    @Transactional
    public void verifyOtp(VerifyOtpRequest request) {
        otpService.verifyOtp(request.getEmail(), request.getOtpCode(), request.getPurpose());

        if (request.getPurpose() == OtpPurpose.REGISTRATION) {
            User user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found"));
            user.setEnabled(true);
            userRepository.save(user);

            notificationEventPublisher.publishPatientRegisteredEvent(
                    com.carepulse.auth.messaging.event.PatientRegisteredEvent.builder()
                            .userId(user.getId())
                            .email(user.getEmail())
                            .firstName(user.getFirstName())
                            .lastName(user.getLastName())
                            .phoneNumber(user.getPhoneNumber())
                            .build());

            log.info("Patient account activated after OTP verification: {}", user.getEmail());
        }
    }

    /** Simply re-triggers OTP generation/send for the same email+purpose - a fresh code supersedes any previous one. */
    @Override
    @Transactional
    public void resendOtp(ForgotPasswordRequest request, OtpPurpose purpose) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("No account found with this email"));
        otpService.generateAndSendOtp(user.getEmail(), user.getFirstName(), purpose);
    }

    /**
     * Only allows the password change if {@link OtpService#isOtpVerified}
     * confirms the PASSWORD_RESET OTP gate was already passed - prevents
     * skipping straight to this endpoint without ever proving email ownership.
     */
    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        if (!otpService.isOtpVerified(request.getEmail(), OtpPurpose.PASSWORD_RESET)) {
            throw new InvalidOtpException("Please verify the OTP sent to your email before resetting your password");
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        // Revoke all existing refresh tokens - a password reset should force re-login everywhere.
        refreshTokenRepository.revokeAllByUser(user);

        notificationEventPublisher.publishEmailEvent(
                SendEmailEvent.builder()
                        .recipientEmail(user.getEmail())
                        .recipientName(user.getFirstName())
                        .subject("Your CarePulse password has been reset")
                        .body("Your password was successfully reset. If you did not request this, please contact support immediately.")
                        .build());

        log.info("Password reset completed for: {}", user.getEmail());
    }

    /**
     * Requires the caller to prove they know their CURRENT password before
     * setting a new one - distinct from resetPassword, which is for users
     * who've forgotten their password entirely and prove identity via OTP instead.
     */
    @Override
    @Transactional
    public void changePassword(Long userId, ChangePasswordRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new InvalidCredentialsException("Current password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setFirstLogin(false);
        userRepository.save(user);

        refreshTokenRepository.revokeAllByUser(user);

        log.info("Password changed for: {}", user.getEmail());
    }

    /** Straightforward read, mapped through UserMapper so the password hash never leaves the service layer. */
    @Override
    public UserProfileResponse getProfile(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return userMapper.toProfileResponse(user);
    }

    /** Updates only the mutable identity fields (name, phone) - email and role are never editable through this endpoint. */
    @Override
    @Transactional
    public UserProfileResponse updateProfile(Long userId, UpdateProfileRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhoneNumber(request.getPhoneNumber());

        User saved = userRepository.save(user);
        log.info("Profile updated for: {}", saved.getEmail());
        return userMapper.toProfileResponse(saved);
    }

    /**
     * Generates a random opaque refresh token (a UUID, not a JWT - it carries
     * no claims, it's just a lookup key into the refresh_tokens table) and
     * persists it with its expiry.
     */
    private String createRefreshToken(User user) {
        String tokenValue = UUID.randomUUID().toString();

        RefreshToken refreshToken = RefreshToken.builder()
                .token(tokenValue)
                .user(user)
                .expiryDate(Instant.now().plus(refreshTokenExpirationMs, ChronoUnit.MILLIS))
                .revoked(false)
                .build();

        refreshTokenRepository.save(refreshToken);
        return tokenValue;
    }
}
