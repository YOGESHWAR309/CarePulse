package com.carepulse.auth.dto.response;

import com.carepulse.auth.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/** Returned by GET /api/auth/profile - the logged-in user's own identity details. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserProfileResponse {

    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private UserRole role;
    private boolean enabled;
    private boolean accountLocked;
    private boolean firstLogin;
    private LocalDateTime createdAt;
}
