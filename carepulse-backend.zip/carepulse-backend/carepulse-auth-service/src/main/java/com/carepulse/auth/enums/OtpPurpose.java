package com.carepulse.auth.enums;

/**
 * Distinguishes what an OTP code is being used for, so the same
 * OtpVerification table/flow can serve multiple use cases without
 * a code generated for one purpose being replayable for another.
 */
public enum OtpPurpose {

    /** Sent right after patient self-registration to verify the email address is real. */
    REGISTRATION,

    /** Sent as part of the forgot-password flow, required before a reset token is issued. */
    PASSWORD_RESET
}
