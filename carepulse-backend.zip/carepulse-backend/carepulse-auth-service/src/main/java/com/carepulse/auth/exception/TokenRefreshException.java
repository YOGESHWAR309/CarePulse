package com.carepulse.auth.exception;

/** Thrown when a refresh token is missing, expired, or revoked - mapped to HTTP 401, forcing the client to re-login. */
public class TokenRefreshException extends RuntimeException {
    public TokenRefreshException(String message) {
        super(message);
    }
}
