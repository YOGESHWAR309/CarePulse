package com.carepulse.auth.repository;

import com.carepulse.auth.entity.User;
import com.carepulse.auth.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Data access for the {@link User} entity - the single source of truth
 * for authentication across all of CarePulse.
 */
public interface UserRepository extends JpaRepository<User, Long> {

    /** Used at login, and to enforce unique email during registration. */
    Optional<User> findByEmail(String email);

    /** Quick existence check before insert, avoids catching a DB constraint violation. */
    boolean existsByEmail(String email);

    /** Used by Admin's "View All Doctors / View All Staff" screens. */
    List<User> findByRole(UserRole role);

    /** Used by Admin's "View All Patients" screen, paged in the service layer if needed. */
    List<User> findByRoleAndAccountLockedFalse(UserRole role);
}
