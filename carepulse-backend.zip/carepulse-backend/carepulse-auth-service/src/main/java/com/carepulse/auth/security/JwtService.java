package com.carepulse.auth.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Owns the entire lifecycle of JWT access tokens - Auth Service is the
 * ONLY microservice allowed to issue tokens. The API Gateway and other
 * services only ever verify a token's signature, using the same
 * {@code jwt.secret} configured here.
 */
@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.access-token-expiration}")
    private long accessTokenExpirationMs;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Builds a signed access token embedding userId, email (as subject) and role,
     * so downstream services never need to query this service just to know who's calling.
     */
    public String generateAccessToken(Long userId, String email, String role) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", String.valueOf(userId));
        claims.put("role", role);

        Date now = new Date();
        Date expiry = new Date(now.getTime() + accessTokenExpirationMs);

        return Jwts.builder()
                .claims(claims)
                .subject(email)
                .issuedAt(now)
                .expiration(expiry)
                .signWith(getSigningKey())
                .compact();
    }

    /** Exposes the configured token lifetime (ms) so login/refresh responses can report expiresIn to the client. */
    public long getAccessTokenExpirationMs() {
        return accessTokenExpirationMs;
    }

    /** Extracts the subject (email) claim from a token - used to re-identify a user during refresh. */
    public String extractEmail(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /** Extracts the custom "role" claim from a token. */
    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }

    /** Generic claim extractor - takes a resolver function so callers can pull any claim type-safely. */
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    /** Parses and verifies the token's signature, throwing if it's malformed, expired, or tampered with. */
    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /** True if the token's signature is valid and it has not yet expired. */
    public boolean isTokenValid(String token) {
        try {
            Date expiration = extractClaim(token, Claims::getExpiration);
            return expiration.after(new Date());
        } catch (Exception ex) {
            return false;
        }
    }
}
