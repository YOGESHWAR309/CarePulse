package com.carepulse.auth.enums;

/**
 * Every role recognized by CarePulse. Stored on the User entity and embedded
 * as a claim inside every issued JWT so downstream services can authorize
 * requests without a second database lookup.
 */
public enum UserRole {

    /** Full system access. Seeded automatically at startup; also creates all other staff accounts. */
    ADMIN,

    /** Self-registers through the public registration endpoint. */
    PATIENT,

    /** Created only by ADMIN. Manages own availability, writes prescriptions, treats patients. */
    DOCTOR,

    /** Created only by ADMIN. Handles walk-in registration, appointment booking, check-in/out. */
    RECEPTIONIST,

    /** Created only by ADMIN. Verifies and dispenses prescriptions. */
    PHARMACIST,

    /** Created only by ADMIN. Performs lab tests, uploads lab reports. */
    PATHOLOGIST,

    /** Created only by ADMIN. Performs scans, uploads radiology reports. */
    RADIOLOGIST,

    /** Created only by ADMIN. Creates and manages patient diet plans. */
    DIETICIAN,

    /** Created only by ADMIN. Creates and manages patient nutrition plans. */
    NUTRITIONIST,

    /** Created only by ADMIN. Manages canteen/food-service menu, patient diet-tray orders, and kitchen order status. */
    CANTEEN_STAFF
}
