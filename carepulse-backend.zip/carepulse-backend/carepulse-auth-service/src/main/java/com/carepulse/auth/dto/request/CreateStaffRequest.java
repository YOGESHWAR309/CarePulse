package com.carepulse.auth.dto.request;

import com.carepulse.auth.enums.UserRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Payload for POST /api/auth/admin/staff - the ONLY way a Doctor,
 * Receptionist, Pharmacist, Pathologist, Radiologist, Dietician, or
 * Nutritionist account gets created. Callable only by ADMIN.
 * A random temporary password is generated server-side (not accepted here)
 * and emailed to the staff member; {@code firstLogin} forces them to change
 * it before using any other endpoint.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateStaffRequest {

    @NotBlank(message = "First name is required")
    @Size(max = 100, message = "First name must not exceed 100 characters")
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(max = 100, message = "Last name must not exceed 100 characters")
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Phone number must be a valid 10-15 digit number")
    private String phoneNumber;

    /** Must be one of DOCTOR, RECEPTIONIST, PHARMACIST, PATHOLOGIST, RADIOLOGIST, DIETICIAN, NUTRITIONIST. */
    @NotNull(message = "Role is required")
    private UserRole role;

    /** Education/qualification (e.g. "MBBS, MD", "B.Pharm", "B.Sc Nursing") - optional at creation, can be added later if not known yet. */
    @Size(max = 200, message = "Qualification must not exceed 200 characters")
    private String qualification;

    /** Only meaningful for role=DOCTOR (e.g. "Cardiology"). Department assignment still happens separately via Admin's doctor-update endpoint, since Auth Service has no knowledge of Hospital Service's department list. */
    @Size(max = 150, message = "Specialization must not exceed 150 characters")
    private String specialization;
}
