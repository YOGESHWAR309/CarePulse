package com.carepulse.auth.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Guards every "/api/auth/internal/**" path. These endpoints are meant to
 * be called ONLY by other CarePulse microservices over OpenFeign (never by
 * the frontend), so instead of requiring a user JWT they require a shared
 * internal secret header. Every calling service must send
 * {@code X-Internal-Api-Key} matching {@code internal.api.key} - configured
 * identically across all services.
 */
@Component
public class InternalApiKeyFilter extends OncePerRequestFilter {

    @Value("${internal.api.key}")
    private String internalApiKey;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        if (request.getRequestURI().startsWith("/api/auth/internal")) {
            String providedKey = request.getHeader("X-Internal-Api-Key");
            if (providedKey == null || !providedKey.equals(internalApiKey)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.setContentType("application/json");
                response.getWriter().write(
                        "{\"success\":false,\"message\":\"Missing or invalid internal API key\"}");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}
