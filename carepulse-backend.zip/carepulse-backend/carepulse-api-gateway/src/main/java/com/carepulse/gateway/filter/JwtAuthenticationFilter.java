package com.carepulse.gateway.filter;

import com.carepulse.gateway.util.JwtUtil;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * Global filter applied to EVERY route configured in the gateway.
 * <p>
 * Flow:
 * 1. If the request path matches an entry in {@link RouteValidator#OPEN_API_ENDPOINTS},
 *    it is passed through untouched (e.g. login, register, swagger).
 * 2. Otherwise, the {@code Authorization: Bearer <token>} header is required.
 * 3. The token is validated (signature + expiry) via {@link JwtUtil}.
 * 4. On success, the userId/email/role claims are extracted and forwarded to
 *    downstream microservices as request headers (X-User-Id, X-User-Email, X-User-Role)
 *    so downstream services don't need to re-parse the JWT themselves.
 * 5. On failure, the gateway short-circuits with 401 UNAUTHORIZED - the request
 *    never reaches a downstream microservice.
 */
@Component
public class JwtAuthenticationFilter implements GlobalFilter, Ordered {

    private final RouteValidator routeValidator;
    private final JwtUtil jwtUtil;

    public JwtAuthenticationFilter(RouteValidator routeValidator, JwtUtil jwtUtil) {
        this.routeValidator = routeValidator;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Runs once per incoming request, before it is proxied to any microservice.
     * Skips validation for public routes, otherwise requires and validates a
     * Bearer JWT, then injects identity headers for downstream services.
     * Returning {@code onError(...)} short-circuits the chain - {@code chain.filter}
     * is never called, so the request never leaves the gateway.
     */
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();

        if (!routeValidator.isSecured.test(request)) {
            return chain.filter(exchange);
        }

        if (!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
            return onError(exchange, "Missing Authorization header", HttpStatus.UNAUTHORIZED);
        }

        String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return onError(exchange, "Authorization header must start with 'Bearer '", HttpStatus.UNAUTHORIZED);
        }

        String token = authHeader.substring(7);

        if (!jwtUtil.isTokenValid(token)) {
            return onError(exchange, "Invalid or expired JWT token", HttpStatus.UNAUTHORIZED);
        }

        String userId = jwtUtil.extractUserId(token);
        String email = jwtUtil.extractEmail(token);
        String role = jwtUtil.extractRole(token);

        ServerHttpRequest mutatedRequest = request.mutate()
                .header("X-User-Id", userId == null ? "" : userId)
                .header("X-User-Email", email == null ? "" : email)
                .header("X-User-Role", role == null ? "" : role)
                .build();

        return chain.filter(exchange.mutate().request(mutatedRequest).build());
    }

    /**
     * Writes a JSON error body directly to the response and stops the
     * filter chain - used for 401s (missing/invalid/expired token) so the
     * frontend gets a consistent error shape instead of a generic failure.
     */
    private Mono<Void> onError(ServerWebExchange exchange, String message, HttpStatus httpStatus) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        response.getHeaders().add("Content-Type", "application/json");
        String body = String.format("{\"timestamp\":\"%s\",\"status\":%d,\"error\":\"%s\",\"message\":\"%s\"}",
                java.time.Instant.now(), httpStatus.value(), httpStatus.getReasonPhrase(), message);
        var buffer = response.bufferFactory().wrap(body.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return response.writeWith(Mono.just(buffer));
    }

    /**
     * Ensures this filter runs before Spring Cloud Gateway's routing filters
     * (lower value = higher priority), so auth is enforced before proxying.
     */
    @Override
    public int getOrder() {
        return -1;
    }
}
