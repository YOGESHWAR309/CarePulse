package com.carepulse.gateway.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;

/**
 * Invoked by Resilience4j's CircuitBreaker gateway filter whenever a
 * downstream service (Auth / Hospital / Notification) is unreachable,
 * times out, or its circuit is OPEN. Returns a graceful 503 instead of
 * letting the caller hit a raw connection-refused error.
 */
@RestController
@RequestMapping("/fallback")
public class FallbackController {

    /** Hit when Auth Service's circuit breaker opens on a GET request (e.g. GET /api/auth/profile). */
    @GetMapping("/auth")
    public Mono<ResponseEntity<Map<String, Object>>> authFallback() {
        return buildFallbackResponse("Auth Service");
    }

    /** Hit when Auth Service's circuit breaker opens on a POST request (e.g. POST /api/auth/login). */
    @PostMapping("/auth")
    public Mono<ResponseEntity<Map<String, Object>>> authFallbackPost() {
        return buildFallbackResponse("Auth Service");
    }

    /** Hit when Hospital Service's circuit breaker opens on a GET request (e.g. GET /api/hospital/doctors). */
    @GetMapping("/hospital")
    public Mono<ResponseEntity<Map<String, Object>>> hospitalFallback() {
        return buildFallbackResponse("Hospital Service");
    }

    /** Hit when Hospital Service's circuit breaker opens on a POST request (e.g. POST /api/hospital/appointments). */
    @PostMapping("/hospital")
    public Mono<ResponseEntity<Map<String, Object>>> hospitalFallbackPost() {
        return buildFallbackResponse("Hospital Service");
    }

    /** Hit when Notification Service's circuit breaker opens (e.g. GET /api/notifications/logs). */
    @GetMapping("/notification")
    public Mono<ResponseEntity<Map<String, Object>>> notificationFallback() {
        return buildFallbackResponse("Notification Service");
    }

    /**
     * Shared helper that builds a consistent 503 JSON body naming which
     * downstream service is currently unavailable.
     */
    private Mono<ResponseEntity<Map<String, Object>>> buildFallbackResponse(String serviceName) {
        Map<String, Object> body = Map.of(
                "timestamp", Instant.now().toString(),
                "status", HttpStatus.SERVICE_UNAVAILABLE.value(),
                "error", "Service Unavailable",
                "message", serviceName + " is temporarily unavailable. Please try again in a few moments."
        );
        return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body));
    }
}
