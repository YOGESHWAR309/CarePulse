package com.carepulse.gateway.filter;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Predicate;

/**
 * Identifies which incoming requests are "public" - i.e. do NOT require a
 * JWT access token. Everything else is treated as secured by default,
 * which is the safer default for a hospital system handling PHI.
 */
@Component
public class RouteValidator {

    public static final List<String> OPEN_API_ENDPOINTS = List.of(
            "/api/auth/register",
            "/api/auth/login",
            "/api/auth/refresh-token",
            "/api/auth/forgot-password",
            "/api/auth/reset-password",
            "/api/auth/verify-otp",
            "/api/auth/resend-otp",
            "/api/hospital/departments",
            "/api/hospital/doctors/public",
            "/v3/api-docs",
            "/swagger-ui",
            "/actuator"
    );

    public Predicate<ServerHttpRequest> isSecured =
            request -> OPEN_API_ENDPOINTS.stream()
                    .noneMatch(uri -> request.getURI().getPath().contains(uri));
}
