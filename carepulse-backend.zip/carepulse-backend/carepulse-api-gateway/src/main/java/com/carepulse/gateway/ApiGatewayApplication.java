package com.carepulse.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * CarePulse - API Gateway
 * <p>
 * Single entry point for the React frontend. Responsibilities:
 * <ul>
 *     <li>Route requests to the correct downstream microservice via Eureka
 *     (Auth Service, Hospital Service, Notification Service)</li>
 *     <li>Validate JWT access tokens on every protected route
 *     ({@link com.carepulse.gateway.filter.JwtAuthenticationFilter})</li>
 *     <li>Enforce CORS policy centrally so downstream services don't have to</li>
 *     <li>Apply circuit breakers / fallbacks for downstream outages</li>
 * </ul>
 * Runs on port 8080 by default. This is the ONLY service the frontend talks to directly.
 */
@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {

    /**
     * Entry point. Starts the reactive Gateway server, registers it with
     * Eureka, and loads all routes/filters defined in application.properties.
     */
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
