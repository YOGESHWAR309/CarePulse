package com.carepulse.gateway.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;

/**
 * Validates JWT access tokens at the Gateway layer before a request is
 * ever routed to a downstream microservice.
 * <p>
 * The Gateway only VALIDATES the token signature/expiry and extracts
 * claims (userId, email, role) to forward as headers. It does NOT issue
 * tokens - that responsibility belongs solely to the Auth Service.
 * Both services must share the same {@code jwt.secret} so signatures
 * verify correctly across services.
 */
@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    /**
     * Builds the HMAC-SHA signing key from the shared secret string.
     * Used both to verify a token's signature was produced by the Auth Service
     * (which signs with the same secret) and hasn't been tampered with.
     */
    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Validates a JWT's signature and expiry only (no DB/user lookup at the gateway).
     * Called by {@link com.carepulse.gateway.filter.JwtAuthenticationFilter} before
     * a request is allowed to reach any downstream microservice.
     * @return true if the token is structurally valid, correctly signed, and not expired.
     */
    public boolean isTokenValid(String token) {
        try {
            Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token);
            return true;
        } catch (ExpiredJwtException | MalformedJwtException | SignatureException | IllegalArgumentException ex) {
            return false;
        }
    }

    /**
     * Parses the token and returns all claims (payload) inside it.
     * Call {@link #isTokenValid(String)} first - this method throws if the
     * token is invalid/expired, since it re-parses without a try/catch.
     */
    public Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /**
     * Reads the "userId" custom claim - used to populate the X-User-Id
     * header forwarded to downstream microservices.
     */
    public String extractUserId(String token) {
        return extractAllClaims(token).get("userId", String.class);
    }

    /**
     * Reads the JWT "sub" (subject) claim, which the Auth Service sets to
     * the user's email at token-issue time - used for the X-User-Email header.
     */
    public String extractEmail(String token) {
        return extractAllClaims(token).getSubject();
    }

    /**
     * Reads the "role" custom claim (e.g. ADMIN, PATIENT, DOCTOR) - used
     * for the X-User-Role header so downstream services can authorize
     * requests without re-decoding the JWT themselves.
     */
    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }
}
