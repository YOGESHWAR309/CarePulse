package com.carepulse.notification.dto.response;

import com.carepulse.notification.enums.NotificationStatus;
import com.carepulse.notification.enums.NotificationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationLogResponse {
    private Long id;
    private String recipientEmail;
    private String subject;
    private NotificationType type;
    private NotificationStatus status;
    private String errorMessage;
    private LocalDateTime createdAt;
}
