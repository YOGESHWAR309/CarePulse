package com.carepulse.notification.controller;

import com.carepulse.notification.dto.response.ApiResponse;
import com.carepulse.notification.dto.response.NotificationLogResponse;
import com.carepulse.notification.entity.NotificationLog;
import com.carepulse.notification.enums.NotificationStatus;
import com.carepulse.notification.exception.ResourceNotFoundException;
import com.carepulse.notification.mapper.NotificationLogMapper;
import com.carepulse.notification.repository.NotificationLogRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Admin-only visibility into every notification this service has attempted
 * to send - lets Admin confirm "did the OTP/confirmation/report-ready
 * email actually go out" without needing server log access.
 */
@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Tag(name = "Notification Logs", description = "Admin-only audit trail of every notification sent or attempted")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasRole('ADMIN')")
public class NotificationLogController {

    private final NotificationLogRepository notificationLogRepository;
    private final NotificationLogMapper notificationLogMapper;

    @Operation(summary = "[Admin] View every notification log, most recent first")
    @GetMapping("/logs")
    public ResponseEntity<ApiResponse<List<NotificationLogResponse>>> getAllLogs() {
        List<NotificationLogResponse> response = notificationLogRepository.findAllByOrderByCreatedAtDesc()
                .stream().map(notificationLogMapper::toResponse).toList();
        return ResponseEntity.ok(ApiResponse.success("Notification logs fetched successfully", response));
    }

    @Operation(summary = "[Admin] View only FAILED notification logs")
    @GetMapping("/logs/failed")
    public ResponseEntity<ApiResponse<List<NotificationLogResponse>>> getFailedLogs() {
        List<NotificationLogResponse> response = notificationLogRepository.findByStatusOrderByCreatedAtDesc(NotificationStatus.FAILED)
                .stream().map(notificationLogMapper::toResponse).toList();
        return ResponseEntity.ok(ApiResponse.success("Failed notification logs fetched successfully", response));
    }

    @Operation(summary = "[Admin] View every notification sent to a specific email address")
    @GetMapping("/logs/by-recipient")
    public ResponseEntity<ApiResponse<List<NotificationLogResponse>>> getLogsByRecipient(@RequestParam String email) {
        List<NotificationLogResponse> response = notificationLogRepository.findByRecipientEmailOrderByCreatedAtDesc(email)
                .stream().map(notificationLogMapper::toResponse).toList();
        return ResponseEntity.ok(ApiResponse.success("Notification logs fetched successfully", response));
    }

    @Operation(summary = "[Admin] Get a single notification log by id")
    @GetMapping("/logs/{logId}")
    public ResponseEntity<ApiResponse<NotificationLogResponse>> getLogById(@PathVariable Long logId) {
        NotificationLog notificationLog = notificationLogRepository.findById(logId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification log not found with id: " + logId));
        return ResponseEntity.ok(ApiResponse.success("Notification log fetched successfully", notificationLogMapper.toResponse(notificationLog)));
    }
}
