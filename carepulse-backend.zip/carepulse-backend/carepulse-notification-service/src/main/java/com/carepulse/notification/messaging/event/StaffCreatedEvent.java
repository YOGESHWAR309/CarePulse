package com.carepulse.notification.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffCreatedEvent implements Serializable {
    private Long userId;
    private String recipientEmail;
    private String recipientName;
    private String role;
    private String temporaryPassword;
}
