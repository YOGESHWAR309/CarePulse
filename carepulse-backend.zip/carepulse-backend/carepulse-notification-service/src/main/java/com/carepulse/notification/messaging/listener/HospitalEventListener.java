package com.carepulse.notification.messaging.listener;

import com.carepulse.notification.config.RabbitMQConfig;
import com.carepulse.notification.enums.NotificationType;
import com.carepulse.notification.messaging.event.*;
import com.carepulse.notification.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/** Consumes every event published by Hospital Service. */
@Component
@RequiredArgsConstructor
@Slf4j
public class HospitalEventListener {

    private final EmailService emailService;

    /** Sends a confirmation to BOTH the patient and the doctor once a booking succeeds. */
    @RabbitListener(queues = RabbitMQConfig.APPOINTMENT_BOOKED_QUEUE)
    public void onAppointmentBooked(AppointmentBookedEvent event) {
        log.info("Received AppointmentBookedEvent id={}", event.getAppointmentId());

        String patientBody = String.format(
                "Hello %s,%n%nYour appointment with Dr. %s is confirmed for %s at %s.%n%n- CarePulse",
                event.getPatientName(), event.getDoctorName(), event.getAppointmentDate(), event.getStartTime());
        emailService.sendEmail(event.getPatientEmail(), "Appointment Confirmed", patientBody, NotificationType.APPOINTMENT_BOOKED);

        String doctorBody = String.format(
                "Hello Dr. %s,%n%nYou have a new appointment with %s on %s at %s.%n%n- CarePulse",
                event.getDoctorName(), event.getPatientName(), event.getAppointmentDate(), event.getStartTime());
        emailService.sendEmail(event.getDoctorEmail(), "New Appointment Booked", doctorBody, NotificationType.APPOINTMENT_BOOKED);
    }

    /** Sends a cancellation notice to both patient and doctor. */
    @RabbitListener(queues = RabbitMQConfig.APPOINTMENT_CANCELLED_QUEUE)
    public void onAppointmentCancelled(AppointmentCancelledEvent event) {
        log.info("Received AppointmentCancelledEvent id={}", event.getAppointmentId());

        String patientBody = String.format(
                "Hello %s,%n%nYour appointment with Dr. %s on %s at %s has been cancelled by %s.%n%n- CarePulse",
                event.getPatientName(), event.getDoctorName(), event.getAppointmentDate(), event.getStartTime(), event.getCancelledBy());
        emailService.sendEmail(event.getPatientEmail(), "Appointment Cancelled", patientBody, NotificationType.APPOINTMENT_CANCELLED);

        String doctorBody = String.format(
                "Hello Dr. %s,%n%nThe appointment with %s on %s at %s has been cancelled by %s.%n%n- CarePulse",
                event.getDoctorName(), event.getPatientName(), event.getAppointmentDate(), event.getStartTime(), event.getCancelledBy());
        emailService.sendEmail(event.getDoctorEmail(), "Appointment Cancelled", doctorBody, NotificationType.APPOINTMENT_CANCELLED);
    }

    /** Notifies the patient that a new prescription is available to view. */
    @RabbitListener(queues = RabbitMQConfig.PRESCRIPTION_GENERATED_QUEUE)
    public void onPrescriptionGenerated(PrescriptionGeneratedEvent event) {
        log.info("Received PrescriptionGeneratedEvent id={}", event.getPrescriptionId());

        String body = String.format(
                "Hello %s,%n%nDr. %s has written a new prescription for you. Please log in to CarePulse to view the details.%n%n- CarePulse",
                event.getPatientName(), event.getDoctorName());
        emailService.sendEmail(event.getPatientEmail(), "New Prescription Available", body, NotificationType.PRESCRIPTION_GENERATED);
    }

    /** Prompts the patient to pay a newly generated bill. */
    @RabbitListener(queues = RabbitMQConfig.BILL_GENERATED_QUEUE)
    public void onBillGenerated(BillGeneratedEvent event) {
        log.info("Received BillGeneratedEvent id={}", event.getBillId());

        String body = String.format(
                "Hello %s,%n%nA bill of %s (Invoice #%s) has been generated for your recent visit. " +
                        "Please log in to CarePulse to complete payment.%n%n- CarePulse",
                event.getPatientName(), event.getAmount(), event.getInvoiceNumber());
        emailService.sendEmail(event.getPatientEmail(), "New Bill Generated", body, NotificationType.BILL_GENERATED);
    }

    /** Confirms a successful payment. */
    @RabbitListener(queues = RabbitMQConfig.BILL_PAID_QUEUE)
    public void onBillPaid(BillPaidEvent event) {
        log.info("Received BillPaidEvent id={}", event.getBillId());

        String body = String.format(
                "Hello %s,%n%nWe've received your payment of %s for Invoice #%s (Payment ID: %s). Thank you!%n%n- CarePulse",
                event.getPatientName(), event.getAmountPaid(), event.getInvoiceNumber(), event.getRazorpayPaymentId());
        emailService.sendEmail(event.getPatientEmail(), "Payment Confirmed", body, NotificationType.BILL_PAID);
    }

    /** Notifies the patient their lab report is ready. */
    @RabbitListener(queues = RabbitMQConfig.LAB_REPORT_READY_QUEUE)
    public void onLabReportReady(LabReportReadyEvent event) {
        log.info("Received LabReportReadyEvent id={}", event.getReportId());

        String body = String.format(
                "Hello %s,%n%nYour lab report for '%s' is now ready. Please log in to CarePulse to view it.%n%n- CarePulse",
                event.getPatientName(), event.getTestName());
        emailService.sendEmail(event.getPatientEmail(), "Lab Report Ready", body, NotificationType.LAB_REPORT_READY);
    }

    /** Notifies the patient their radiology/scan report is ready. */
    @RabbitListener(queues = RabbitMQConfig.RADIOLOGY_REPORT_READY_QUEUE)
    public void onRadiologyReportReady(RadiologyReportReadyEvent event) {
        log.info("Received RadiologyReportReadyEvent id={}", event.getReportId());

        String body = String.format(
                "Hello %s,%n%nYour %s scan report is now ready. Please log in to CarePulse to view it.%n%n- CarePulse",
                event.getPatientName(), event.getScanType());
        emailService.sendEmail(event.getPatientEmail(), "Radiology Report Ready", body, NotificationType.RADIOLOGY_REPORT_READY);
    }
}
