package com.carepulse.notification.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SendOtpEvent implements Serializable {
    private String recipientEmail;
    private String recipientName;
    private String otpCode;
    private String purpose;
    private int validityMinutes;
}
