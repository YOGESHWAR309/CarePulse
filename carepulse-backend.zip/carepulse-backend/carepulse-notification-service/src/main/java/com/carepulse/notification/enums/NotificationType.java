package com.carepulse.notification.enums;

/** Every distinct kind of notification this service sends, one per RabbitMQ event type it consumes. */
public enum NotificationType {
    OTP,
    GENERIC_EMAIL,
    STAFF_CREATED,
    APPOINTMENT_BOOKED,
    APPOINTMENT_CANCELLED,
    PRESCRIPTION_GENERATED,
    BILL_GENERATED,
    BILL_PAID,
    LAB_REPORT_READY,
    RADIOLOGY_REPORT_READY
}
