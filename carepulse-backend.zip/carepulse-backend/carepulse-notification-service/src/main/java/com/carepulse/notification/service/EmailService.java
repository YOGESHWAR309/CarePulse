package com.carepulse.notification.service;

import com.carepulse.notification.enums.NotificationType;

/**
 * Single point through which every listener sends an actual email. Wraps
 * JavaMailSender so listeners don't need to know about MimeMessage/etc.,
 * and unconditionally records a {@link com.carepulse.notification.entity.NotificationLog}
 * row for every attempt regardless of success/failure.
 */
public interface EmailService {

    /**
     * Sends a plain-text email and logs the outcome. Never throws - a mail
     * server outage should not crash a RabbitMQ listener or cause endless
     * redelivery; failures are recorded in the notification log instead so
     * Admin can see and manually follow up on them.
     */
    void sendEmail(String recipientEmail, String subject, String body, NotificationType type);
}
