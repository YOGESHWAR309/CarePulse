package com.carepulse.notification.repository;

import com.carepulse.notification.entity.NotificationLog;
import com.carepulse.notification.enums.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationLogRepository extends JpaRepository<NotificationLog, Long> {

    /** Admin's "did this notification actually go out" troubleshooting screen, most recent first. */
    List<NotificationLog> findAllByOrderByCreatedAtDesc();

    /** Filters the log to just failures, so Admin can spot delivery problems quickly. */
    List<NotificationLog> findByStatusOrderByCreatedAtDesc(NotificationStatus status);

    List<NotificationLog> findByRecipientEmailOrderByCreatedAtDesc(String recipientEmail);
}
