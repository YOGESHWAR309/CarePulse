package com.carepulse.notification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * CarePulse - Notification Service
 * <p>
 * A pure event-driven consumer: listens on every RabbitMQ queue that Auth
 * Service and Hospital Service publish to, and sends the corresponding
 * email (OTP, appointment confirmation/cancellation, prescription/bill/
 * report-ready alerts, staff account credentials). Exposes only a small
 * Admin-only REST API for auditing what was sent - it never receives
 * synchronous calls from other services. Backed by its own
 * {@code notification_db} to persist the send/failure audit trail.
 */
@SpringBootApplication
@EnableDiscoveryClient
public class NotificationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
    }
}
