package com.carepulse.notification.service.impl;

import com.carepulse.notification.entity.NotificationLog;
import com.carepulse.notification.enums.NotificationStatus;
import com.carepulse.notification.enums.NotificationType;
import com.carepulse.notification.repository.NotificationLogRepository;
import com.carepulse.notification.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender javaMailSender;
    private final NotificationLogRepository notificationLogRepository;

    @Value("${spring.mail.username}")
    private String fromAddress;

    /**
     * Sends via {@link JavaMailSender} and always writes a
     * {@link NotificationLog} row - SENT on success, FAILED (with the
     * exception message) if the mail server rejects or is unreachable.
     * The exception is deliberately swallowed here rather than propagated,
     * so a single bad email doesn't crash the RabbitMQ listener that called
     * this or trigger infinite redelivery of the underlying message.
     */
    @Override
    @Transactional
    public void sendEmail(String recipientEmail, String subject, String body, NotificationType type) {
        NotificationLog.NotificationLogBuilder logBuilder = NotificationLog.builder()
                .recipientEmail(recipientEmail)
                .subject(subject)
                .type(type);

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromAddress);
            message.setTo(recipientEmail);
            message.setSubject(subject);
            message.setText(body);

            javaMailSender.send(message);

            notificationLogRepository.save(logBuilder.status(NotificationStatus.SENT).build());
            log.info("Email sent: to={} subject='{}' type={}", recipientEmail, subject, type);

        } catch (Exception ex) {
            notificationLogRepository.save(logBuilder
                    .status(NotificationStatus.FAILED)
                    .errorMessage(ex.getMessage())
                    .build());
            log.error("Email FAILED: to={} subject='{}' type={} error={}", recipientEmail, subject, type, ex.getMessage());
        }
    }
}
