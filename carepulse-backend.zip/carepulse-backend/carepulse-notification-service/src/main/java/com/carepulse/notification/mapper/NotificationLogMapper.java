package com.carepulse.notification.mapper;

import com.carepulse.notification.dto.response.NotificationLogResponse;
import com.carepulse.notification.entity.NotificationLog;
import org.springframework.stereotype.Component;

/**
 * Plain manual mapper (no MapStruct) - this entity has no nested
 * associations to resolve, so a generated mapper would add build
 * complexity for zero benefit over a one-line builder call.
 */
@Component
public class NotificationLogMapper {

    public NotificationLogResponse toResponse(NotificationLog log) {
        return NotificationLogResponse.builder()
                .id(log.getId())
                .recipientEmail(log.getRecipientEmail())
                .subject(log.getSubject())
                .type(log.getType())
                .status(log.getStatus())
                .errorMessage(log.getErrorMessage())
                .createdAt(log.getCreatedAt())
                .build();
    }
}
