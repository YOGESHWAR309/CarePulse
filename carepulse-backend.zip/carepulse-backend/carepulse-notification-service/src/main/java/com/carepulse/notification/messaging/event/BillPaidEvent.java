package com.carepulse.notification.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillPaidEvent implements Serializable {
    private Long billId;
    private String patientEmail;
    private String patientName;
    private BigDecimal amountPaid;
    private String invoiceNumber;
    private String razorpayPaymentId;
}
