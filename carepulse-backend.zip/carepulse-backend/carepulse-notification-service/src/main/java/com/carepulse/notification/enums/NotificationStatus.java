package com.carepulse.notification.enums;

public enum NotificationStatus {
    SENT,
    FAILED
}
