package com.carepulse.notification.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Notification Service is a pure CONSUMER - it never publishes anything
 * back to RabbitMQ. This config idempotently re-declares both topic
 * exchanges (Auth Service's and Hospital Service's) plus every queue this
 * service listens on, so Notification Service can be started before,
 * after, or independently of the services that publish to it with no
 * message loss.
 */
@Configuration
public class RabbitMQConfig {

    // ---- Auth Service's exchange ----
    public static final String NOTIFICATION_EXCHANGE = "carepulse.notification.exchange";

    public static final String OTP_QUEUE = "carepulse.notification.otp.queue";
    public static final String OTP_ROUTING_KEY = "notification.otp";

    public static final String EMAIL_QUEUE = "carepulse.notification.email.queue";
    public static final String EMAIL_ROUTING_KEY = "notification.email";

    public static final String STAFF_CREATED_QUEUE = "carepulse.notification.staff-created.queue";
    public static final String STAFF_CREATED_ROUTING_KEY = "notification.staff-created";

    // ---- Hospital Service's exchange ----
    public static final String HOSPITAL_EVENTS_EXCHANGE = "carepulse.hospital.events.exchange";

    public static final String APPOINTMENT_BOOKED_QUEUE = "carepulse.notification.appointment-booked.queue";
    public static final String APPOINTMENT_BOOKED_ROUTING_KEY = "hospital.appointment.booked";

    public static final String APPOINTMENT_CANCELLED_QUEUE = "carepulse.notification.appointment-cancelled.queue";
    public static final String APPOINTMENT_CANCELLED_ROUTING_KEY = "hospital.appointment.cancelled";

    public static final String PRESCRIPTION_GENERATED_QUEUE = "carepulse.notification.prescription-generated.queue";
    public static final String PRESCRIPTION_GENERATED_ROUTING_KEY = "hospital.prescription.generated";

    public static final String BILL_GENERATED_QUEUE = "carepulse.notification.bill-generated.queue";
    public static final String BILL_GENERATED_ROUTING_KEY = "hospital.bill.generated";

    public static final String BILL_PAID_QUEUE = "carepulse.notification.bill-paid.queue";
    public static final String BILL_PAID_ROUTING_KEY = "hospital.bill.paid";

    public static final String LAB_REPORT_READY_QUEUE = "carepulse.notification.lab-report-ready.queue";
    public static final String LAB_REPORT_READY_ROUTING_KEY = "hospital.lab-report.ready";

    public static final String RADIOLOGY_REPORT_READY_QUEUE = "carepulse.notification.radiology-report-ready.queue";
    public static final String RADIOLOGY_REPORT_READY_ROUTING_KEY = "hospital.radiology-report.ready";

    // ================= Exchanges =================

    @Bean
    public TopicExchange notificationExchange() {
        return new TopicExchange(NOTIFICATION_EXCHANGE, true, false);
    }

    @Bean
    public TopicExchange hospitalEventsExchange() {
        return new TopicExchange(HOSPITAL_EVENTS_EXCHANGE, true, false);
    }

    // ================= Queues + Bindings: Auth Service events =================

    @Bean
    public Queue otpQueue() {
        return new Queue(OTP_QUEUE, true);
    }

    @Bean
    public Binding otpBinding() {
        return BindingBuilder.bind(otpQueue()).to(notificationExchange()).with(OTP_ROUTING_KEY);
    }

    @Bean
    public Queue emailQueue() {
        return new Queue(EMAIL_QUEUE, true);
    }

    @Bean
    public Binding emailBinding() {
        return BindingBuilder.bind(emailQueue()).to(notificationExchange()).with(EMAIL_ROUTING_KEY);
    }

    @Bean
    public Queue staffCreatedQueue() {
        return new Queue(STAFF_CREATED_QUEUE, true);
    }

    @Bean
    public Binding staffCreatedBinding() {
        return BindingBuilder.bind(staffCreatedQueue()).to(notificationExchange()).with(STAFF_CREATED_ROUTING_KEY);
    }

    // ================= Queues + Bindings: Hospital Service events =================

    @Bean
    public Queue appointmentBookedQueue() {
        return new Queue(APPOINTMENT_BOOKED_QUEUE, true);
    }

    @Bean
    public Binding appointmentBookedBinding() {
        return BindingBuilder.bind(appointmentBookedQueue()).to(hospitalEventsExchange()).with(APPOINTMENT_BOOKED_ROUTING_KEY);
    }

    @Bean
    public Queue appointmentCancelledQueue() {
        return new Queue(APPOINTMENT_CANCELLED_QUEUE, true);
    }

    @Bean
    public Binding appointmentCancelledBinding() {
        return BindingBuilder.bind(appointmentCancelledQueue()).to(hospitalEventsExchange()).with(APPOINTMENT_CANCELLED_ROUTING_KEY);
    }

    @Bean
    public Queue prescriptionGeneratedQueue() {
        return new Queue(PRESCRIPTION_GENERATED_QUEUE, true);
    }

    @Bean
    public Binding prescriptionGeneratedBinding() {
        return BindingBuilder.bind(prescriptionGeneratedQueue()).to(hospitalEventsExchange()).with(PRESCRIPTION_GENERATED_ROUTING_KEY);
    }

    @Bean
    public Queue billGeneratedQueue() {
        return new Queue(BILL_GENERATED_QUEUE, true);
    }

    @Bean
    public Binding billGeneratedBinding() {
        return BindingBuilder.bind(billGeneratedQueue()).to(hospitalEventsExchange()).with(BILL_GENERATED_ROUTING_KEY);
    }

    @Bean
    public Queue billPaidQueue() {
        return new Queue(BILL_PAID_QUEUE, true);
    }

    @Bean
    public Binding billPaidBinding() {
        return BindingBuilder.bind(billPaidQueue()).to(hospitalEventsExchange()).with(BILL_PAID_ROUTING_KEY);
    }

    @Bean
    public Queue labReportReadyQueue() {
        return new Queue(LAB_REPORT_READY_QUEUE, true);
    }

    @Bean
    public Binding labReportReadyBinding() {
        return BindingBuilder.bind(labReportReadyQueue()).to(hospitalEventsExchange()).with(LAB_REPORT_READY_ROUTING_KEY);
    }

    @Bean
    public Queue radiologyReportReadyQueue() {
        return new Queue(RADIOLOGY_REPORT_READY_QUEUE, true);
    }

    @Bean
    public Binding radiologyReportReadyBinding() {
        return BindingBuilder.bind(radiologyReportReadyQueue()).to(hospitalEventsExchange()).with(RADIOLOGY_REPORT_READY_ROUTING_KEY);
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}
