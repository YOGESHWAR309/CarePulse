package com.carepulse.notification.messaging.listener;

import com.carepulse.notification.config.RabbitMQConfig;
import com.carepulse.notification.enums.NotificationType;
import com.carepulse.notification.messaging.event.SendEmailEvent;
import com.carepulse.notification.messaging.event.SendOtpEvent;
import com.carepulse.notification.messaging.event.StaffCreatedEvent;
import com.carepulse.notification.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/** Consumes every event published by Auth Service. */
@Component
@RequiredArgsConstructor
@Slf4j
public class AuthEventListener {

    private final EmailService emailService;

    /** Registration-verification OR password-reset OTP - the same event shape serves both, differentiated by {@code purpose}. */
    @RabbitListener(queues = RabbitMQConfig.OTP_QUEUE)
    public void onSendOtp(SendOtpEvent event) {
        log.info("Received SendOtpEvent for {} (purpose={})", event.getRecipientEmail(), event.getPurpose());

        String subject = "REGISTRATION".equals(event.getPurpose())
                ? "Verify your CarePulse account"
                : "Reset your CarePulse password";

        String body = String.format(
                "Hello %s,%n%nYour one-time password (OTP) is: %s%n%nThis code is valid for %d minutes. " +
                        "If you did not request this, please ignore this email.%n%n- CarePulse",
                event.getRecipientName(), event.getOtpCode(), event.getValidityMinutes());

        emailService.sendEmail(event.getRecipientEmail(), subject, body, NotificationType.OTP);
    }

    /** Generic transactional emails (e.g. password-changed confirmation). */
    @RabbitListener(queues = RabbitMQConfig.EMAIL_QUEUE)
    public void onSendEmail(SendEmailEvent event) {
        log.info("Received SendEmailEvent for {} (subject='{}')", event.getRecipientEmail(), event.getSubject());
        emailService.sendEmail(event.getRecipientEmail(), event.getSubject(), event.getBody(), NotificationType.GENERIC_EMAIL);
    }

    /** New staff account login credentials, emailed after Admin creates a Doctor/Receptionist/Pharmacist/etc. account. */
    @RabbitListener(queues = RabbitMQConfig.STAFF_CREATED_QUEUE)
    public void onStaffCreated(StaffCreatedEvent event) {
        log.info("Received StaffCreatedEvent for {} (role={})", event.getRecipientEmail(), event.getRole());

        String subject = "Your CarePulse staff account has been created";
        String body = String.format(
                "Hello %s,%n%nAn Admin has created a %s account for you on CarePulse.%n%n" +
                        "Login email: %s%nTemporary password: %s%n%n" +
                        "You will be required to change this password on your first login.%n%n- CarePulse",
                event.getRecipientName(), event.getRole(), event.getRecipientEmail(), event.getTemporaryPassword());

        emailService.sendEmail(event.getRecipientEmail(), subject, body, NotificationType.STAFF_CREATED);
    }
}
