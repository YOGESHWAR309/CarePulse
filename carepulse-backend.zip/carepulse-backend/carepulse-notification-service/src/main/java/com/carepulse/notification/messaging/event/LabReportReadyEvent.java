package com.carepulse.notification.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabReportReadyEvent implements Serializable {
    private Long reportId;
    private String patientEmail;
    private String patientName;
    private String testName;
}
