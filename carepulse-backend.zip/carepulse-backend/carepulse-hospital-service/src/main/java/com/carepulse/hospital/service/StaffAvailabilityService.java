package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateBulkStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.StaffAvailabilityResponse;
import com.carepulse.hospital.dto.response.StaffBulkAvailabilityResponse;

import java.time.LocalDate;
import java.util.List;

/** Dietician/Nutritionist-owned availability CRUD, mirroring {@link AvailabilityService} for Doctors. */
public interface StaffAvailabilityService {

    StaffAvailabilityResponse createAvailability(Long staffUserId, CreateStaffAvailabilityRequest request);

    /** Publishes availability across a date range in one call - mirrors {@link AvailabilityService#createBulkAvailability}. */
    StaffBulkAvailabilityResponse createBulkAvailability(Long staffUserId, CreateBulkStaffAvailabilityRequest request);

    StaffAvailabilityResponse updateAvailability(Long staffUserId, Long availabilityId, UpdateStaffAvailabilityRequest request);

    /** Toggles ACTIVE/INACTIVE only, without re-validating the rest of the block. */
    StaffAvailabilityResponse updateAvailabilityStatus(Long staffUserId, Long availabilityId, com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request);

    void deleteAvailability(Long staffUserId, Long availabilityId);

    List<StaffAvailabilityResponse> getMyAvailability(Long staffUserId);

    /** Patient-facing: every ACTIVE, future-dated block for a given Dietician/Nutritionist. */
    List<StaffAvailabilityResponse> getStaffAvailability(Long staffProfileId);

    /** Patient-facing: concrete bookable slots for one staff member on one specific date. */
    List<AvailableSlotResponse> getAvailableSlots(Long staffProfileId, LocalDate date);
}
