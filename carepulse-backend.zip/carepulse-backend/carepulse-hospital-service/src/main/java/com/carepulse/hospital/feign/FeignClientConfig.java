package com.carepulse.hospital.feign;

import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Attaches the shared {@code X-Internal-Api-Key} header to every outgoing
 * Feign call made by Hospital Service, satisfying
 * {@code com.carepulse.auth.config.InternalApiKeyFilter} on the Auth
 * Service side. Must be kept identical to Auth Service's {@code internal.api.key}.
 */
@Configuration
public class FeignClientConfig {

    @Value("${internal.api.key}")
    private String internalApiKey;

    @Bean
    public RequestInterceptor internalApiKeyInterceptor() {
        return requestTemplate -> requestTemplate.header("X-Internal-Api-Key", internalApiKey);
    }
}
