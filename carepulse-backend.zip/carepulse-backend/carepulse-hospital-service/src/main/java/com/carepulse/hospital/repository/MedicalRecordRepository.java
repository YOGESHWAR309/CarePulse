package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.MedicalRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Long> {

    Optional<MedicalRecord> findByAppointmentId(Long appointmentId);

    boolean existsByAppointmentId(Long appointmentId);

    /**
     * Patient's own "View Medical Records" screen, and a doctor's "View Patient Medical History".
     * Fetch-joins patient/doctor - MedicalRecordMapper reads patientName/doctorName per row.
     */
    @Query("SELECT m FROM MedicalRecord m JOIN FETCH m.patient JOIN FETCH m.doctor " +
            "WHERE m.patient.id = :patientId ORDER BY m.createdAt DESC")
    List<MedicalRecord> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);
}
