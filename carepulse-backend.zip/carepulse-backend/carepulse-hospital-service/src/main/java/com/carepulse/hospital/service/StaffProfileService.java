package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.UpdateStaffProfileRequest;
import com.carepulse.hospital.dto.response.StaffDirectoryResponse;
import com.carepulse.hospital.enums.UserRole;

import java.util.List;

/** Admin management of non-Doctor staff profiles (Receptionist, Pharmacist, Pathologist, Radiologist, Dietician, Nutritionist). */
public interface StaffProfileService {

    /** [Admin] Adds/edits qualification and department assignment - the counterpart to {@link DoctorService#updateDoctorProfile}. */
    StaffDirectoryResponse updateStaffProfile(Long staffProfileId, UpdateStaffProfileRequest request);

    StaffDirectoryResponse getStaffProfileById(Long staffProfileId);

    /** [Admin] Every staff member of a given role. */
    List<StaffDirectoryResponse> getStaffByRole(UserRole role);

    /** [Admin] Every non-doctor, non-patient staff member across all roles. */
    List<StaffDirectoryResponse> getAllStaff();
}
