package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/** Staff (Dietician/Nutritionist) counterpart to {@link BulkAvailabilityResponse}, which is typed for Doctor availability. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffBulkAvailabilityResponse {
    private int createdCount;
    private int skippedCount;
    private List<StaffAvailabilityResponse> created;
}
