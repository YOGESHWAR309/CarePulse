package com.carepulse.hospital.dto.request;

import com.carepulse.hospital.enums.Gender;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Payload for PUT /api/hospital/patients/me - fills in the clinical fields
 * (DOB, gender, blood group, address, emergency contact) that Auth Service's
 * registration form never collected. Name/email/phone stay owned by Auth
 * Service and are only ever refreshed here via events, not direct edits.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdatePatientProfileRequest {

    @Past(message = "Date of birth must be in the past")
    private LocalDate dateOfBirth;

    private Gender gender;

    @Size(max = 10, message = "Blood group must not exceed 10 characters")
    private String bloodGroup;

    @Size(max = 500, message = "Address must not exceed 500 characters")
    private String address;

    @Size(max = 100, message = "Emergency contact name must not exceed 100 characters")
    private String emergencyContactName;

    @Pattern(regexp = "^$|^[+]?[0-9]{10,15}$", message = "Emergency contact phone must be a valid 10-15 digit number")
    private String emergencyContactPhone;
}
