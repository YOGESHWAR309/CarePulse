package com.carepulse.hospital.config;

import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Provides a single shared {@link RazorpayClient} configured with the
 * TEST MODE key id/secret. Every Razorpay call (order creation, signature
 * verification) in Billing goes through this one client instance.
 */
@Configuration
@Slf4j
public class RazorpayConfig {

    @Value("${razorpay.key-id}")
    private String keyId;

    @Value("${razorpay.key-secret}")
    private String keySecret;

    @Bean
    public RazorpayClient razorpayClient() throws RazorpayException {
        log.info("Initializing Razorpay client in TEST MODE");
        return new RazorpayClient(keyId, keySecret);
    }
}
