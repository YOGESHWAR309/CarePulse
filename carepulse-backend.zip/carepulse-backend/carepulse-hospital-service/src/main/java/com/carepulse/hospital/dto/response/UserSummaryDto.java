package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Mirrors Auth Service's {@code UserSummaryResponse}, used only as the
 * deserialization target for {@link com.carepulse.hospital.feign.AuthServiceClient}
 * responses - never persisted or returned directly to Hospital Service's own callers.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSummaryDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private UserRole role;
    private boolean enabled;
    private boolean accountLocked;
}
