package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.DietPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DietPlanRepository extends JpaRepository<DietPlan, Long> {

    /** Patient's own "View Diet Plan" screen. Fetch-joins patient - DietPlanMapper reads patientName per row. */
    @Query("SELECT d FROM DietPlan d JOIN FETCH d.patient WHERE d.patient.id = :patientId ORDER BY d.createdAt DESC")
    List<DietPlan> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);

    boolean existsByConsultationAppointmentId(Long consultationAppointmentId);
}
