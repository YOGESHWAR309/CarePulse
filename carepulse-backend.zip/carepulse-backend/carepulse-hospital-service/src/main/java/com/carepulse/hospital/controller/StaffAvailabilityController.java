package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateBulkStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.StaffAvailabilityResponse;
import com.carepulse.hospital.dto.response.StaffBulkAvailabilityResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.StaffAvailabilityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Availability CRUD for Dietician/Nutritionist staff, plus the
 * patient-facing read side used during consultation booking. Mirrors
 * {@link AvailabilityController} for Doctors.
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Staff Availability", description = "Dietician/Nutritionist bookable time blocks and patient-facing slot lookup")
@SecurityRequirement(name = "bearerAuth")
public class StaffAvailabilityController {

    private final StaffAvailabilityService staffAvailabilityService;

    @Operation(summary = "[Dietician/Nutritionist] Publish a new availability block")
    @PostMapping("/staff/me/availability")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<StaffAvailabilityResponse>> createAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateStaffAvailabilityRequest request) {
        StaffAvailabilityResponse response = staffAvailabilityService.createAvailability(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Availability created successfully", response));
    }

    @Operation(summary = "[Dietician/Nutritionist] Publish availability across a date range in one call (e.g. a week or 15 days at once)")
    @PostMapping("/staff/me/availability/bulk")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<StaffBulkAvailabilityResponse>> createBulkAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateBulkStaffAvailabilityRequest request) {
        StaffBulkAvailabilityResponse response = staffAvailabilityService.createBulkAvailability(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success(
                response.getCreatedCount() + " availability block(s) created, " + response.getSkippedCount() + " skipped as duplicates",
                response));
    }

    @Operation(summary = "[Dietician/Nutritionist] Update my own availability block")
    @PutMapping("/staff/me/availability/{availabilityId}")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<StaffAvailabilityResponse>> updateAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId,
            @Valid @RequestBody UpdateStaffAvailabilityRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Availability updated successfully",
                staffAvailabilityService.updateAvailability(user.userId(), availabilityId, request)));
    }

    @Operation(summary = "[Dietician/Nutritionist] Toggle ACTIVE/INACTIVE on my own availability block, without touching its date/time/capacity")
    @PatchMapping("/staff/me/availability/{availabilityId}/status")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<StaffAvailabilityResponse>> updateAvailabilityStatus(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId,
            @Valid @RequestBody com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Availability status updated successfully",
                staffAvailabilityService.updateAvailabilityStatus(user.userId(), availabilityId, request)));
    }

    @Operation(summary = "[Dietician/Nutritionist] Delete my own availability block (only if it has no bookings)")
    @DeleteMapping("/staff/me/availability/{availabilityId}")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<Void>> deleteAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId) {
        staffAvailabilityService.deleteAvailability(user.userId(), availabilityId);
        return ResponseEntity.ok(ApiResponse.success("Availability deleted successfully"));
    }

    @Operation(summary = "[Dietician/Nutritionist] View my own availability (all blocks, any status)")
    @GetMapping("/staff/me/availability")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<List<StaffAvailabilityResponse>>> getMyAvailability(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Availability fetched successfully", staffAvailabilityService.getMyAvailability(user.userId())));
    }

    @Operation(summary = "View a specific Dietician/Nutritionist's published availability (patient booking flow)")
    @GetMapping("/staff/{staffProfileId}/availability")
    public ResponseEntity<ApiResponse<List<StaffAvailabilityResponse>>> getStaffAvailability(@PathVariable Long staffProfileId) {
        return ResponseEntity.ok(ApiResponse.success("Availability fetched successfully", staffAvailabilityService.getStaffAvailability(staffProfileId)));
    }

    @Operation(summary = "View concrete bookable slots for a Dietician/Nutritionist on a specific date")
    @GetMapping("/staff/{staffProfileId}/availability/slots")
    public ResponseEntity<ApiResponse<List<AvailableSlotResponse>>> getAvailableSlots(
            @PathVariable Long staffProfileId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(ApiResponse.success("Slots fetched successfully", staffAvailabilityService.getAvailableSlots(staffProfileId, date)));
    }
}
