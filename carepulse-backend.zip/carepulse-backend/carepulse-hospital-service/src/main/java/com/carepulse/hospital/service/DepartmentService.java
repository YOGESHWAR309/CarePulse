package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateDepartmentRequest;
import com.carepulse.hospital.dto.request.UpdateDepartmentRequest;
import com.carepulse.hospital.dto.response.DepartmentResponse;

import java.util.List;

/** Admin-managed hospital departments, and the read-only listing every other role (and the public) can browse. */
public interface DepartmentService {

    DepartmentResponse createDepartment(CreateDepartmentRequest request);

    DepartmentResponse updateDepartment(Long departmentId, UpdateDepartmentRequest request);

    /** Soft-deletes by flipping active=false rather than a hard delete, so doctors/history linked to it remain intact. */
    void deactivateDepartment(Long departmentId);

    DepartmentResponse getDepartmentById(Long departmentId);

    /** Every department regardless of active status - used by Admin's management screen. */
    List<DepartmentResponse> getAllDepartments();

    /** Only active departments - used by the patient-facing "View Departments" screen. */
    List<DepartmentResponse> getActiveDepartments();
}
