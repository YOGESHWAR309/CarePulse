package com.carepulse.hospital.messaging.listener;

import com.carepulse.hospital.config.RabbitMQConfig;
import com.carepulse.hospital.entity.Doctor;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.messaging.event.StaffCreatedEvent;
import com.carepulse.hospital.repository.DoctorRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * Consumes {@link StaffCreatedEvent} from Auth Service. Routes to one of
 * two tables depending on role:
 * <ul>
 *     <li>DOCTOR -> a {@link Doctor} row (department/specialization/fee are
 *     left null and filled in afterwards by Admin via a separate
 *     PUT /api/hospital/doctors/{id} call, since Auth Service's create-staff
 *     payload doesn't collect clinical fields)</li>
 *     <li>Everything else (RECEPTIONIST, PHARMACIST, PATHOLOGIST, RADIOLOGIST,
 *     DIETICIAN, NUTRITIONIST) -> a {@link StaffProfile} row</li>
 * </ul>
 * Idempotent per userId, same as {@link PatientRegisteredEventListener}.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class StaffCreatedEventListener {

    private final DoctorRepository doctorRepository;
    private final StaffProfileRepository staffProfileRepository;

    @RabbitListener(queues = RabbitMQConfig.HOSPITAL_STAFF_CREATED_QUEUE)
    public void onStaffCreated(StaffCreatedEvent event) {
        if (event.getRole() == UserRole.DOCTOR) {
            provisionDoctor(event);
        } else {
            provisionStaffProfile(event);
        }
    }

    private void provisionDoctor(StaffCreatedEvent event) {
        if (doctorRepository.existsByUserId(event.getUserId())) {
            log.info("Doctor profile already exists for userId={}, skipping duplicate event", event.getUserId());
            return;
        }

        Doctor doctor = Doctor.builder()
                .userId(event.getUserId())
                .fullName(event.getRecipientName())
                .email(event.getRecipientEmail())
                .qualification(event.getQualification())
                .specialization(event.getSpecialization())
                .active(true)
                .build();

        doctorRepository.save(doctor);
        log.info("Auto-provisioned Doctor profile for userId={} - awaiting Admin to set department/fee", event.getUserId());
    }

    private void provisionStaffProfile(StaffCreatedEvent event) {
        if (staffProfileRepository.existsByUserId(event.getUserId())) {
            log.info("Staff profile already exists for userId={}, skipping duplicate event", event.getUserId());
            return;
        }

        StaffProfile profile = StaffProfile.builder()
                .userId(event.getUserId())
                .fullName(event.getRecipientName())
                .email(event.getRecipientEmail())
                .role(event.getRole())
                .qualification(event.getQualification())
                .active(true)
                .build();

        staffProfileRepository.save(profile);
        log.info("Auto-provisioned StaffProfile for userId={} (role={})", event.getUserId(), event.getRole());
    }
}
