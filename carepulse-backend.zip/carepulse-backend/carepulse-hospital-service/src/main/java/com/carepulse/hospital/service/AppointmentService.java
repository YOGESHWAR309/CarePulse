package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.*;
import com.carepulse.hospital.dto.response.AppointmentResponse;

import java.time.LocalDate;
import java.util.List;

/**
 * The core booking workflow: Department -> Doctor -> Availability -> Slot
 * all converge here. Every write enforces ownership - a patient may only
 * touch their OWN appointments; Receptionist/Admin may act on any.
 */
public interface AppointmentService {

    /** [Patient] Books for themselves - patientId is resolved from the caller's own userId. */
    AppointmentResponse bookAppointment(Long patientUserId, BookAppointmentRequest request);

    /** [Receptionist] Books on behalf of an explicit patientId. */
    AppointmentResponse bookAppointmentForPatient(Long receptionistUserId, BookAppointmentForPatientRequest request);

    /** [Patient or Receptionist] Moves an existing appointment to a new slot; releases the old slot's booked-count and consumes the new one. */
    AppointmentResponse rescheduleAppointment(Long callerUserId, String callerRole, Long appointmentId, RescheduleAppointmentRequest request);

    /** [Patient or Receptionist] Cancels; releases the slot's booked-count back to the availability block. */
    AppointmentResponse cancelAppointment(Long callerUserId, String callerRole, Long appointmentId, CancelAppointmentRequest request);

    /** [Receptionist] Marks a patient as arrived for their appointment. */
    AppointmentResponse checkIn(Long appointmentId);

    /** [Receptionist] Marks a patient's visit as concluded (front-desk side, distinct from the doctor completing the consultation). */
    AppointmentResponse checkOut(Long appointmentId);

    /** [Doctor] Marks the clinical consultation itself as completed - required before a Bill can be generated. */
    AppointmentResponse completeConsultation(Long doctorUserId, Long appointmentId);

    AppointmentResponse getAppointmentById(Long appointmentId);

    /** [Patient] Own appointment history. */
    List<AppointmentResponse> getMyAppointments(Long patientUserId);

    /** [Doctor] Today's appointments. */
    List<AppointmentResponse> getDoctorTodayAppointments(Long doctorUserId);

    /** [Doctor] Upcoming (future, still-active) appointments. */
    List<AppointmentResponse> getDoctorUpcomingAppointments(Long doctorUserId);

    /** [Receptionist] Full day's queue across all doctors, for front-desk management. */
    List<AppointmentResponse> getAppointmentQueue(LocalDate date);
}
