package com.carepulse.hospital.dto.request;

import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/** Payload for PUT /api/hospital/doctors/me/availability/{id}. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAvailabilityRequest {

    @NotNull(message = "Available date is required")
    @FutureOrPresent(message = "Available date cannot be in the past")
    private LocalDate availableDate;

    @NotNull(message = "Start time is required")
    private LocalTime startTime;

    @NotNull(message = "End time is required")
    private LocalTime endTime;

    @NotNull(message = "Slot duration is required")
    @Min(value = 5, message = "Slot duration must be at least 5 minutes")
    private Integer slotDurationMinutes;

    @NotNull(message = "Maximum patients is required")
    @Min(value = 1, message = "Maximum patients must be at least 1")
    private Integer maximumPatients;

    @NotNull(message = "Consultation mode is required")
    private ConsultationMode consultationMode;

    @NotNull(message = "Status is required")
    private AvailabilityStatus status;
}
