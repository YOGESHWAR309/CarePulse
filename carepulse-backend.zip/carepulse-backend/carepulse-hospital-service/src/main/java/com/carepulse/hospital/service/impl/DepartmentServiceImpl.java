package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateDepartmentRequest;
import com.carepulse.hospital.dto.request.UpdateDepartmentRequest;
import com.carepulse.hospital.dto.response.DepartmentResponse;
import com.carepulse.hospital.entity.Department;
import com.carepulse.hospital.exception.DuplicateResourceException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.mapper.DepartmentMapper;
import com.carepulse.hospital.repository.DepartmentRepository;
import com.carepulse.hospital.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final DepartmentMapper departmentMapper;

    @Override
    @Transactional
    public DepartmentResponse createDepartment(CreateDepartmentRequest request) {
        if (departmentRepository.existsByNameIgnoreCase(request.getName())) {
            throw new DuplicateResourceException("A department named '" + request.getName() + "' already exists");
        }

        Department department = Department.builder()
                .name(request.getName())
                .description(request.getDescription())
                .active(true)
                .build();

        Department saved = departmentRepository.save(department);
        log.info("Department created: {}", saved.getName());
        return departmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public DepartmentResponse updateDepartment(Long departmentId, UpdateDepartmentRequest request) {
        Department department = findByIdOrThrow(departmentId);

        // Only re-check uniqueness if the name is actually changing.
        if (!department.getName().equalsIgnoreCase(request.getName())
                && departmentRepository.existsByNameIgnoreCase(request.getName())) {
            throw new DuplicateResourceException("A department named '" + request.getName() + "' already exists");
        }

        department.setName(request.getName());
        department.setDescription(request.getDescription());
        department.setActive(request.getActive());

        Department saved = departmentRepository.save(department);
        log.info("Department updated: {}", saved.getName());
        return departmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public void deactivateDepartment(Long departmentId) {
        Department department = findByIdOrThrow(departmentId);
        department.setActive(false);
        departmentRepository.save(department);
        log.info("Department deactivated: {}", department.getName());
    }

    @Override
    @Transactional(readOnly = true)
    public DepartmentResponse getDepartmentById(Long departmentId) {
        return departmentMapper.toResponse(findByIdOrThrow(departmentId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<DepartmentResponse> getAllDepartments() {
        return departmentRepository.findAll().stream().map(departmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<DepartmentResponse> getActiveDepartments() {
        return departmentRepository.findByActiveTrue().stream().map(departmentMapper::toResponse).toList();
    }

    private Department findByIdOrThrow(Long departmentId) {
        return departmentRepository.findById(departmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + departmentId));
    }
}
