package com.carepulse.hospital.enums;

/** Full lifecycle of a booked appointment, from booking through to billing. */
public enum AppointmentStatus {
    BOOKED,
    RESCHEDULED,
    CHECKED_IN,
    IN_CONSULTATION,
    COMPLETED,
    CANCELLED,
    NO_SHOW
}
