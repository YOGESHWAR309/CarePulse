package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for PUT /api/hospital/nutrition-plans/{id} - the owning Nutritionist amending their own plan. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateNutritionPlanRequest {

    @NotBlank(message = "Plan details are required")
    @Size(max = 3000, message = "Plan details must not exceed 3000 characters")
    private String planDetails;
}
