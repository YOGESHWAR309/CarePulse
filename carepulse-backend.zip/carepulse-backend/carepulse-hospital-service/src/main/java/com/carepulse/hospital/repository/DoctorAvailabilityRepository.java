package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.DoctorAvailability;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {

    /** A doctor's own "View Availability" screen - every block regardless of status. */
    List<DoctorAvailability> findByDoctorIdOrderByAvailableDateAscStartTimeAsc(Long doctorId);

    /**
     * Backs the patient booking flow: "system displays only the selected
     * doctor's published availability" - active blocks only, from today
     * forward, oldest first so the soonest slots appear at the top.
     */
    List<DoctorAvailability> findByDoctorIdAndStatusAndAvailableDateGreaterThanEqualOrderByAvailableDateAscStartTimeAsc(
            Long doctorId, com.carepulse.hospital.enums.AvailabilityStatus status, LocalDate fromDate);

    /** Same as above but further filtered to one specific date, once the patient picks a date. */
    List<DoctorAvailability> findByDoctorIdAndAvailableDateAndStatus(
            Long doctorId, LocalDate date, com.carepulse.hospital.enums.AvailabilityStatus status);

    /** Guards bulk publishing from creating a duplicate block if the doctor re-runs the same date range/time twice. */
    boolean existsByDoctorIdAndAvailableDateAndStartTimeAndEndTime(
            Long doctorId, LocalDate availableDate, java.time.LocalTime startTime, java.time.LocalTime endTime);
}
