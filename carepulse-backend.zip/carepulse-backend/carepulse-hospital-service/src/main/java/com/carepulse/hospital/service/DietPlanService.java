package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateDietPlanRequest;
import com.carepulse.hospital.dto.request.UpdateDietPlanRequest;
import com.carepulse.hospital.dto.response.DietPlanResponse;

import java.util.List;

public interface DietPlanService {

    /** [Dietician] Creates a diet plan for a patient. */
    DietPlanResponse createDietPlan(Long dieticianUserId, CreateDietPlanRequest request);

    /** [Dietician] Updates their own previously created plan. */
    DietPlanResponse updateDietPlan(Long dieticianUserId, Long dietPlanId, UpdateDietPlanRequest request);

    /** [Patient] Own diet plans. */
    List<DietPlanResponse> getMyDietPlans(Long patientUserId);

    /** [Dietician] Any patient's diet plan history, for context before writing a new one. */
    List<DietPlanResponse> getPatientDietPlans(Long patientId);
}
