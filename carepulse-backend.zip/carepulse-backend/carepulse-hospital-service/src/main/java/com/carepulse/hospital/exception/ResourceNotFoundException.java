package com.carepulse.hospital.exception;

/** Thrown when a lookup by id (department, doctor, patient, appointment, etc.) finds nothing - mapped to HTTP 404. */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
