package com.carepulse.hospital.enums;

/** Lifecycle of a prescription from being written by a doctor through to pharmacy dispensing. */
public enum PrescriptionStatus {
    PENDING,
    VERIFIED,
    DISPENSED,
    REJECTED
}
