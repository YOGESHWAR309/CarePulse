package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import com.carepulse.hospital.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultationAppointmentResponse {
    private Long id;
    private Long patientId;
    private String patientName;
    private Long staffProfileId;
    private String staffName;
    private UserRole staffRole;
    private LocalDate appointmentDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private ConsultationMode consultationMode;
    private AppointmentStatus status;
    private String reasonForVisit;
    private String cancelReason;
}
