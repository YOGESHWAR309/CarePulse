package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateDepartmentRequest;
import com.carepulse.hospital.dto.request.UpdateDepartmentRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.DepartmentResponse;
import com.carepulse.hospital.service.DepartmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Department management. Create/update/deactivate are Admin-only; listing
 * is available to any authenticated role (patients browsing departments
 * before picking a doctor, doctors/staff seeing their own department, etc.)
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Departments", description = "Hospital department management and browsing")
@SecurityRequirement(name = "bearerAuth")
public class DepartmentController {

    private final DepartmentService departmentService;

    @Operation(summary = "[Admin] Create a department")
    @PostMapping("/admin/departments")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<DepartmentResponse>> createDepartment(@Valid @RequestBody CreateDepartmentRequest request) {
        DepartmentResponse response = departmentService.createDepartment(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Department created successfully", response));
    }

    @Operation(summary = "[Admin] Update a department")
    @PutMapping("/admin/departments/{departmentId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<DepartmentResponse>> updateDepartment(
            @PathVariable Long departmentId, @Valid @RequestBody UpdateDepartmentRequest request) {
        DepartmentResponse response = departmentService.updateDepartment(departmentId, request);
        return ResponseEntity.ok(ApiResponse.success("Department updated successfully", response));
    }

    @Operation(summary = "[Admin] Deactivate a department (soft delete)")
    @DeleteMapping("/admin/departments/{departmentId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deactivateDepartment(@PathVariable Long departmentId) {
        departmentService.deactivateDepartment(departmentId);
        return ResponseEntity.ok(ApiResponse.success("Department deactivated successfully"));
    }

    @Operation(summary = "[Admin] View all departments (including inactive)")
    @GetMapping("/admin/departments")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<DepartmentResponse>>> getAllDepartments() {
        return ResponseEntity.ok(ApiResponse.success("Departments fetched successfully", departmentService.getAllDepartments()));
    }

    @Operation(summary = "Get a single department by id")
    @GetMapping("/departments/{departmentId}")
    public ResponseEntity<ApiResponse<DepartmentResponse>> getDepartmentById(@PathVariable Long departmentId) {
        return ResponseEntity.ok(ApiResponse.success("Department fetched successfully", departmentService.getDepartmentById(departmentId)));
    }

    @Operation(summary = "View all active departments (patient department-selection screen)")
    @GetMapping("/departments")
    public ResponseEntity<ApiResponse<List<DepartmentResponse>>> getActiveDepartments() {
        return ResponseEntity.ok(ApiResponse.success("Departments fetched successfully", departmentService.getActiveDepartments()));
    }
}
