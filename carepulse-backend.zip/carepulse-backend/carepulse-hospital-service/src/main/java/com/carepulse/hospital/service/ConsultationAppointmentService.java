package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.BookConsultationAppointmentRequest;
import com.carepulse.hospital.dto.request.CancelAppointmentRequest;
import com.carepulse.hospital.dto.response.ConsultationAppointmentResponse;

import java.time.LocalDate;
import java.util.List;

/** Patient bookings with Dietician/Nutritionist staff - the counterpart to {@link AppointmentService} for Doctor bookings. */
public interface ConsultationAppointmentService {

    /** [Patient] Books a consultation with a Dietician or Nutritionist. */
    ConsultationAppointmentResponse bookAppointment(Long patientUserId, BookConsultationAppointmentRequest request);

    /** [Patient] Cancels their own consultation; releases the slot's booked-count back to the availability block. */
    ConsultationAppointmentResponse cancelAppointment(Long patientUserId, Long appointmentId, CancelAppointmentRequest request);

    /** [Dietician/Nutritionist] Marks the consultation as completed - required before a plan can be written against it. */
    ConsultationAppointmentResponse completeConsultation(Long staffUserId, Long appointmentId);

    ConsultationAppointmentResponse getAppointmentById(Long appointmentId);

    /** [Patient] Own consultation history. */
    List<ConsultationAppointmentResponse> getMyAppointments(Long patientUserId);

    /** [Dietician/Nutritionist] Today's consultations. */
    List<ConsultationAppointmentResponse> getTodayAppointments(Long staffUserId);

    /** [Dietician/Nutritionist] Upcoming (future, still-active) consultations. */
    List<ConsultationAppointmentResponse> getUpcomingAppointments(Long staffUserId);
}
