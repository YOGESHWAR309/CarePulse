package com.carepulse.hospital.exception;

/**
 * Thrown when a role-permitted but OWNERSHIP-violating action is attempted -
 * e.g. a doctor trying to edit another doctor's availability, or a patient
 * trying to view someone else's medical record. Mapped to HTTP 403.
 * Distinct from Spring Security's AccessDeniedException, which covers
 * coarse role checks; this one covers the fine-grained "is this YOUR
 * resource" checks that live in the service layer.
 */
public class UnauthorizedActionException extends RuntimeException {
    public UnauthorizedActionException(String message) {
        super(message);
    }
}
