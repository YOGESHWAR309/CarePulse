package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateLabTestRequest;
import com.carepulse.hospital.dto.response.LabTestResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/** Doctor picks a Pathologist and orders a test -> that Pathologist collects sample -> uploads report -> marks ready. */
public interface LabTestService {

    /** [Doctor] Orders a lab test against a medical record they own, assigned to a specific (searched) Pathologist. */
    LabTestResponse createLabTestRequest(Long doctorUserId, CreateLabTestRequest request);

    /** [Pathologist] Marks a REQUESTED test as sample having been physically collected. Must be the assigned pathologist. */
    LabTestResponse collectSample(Long pathologistUserId, Long labTestId);

    /** [Pathologist] Attaches results + report PDF - moves status to IN_PROGRESS if not already past it. Must be the assigned pathologist. */
    LabTestResponse uploadReport(Long pathologistUserId, Long labTestId, String resultSummary, MultipartFile reportFile);

    /** [Pathologist] Finalizes the report as READY - fires LabReportReadyEvent so the patient is notified. */
    LabTestResponse markReportReady(Long pathologistUserId, Long labTestId);

    LabTestResponse getLabTestById(Long labTestId);

    /** [Pathologist] Their own work queue - REQUESTED/SAMPLE_COLLECTED/IN_PROGRESS tests assigned to them. */
    List<LabTestResponse> getRequestedLabTests(Long pathologistUserId);

    /** [Patient] Own lab reports. */
    List<LabTestResponse> getMyLabTests(Long patientUserId);

    /** [Doctor/Pathologist/Patient - ownership enforced internally] Downloads the uploaded report PDF's bytes. */
    ReportFileDownload getReportFile(Long userId, String role, Long labTestId);
}
