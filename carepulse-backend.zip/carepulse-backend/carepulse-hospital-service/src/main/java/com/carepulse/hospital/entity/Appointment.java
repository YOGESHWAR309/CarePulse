package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * A single booked appointment - the central record everything else in
 * Hospital Service hangs off of (Medical Records, Prescriptions, Bills all
 * reference back to the Appointment that generated them). Created by
 * either the patient themselves or a Receptionist on their behalf; the
 * discrete slot times are copied from the {@link DoctorAvailability} block
 * at booking time so later changes to that block don't retroactively alter
 * a patient's already-confirmed appointment time.
 */
@Entity
@Table(name = "appointments")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor;

    /** The availability block this slot was carved from - used to release capacity on cancel/reschedule. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "availability_id", nullable = false)
    private DoctorAvailability availability;

    @Column(nullable = false)
    private LocalDate appointmentDate;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private LocalTime endTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ConsultationMode consultationMode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private AppointmentStatus status = AppointmentStatus.BOOKED;

    @Column(length = 500)
    private String reasonForVisit;

    /** The userId who actually made the booking - the patient themselves, or a Receptionist acting on their behalf. */
    @Column(nullable = false)
    private Long bookedByUserId;

    private LocalDateTime checkedInAt;

    private LocalDateTime checkedOutAt;

    @Column(length = 30)
    private String cancelledByRole;

    @Column(length = 500)
    private String cancelReason;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
