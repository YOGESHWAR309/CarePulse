package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface BillRepository extends JpaRepository<Bill, Long> {

    Optional<Bill> findByAppointmentId(Long appointmentId);

    boolean existsByAppointmentId(Long appointmentId);

    /** Patient's own "Pay Bills" / billing history screen. Fetch-joins patient - BillMapper reads patientName per row. */
    @Query("SELECT b FROM Bill b JOIN FETCH b.patient WHERE b.patient.id = :patientId ORDER BY b.createdAt DESC")
    List<Bill> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);

    /**
     * Admin's "View All Bills" screen. Overrides the inherited findAll() with an
     * explicit fetch-join, since every row's patient is different (unlike the
     * per-patient/per-doctor scoped queries above where the L1 cache absorbs most
     * of the repeat lookups) - without this it's a straightforward N+1.
     */
    @Query("SELECT b FROM Bill b JOIN FETCH b.patient ORDER BY b.createdAt DESC")
    List<Bill> findAll();

    Optional<Bill> findByRazorpayOrderId(String razorpayOrderId);
}
