package com.carepulse.hospital.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * Validates JWTs issued by Auth Service. Hospital Service NEVER issues
 * tokens itself - it only verifies signature/expiry and reads the
 * embedded userId/role claims, using the exact same {@code jwt.secret}
 * configured in Auth Service and the API Gateway.
 */
@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secret;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /** Parses and verifies the token, throwing if it's malformed, expired, or has a bad signature. */
    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /** True if the token's signature checks out and it has not yet expired. */
    public boolean isTokenValid(String token) {
        try {
            Date expiration = extractAllClaims(token).getExpiration();
            return expiration.after(new Date());
        } catch (Exception ex) {
            return false;
        }
    }

    /** The user's email, stored as the JWT subject. */
    public String extractEmail(String token) {
        return extractAllClaims(token).getSubject();
    }

    /** The user's numeric id, embedded as a custom claim at token-issue time. */
    public Long extractUserId(String token) {
        String userId = extractAllClaims(token).get("userId", String.class);
        return userId == null ? null : Long.valueOf(userId);
    }

    /** The user's role (ADMIN, PATIENT, DOCTOR, ...), embedded as a custom claim. */
    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }
}
