package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * A patient's booked consultation with a non-Doctor clinical staff member
 * (Dietician or Nutritionist) - the counterpart to {@link Appointment} for
 * Doctor bookings. Kept as a separate entity/table rather than reusing
 * {@link Appointment} because Appointment's {@code doctor} field is
 * mandatory and deeply wired into Medical Records/Prescriptions/Billing,
 * none of which apply to a diet/nutrition consultation.
 * <p>
 * A {@link DietPlan} or {@link NutritionPlan} must now reference one of
 * these rather than an arbitrary patientId - the plan is evidence of an
 * actual consultation having taken place.
 */
@Entity
@Table(name = "consultation_appointments")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultationAppointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "staff_profile_id", nullable = false)
    private StaffProfile staffProfile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "availability_id", nullable = false)
    private StaffAvailability availability;

    @Column(nullable = false)
    private LocalDate appointmentDate;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private LocalTime endTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ConsultationMode consultationMode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private AppointmentStatus status = AppointmentStatus.BOOKED;

    @Column(length = 500)
    private String reasonForVisit;

    @Column(nullable = false)
    private Long bookedByUserId;

    @Column(length = 500)
    private String cancelReason;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
