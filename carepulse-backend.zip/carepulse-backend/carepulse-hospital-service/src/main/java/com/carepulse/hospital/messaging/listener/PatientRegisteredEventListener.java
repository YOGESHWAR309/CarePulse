package com.carepulse.hospital.messaging.listener;

import com.carepulse.hospital.config.RabbitMQConfig;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.messaging.event.PatientRegisteredEvent;
import com.carepulse.hospital.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * Consumes {@link PatientRegisteredEvent} from Auth Service and auto-creates
 * the matching clinical {@link Patient} profile row in {@code hospital_db}.
 * Idempotent - if a profile already exists for this userId (e.g. the
 * message got redelivered after a broker restart), it's skipped rather
 * than duplicated.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class PatientRegisteredEventListener {

    private final PatientRepository patientRepository;

    @RabbitListener(queues = RabbitMQConfig.HOSPITAL_PATIENT_REGISTERED_QUEUE)
    public void onPatientRegistered(PatientRegisteredEvent event) {
        if (patientRepository.existsByUserId(event.getUserId())) {
            log.info("Patient profile already exists for userId={}, skipping duplicate event", event.getUserId());
            return;
        }

        Patient patient = Patient.builder()
                .userId(event.getUserId())
                .fullName(event.getFirstName() + " " + event.getLastName())
                .email(event.getEmail())
                .phoneNumber(event.getPhoneNumber())
                .build();

        patientRepository.save(patient);
        log.info("Auto-provisioned Patient profile for userId={}", event.getUserId());
    }
}
