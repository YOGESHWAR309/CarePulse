package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateRadiologyRequest;
import com.carepulse.hospital.dto.request.UploadScanImageRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.RadiologyResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.RadiologyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Radiology", description = "Doctor-ordered scans, assigned to and worked through by a specific Radiologist")
@SecurityRequirement(name = "bearerAuth")
public class RadiologyController {

    private final RadiologyService radiologyService;

    @Operation(summary = "[Doctor] Order a radiology scan, assigned to a specific Radiologist")
    @PostMapping("/doctors/me/radiology")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<RadiologyResponse>> createRadiologyRequest(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateRadiologyRequest request) {
        RadiologyResponse response = radiologyService.createRadiologyRequest(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Scan requested successfully", response));
    }

    @Operation(summary = "[Radiologist] View scans assigned to me that are still open (REQUESTED/IN_PROGRESS)")
    @GetMapping("/radiology/scans/requested")
    @PreAuthorize("hasRole('RADIOLOGIST')")
    public ResponseEntity<ApiResponse<List<RadiologyResponse>>> getRequestedScans(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Requested scans fetched successfully", radiologyService.getRequestedScans(user.userId())));
    }

    @Operation(summary = "[Radiologist] Upload raw scan image(s)")
    @PutMapping("/radiology/scans/{radiologyId}/images")
    @PreAuthorize("hasRole('RADIOLOGIST')")
    public ResponseEntity<ApiResponse<RadiologyResponse>> uploadScanImages(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long radiologyId,
            @Valid @RequestBody UploadScanImageRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Scan images uploaded successfully", radiologyService.uploadScanImages(user.userId(), radiologyId, request)));
    }

    @Operation(summary = "[Radiologist] Upload the written radiology report as a PDF file")
    @PutMapping(value = "/radiology/scans/{radiologyId}/report", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('RADIOLOGIST')")
    public ResponseEntity<ApiResponse<RadiologyResponse>> uploadReport(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long radiologyId,
            @RequestParam("resultSummary") String resultSummary,
            @RequestPart("file") MultipartFile file) {
        return ResponseEntity.ok(ApiResponse.success("Radiology report uploaded successfully",
                radiologyService.uploadReport(user.userId(), radiologyId, resultSummary, file)));
    }

    @Operation(summary = "[Radiologist] Mark a radiology report as ready (notifies the patient)")
    @PutMapping("/radiology/scans/{radiologyId}/mark-ready")
    @PreAuthorize("hasRole('RADIOLOGIST')")
    public ResponseEntity<ApiResponse<RadiologyResponse>> markReportReady(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long radiologyId) {
        return ResponseEntity.ok(ApiResponse.success("Radiology report marked as ready", radiologyService.markReportReady(user.userId(), radiologyId)));
    }

    @Operation(summary = "Get a single radiology request by id")
    @GetMapping("/radiology-requests/{radiologyId}")
    public ResponseEntity<ApiResponse<RadiologyResponse>> getRadiologyRequestById(@PathVariable Long radiologyId) {
        return ResponseEntity.ok(ApiResponse.success("Radiology request fetched successfully", radiologyService.getRadiologyRequestById(radiologyId)));
    }

    @Operation(summary = "[Doctor/Radiologist/Patient] Download the uploaded radiology report PDF - access is limited to the assigned radiologist, the ordering doctor, or the owning patient")
    @GetMapping("/radiology-requests/{radiologyId}/report/file")
    public ResponseEntity<byte[]> downloadReportFile(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long radiologyId) {
        ReportFileDownload file = radiologyService.getReportFile(user.userId(), user.role(), radiologyId);
        MediaType mediaType = file.getContentType() != null ? MediaType.parseMediaType(file.getContentType()) : MediaType.APPLICATION_OCTET_STREAM;
        return ResponseEntity.ok()
                .contentType(mediaType)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFileName() + "\"")
                .body(file.getData());
    }

    @Operation(summary = "[Patient] View my own radiology reports")
    @GetMapping("/patients/me/radiology")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<RadiologyResponse>>> getMyRadiologyRequests(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Radiology reports fetched successfully", radiologyService.getMyRadiologyRequests(user.userId())));
    }
}
