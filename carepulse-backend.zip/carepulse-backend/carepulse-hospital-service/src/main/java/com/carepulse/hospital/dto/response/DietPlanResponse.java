package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DietPlanResponse {
    private Long id;
    private Long consultationAppointmentId;
    private Long patientId;
    private String patientName;
    private String dieticianName;
    private String planDetails;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
