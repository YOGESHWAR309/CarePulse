package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Summarizes the outcome of a bulk availability publish - how many blocks
 * were actually created plus the created blocks themselves, and how many
 * were skipped because an identical block already existed for that date.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkAvailabilityResponse {
    private int createdCount;
    private int skippedCount;
    private List<AvailabilityResponse> created;
}
