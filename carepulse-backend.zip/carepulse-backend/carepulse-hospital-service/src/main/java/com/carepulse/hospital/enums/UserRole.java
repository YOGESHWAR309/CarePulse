package com.carepulse.hospital.enums;

/**
 * Mirrors {@code com.carepulse.auth.enums.UserRole} from Auth Service.
 * Duplicated intentionally rather than shared via a common library module -
 * each microservice in this architecture owns its own copy of cross-cutting
 * enums so the two services can evolve independently without a shared JAR
 * dependency creating a deployment coupling between them.
 */
public enum UserRole {
    ADMIN, PATIENT, DOCTOR, RECEPTIONIST, PHARMACIST, PATHOLOGIST, RADIOLOGIST, DIETICIAN, NUTRITIONIST
}
