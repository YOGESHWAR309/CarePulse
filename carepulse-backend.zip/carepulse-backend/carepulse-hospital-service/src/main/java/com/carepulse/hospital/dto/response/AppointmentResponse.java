package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentResponse {
    private Long id;
    private Long patientId;
    private String patientName;
    private Long doctorId;
    private String doctorName;
    private String departmentName;
    private LocalDate appointmentDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private ConsultationMode consultationMode;
    private AppointmentStatus status;
    private String reasonForVisit;
    private LocalDateTime checkedInAt;
    private LocalDateTime checkedOutAt;
    private String cancelReason;
}
