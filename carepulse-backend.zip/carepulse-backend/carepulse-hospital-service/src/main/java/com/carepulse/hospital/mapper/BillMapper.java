package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.BillResponse;
import com.carepulse.hospital.entity.Bill;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BillMapper {

    @Mapping(target = "appointmentId", expression = "java(bill.getAppointment().getId())")
    @Mapping(target = "patientId", expression = "java(bill.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(bill.getPatient().getFullName())")
    BillResponse toResponse(Bill bill);
}
