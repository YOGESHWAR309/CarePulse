package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.PatientResponse;
import com.carepulse.hospital.entity.Patient;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PatientMapper {
    PatientResponse toResponse(Patient patient);
}
