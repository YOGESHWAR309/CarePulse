package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NutritionPlanResponse {
    private Long id;
    private Long consultationAppointmentId;
    private Long patientId;
    private String patientName;
    private String nutritionistName;
    private String planDetails;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
