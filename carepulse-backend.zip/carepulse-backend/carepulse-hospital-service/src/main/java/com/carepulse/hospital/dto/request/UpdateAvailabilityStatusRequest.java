package com.carepulse.hospital.dto.request;

import com.carepulse.hospital.enums.AvailabilityStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Payload for PATCH .../availability/{id}/status - toggling ACTIVE/INACTIVE
 * only. Deliberately separate from {@code UpdateAvailabilityRequest} /
 * {@code UpdateStaffAvailabilityRequest}: those carry a
 * {@code @FutureOrPresent} check on availableDate, which is correct when
 * actually editing a block's date, but wrongly blocks a simple status
 * toggle once the block's date has since passed (e.g. deactivating an old
 * block that already has bookings, or that just aged out).
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAvailabilityStatusRequest {

    @NotNull(message = "Status is required")
    private AvailabilityStatus status;
}
