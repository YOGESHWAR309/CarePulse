package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for POST /api/hospital/doctors/me/lab-tests - a doctor ordering a lab test during/after a consultation. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateLabTestRequest {

    @NotNull(message = "Medical record id is required")
    private Long medicalRecordId;

    @NotBlank(message = "Test name is required")
    @Size(max = 200, message = "Test name must not exceed 200 characters")
    private String testName;

    /** userId of the Pathologist to assign this test to - selected by the doctor from a name search (GET /doctors/me/staff/search). */
    @NotNull(message = "A pathologist must be selected")
    private Long pathologistId;
}
