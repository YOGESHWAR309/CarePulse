package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreatePrescriptionRequest;
import com.carepulse.hospital.dto.request.RejectPrescriptionRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.PrescriptionResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.PrescriptionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Prescriptions", description = "Doctor-written prescriptions and the Pharmacist verify/dispense workflow")
@SecurityRequirement(name = "bearerAuth")
public class PrescriptionController {

    private final PrescriptionService prescriptionService;

    @Operation(summary = "[Doctor] Write a prescription against a medical record")
    @PostMapping("/doctors/me/prescriptions")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<PrescriptionResponse>> createPrescription(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreatePrescriptionRequest request) {
        PrescriptionResponse response = prescriptionService.createPrescription(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Prescription created successfully", response));
    }

    @Operation(summary = "Get a single prescription by id")
    @GetMapping("/prescriptions/{prescriptionId}")
    public ResponseEntity<ApiResponse<PrescriptionResponse>> getPrescriptionById(@PathVariable Long prescriptionId) {
        return ResponseEntity.ok(ApiResponse.success("Prescription fetched successfully", prescriptionService.getPrescriptionById(prescriptionId)));
    }

    @Operation(summary = "[Patient] View my own prescriptions")
    @GetMapping("/patients/me/prescriptions")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<PrescriptionResponse>>> getMyPrescriptions(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Prescriptions fetched successfully", prescriptionService.getMyPrescriptions(user.userId())));
    }

    @Operation(summary = "[Pharmacist] View all pending prescriptions awaiting review")
    @GetMapping("/pharmacy/prescriptions/pending")
    @PreAuthorize("hasRole('PHARMACIST')")
    public ResponseEntity<ApiResponse<List<PrescriptionResponse>>> getPendingPrescriptions() {
        return ResponseEntity.ok(ApiResponse.success("Pending prescriptions fetched successfully", prescriptionService.getPendingPrescriptions()));
    }

    @Operation(summary = "[Pharmacist] Verify a prescription")
    @PutMapping("/pharmacy/prescriptions/{prescriptionId}/verify")
    @PreAuthorize("hasRole('PHARMACIST')")
    public ResponseEntity<ApiResponse<PrescriptionResponse>> verifyPrescription(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long prescriptionId) {
        return ResponseEntity.ok(ApiResponse.success("Prescription verified successfully", prescriptionService.verifyPrescription(user.userId(), prescriptionId)));
    }

    @Operation(summary = "[Pharmacist] Dispense a verified prescription")
    @PutMapping("/pharmacy/prescriptions/{prescriptionId}/dispense")
    @PreAuthorize("hasRole('PHARMACIST')")
    public ResponseEntity<ApiResponse<PrescriptionResponse>> dispensePrescription(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long prescriptionId) {
        return ResponseEntity.ok(ApiResponse.success("Prescription dispensed successfully", prescriptionService.dispensePrescription(user.userId(), prescriptionId)));
    }

    @Operation(summary = "[Pharmacist] Reject a prescription")
    @PutMapping("/pharmacy/prescriptions/{prescriptionId}/reject")
    @PreAuthorize("hasRole('PHARMACIST')")
    public ResponseEntity<ApiResponse<PrescriptionResponse>> rejectPrescription(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long prescriptionId,
            @Valid @RequestBody RejectPrescriptionRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Prescription rejected", prescriptionService.rejectPrescription(user.userId(), prescriptionId, request)));
    }
}
