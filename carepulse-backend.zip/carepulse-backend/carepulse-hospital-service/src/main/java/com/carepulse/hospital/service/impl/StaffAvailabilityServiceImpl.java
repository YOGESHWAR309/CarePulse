package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateBulkStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateStaffAvailabilityRequest;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.StaffAvailabilityResponse;
import com.carepulse.hospital.dto.response.StaffBulkAvailabilityResponse;
import com.carepulse.hospital.entity.StaffAvailability;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.StaffAvailabilityMapper;
import com.carepulse.hospital.repository.ConsultationAppointmentRepository;
import com.carepulse.hospital.repository.StaffAvailabilityRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.StaffAvailabilityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Mirrors {@link AvailabilityServiceImpl}'s logic exactly, but for {@link StaffProfile} (Dietician/Nutritionist) instead of Doctor. */
@Service
@RequiredArgsConstructor
@Slf4j
public class StaffAvailabilityServiceImpl implements StaffAvailabilityService {

    /**
     * Every status that means this exact clock-time slot is already spoken for and
     * must not be offered again - i.e. everything except CANCELLED. A COMPLETED
     * consultation still consumed that slot; only a CANCELLED one frees it back up.
     */
    private static final List<AppointmentStatus> SLOT_TAKEN_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN,
                    AppointmentStatus.IN_CONSULTATION, AppointmentStatus.COMPLETED, AppointmentStatus.NO_SHOW);

    private final StaffAvailabilityRepository availabilityRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final ConsultationAppointmentRepository appointmentRepository;
    private final StaffAvailabilityMapper availabilityMapper;

    @Override
    @Transactional
    public StaffAvailabilityResponse createAvailability(Long staffUserId, CreateStaffAvailabilityRequest request) {
        StaffProfile staffProfile = findStaffByUserId(staffUserId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        StaffAvailability availability = StaffAvailability.builder()
                .staffProfile(staffProfile)
                .availableDate(request.getAvailableDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .slotDurationMinutes(request.getSlotDurationMinutes())
                .maximumPatients(request.getMaximumPatients())
                .consultationMode(request.getConsultationMode())
                .status(AvailabilityStatus.ACTIVE)
                .bookedCount(0)
                .build();

        StaffAvailability saved = availabilityRepository.save(availability);
        log.info("Staff availability created for staffProfileId={} on {}", staffProfile.getId(), saved.getAvailableDate());
        return availabilityMapper.toResponse(saved);
    }

    /** Mirrors {@link AvailabilityServiceImpl#createBulkAvailability} exactly, scoped to a {@link StaffProfile}. */
    @Override
    @Transactional
    public StaffBulkAvailabilityResponse createBulkAvailability(Long staffUserId, CreateBulkStaffAvailabilityRequest request) {
        StaffProfile staffProfile = findStaffByUserId(staffUserId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        if (request.getEndDate().isBefore(request.getStartDate())) {
            throw new InvalidRequestException("End date cannot be before start date");
        }

        long spanDays = java.time.temporal.ChronoUnit.DAYS.between(request.getStartDate(), request.getEndDate()) + 1;
        if (spanDays > 60) {
            throw new InvalidRequestException("Bulk availability can be published for at most 60 days at a time");
        }

        List<StaffAvailabilityResponse> created = new ArrayList<>();
        int skipped = 0;

        for (LocalDate date = request.getStartDate(); !date.isAfter(request.getEndDate()); date = date.plusDays(1)) {
            if (!request.getDaysOfWeek().contains(date.getDayOfWeek())) {
                continue;
            }

            boolean duplicate = availabilityRepository.existsByStaffProfileIdAndAvailableDateAndStartTimeAndEndTime(
                    staffProfile.getId(), date, request.getStartTime(), request.getEndTime());

            if (duplicate) {
                skipped++;
                continue;
            }

            StaffAvailability availability = StaffAvailability.builder()
                    .staffProfile(staffProfile)
                    .availableDate(date)
                    .startTime(request.getStartTime())
                    .endTime(request.getEndTime())
                    .slotDurationMinutes(request.getSlotDurationMinutes())
                    .maximumPatients(request.getMaximumPatients())
                    .consultationMode(request.getConsultationMode())
                    .status(AvailabilityStatus.ACTIVE)
                    .bookedCount(0)
                    .build();

            StaffAvailability saved = availabilityRepository.save(availability);
            created.add(availabilityMapper.toResponse(saved));
        }

        log.info("Bulk availability published for staffProfileId={}: created={} skipped={} range={}..{}",
                staffProfile.getId(), created.size(), skipped, request.getStartDate(), request.getEndDate());

        return StaffBulkAvailabilityResponse.builder()
                .createdCount(created.size())
                .skippedCount(skipped)
                .created(created)
                .build();
    }

    @Override
    @Transactional
    public StaffAvailabilityResponse updateAvailability(Long staffUserId, Long availabilityId, UpdateStaffAvailabilityRequest request) {
        StaffAvailability availability = findOwnedAvailabilityOrThrow(staffUserId, availabilityId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        if (request.getMaximumPatients() < availability.getBookedCount()) {
            throw new InvalidRequestException(
                    "Cannot set maximum patients below the number already booked (" + availability.getBookedCount() + ")");
        }

        availability.setAvailableDate(request.getAvailableDate());
        availability.setStartTime(request.getStartTime());
        availability.setEndTime(request.getEndTime());
        availability.setSlotDurationMinutes(request.getSlotDurationMinutes());
        availability.setMaximumPatients(request.getMaximumPatients());
        availability.setConsultationMode(request.getConsultationMode());
        availability.setStatus(request.getStatus());

        StaffAvailability saved = availabilityRepository.save(availability);
        log.info("Staff availability updated: id={}", saved.getId());
        return availabilityMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public StaffAvailabilityResponse updateAvailabilityStatus(
            Long staffUserId, Long availabilityId, com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request) {
        StaffAvailability availability = findOwnedAvailabilityOrThrow(staffUserId, availabilityId);
        availability.setStatus(request.getStatus());
        StaffAvailability saved = availabilityRepository.save(availability);
        log.info("Staff availability status updated: id={} status={}", saved.getId(), saved.getStatus());
        return availabilityMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public void deleteAvailability(Long staffUserId, Long availabilityId) {
        StaffAvailability availability = findOwnedAvailabilityOrThrow(staffUserId, availabilityId);

        if (availability.getBookedCount() > 0) {
            throw new InvalidRequestException(
                    "Cannot delete availability with existing bookings. Set it to INACTIVE instead to stop new bookings.");
        }

        availabilityRepository.delete(availability);
        log.info("Staff availability deleted: id={}", availabilityId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<StaffAvailabilityResponse> getMyAvailability(Long staffUserId) {
        StaffProfile staffProfile = findStaffByUserId(staffUserId);
        return availabilityRepository.findByStaffProfileIdOrderByAvailableDateAscStartTimeAsc(staffProfile.getId())
                .stream().map(availabilityMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<StaffAvailabilityResponse> getStaffAvailability(Long staffProfileId) {
        return availabilityRepository
                .findByStaffProfileIdAndStatusAndAvailableDateGreaterThanEqualOrderByAvailableDateAscStartTimeAsc(
                        staffProfileId, AvailabilityStatus.ACTIVE, LocalDate.now())
                .stream().map(availabilityMapper::toResponse).toList();
    }

    /**
     * Mirrors {@link AvailabilityServiceImpl#getAvailableSlots}: block-level capacity
     * (bookedCount < maximumPatients) is necessary but not sufficient, since with
     * maximumPatients > 1 a specific clock time can already be taken while the block's
     * aggregate count is still under the cap. Each slot is additionally excluded if its
     * exact start time already has an active consultation against this block.
     */
    @Override
    @Transactional(readOnly = true)
    public List<AvailableSlotResponse> getAvailableSlots(Long staffProfileId, LocalDate date) {
        List<StaffAvailability> blocks = availabilityRepository
                .findByStaffProfileIdAndAvailableDateAndStatus(staffProfileId, date, AvailabilityStatus.ACTIVE);

        List<AvailableSlotResponse> slots = new ArrayList<>();

        for (StaffAvailability block : blocks) {
            boolean blockBookable = block.getBookedCount() < block.getMaximumPatients();
            Set<LocalTime> takenStartTimes = new HashSet<>(
                    appointmentRepository.findBookedStartTimesByAvailabilityId(block.getId(), SLOT_TAKEN_STATUSES));
            LocalTime cursor = block.getStartTime();

            while (cursor.plusMinutes(block.getSlotDurationMinutes()).compareTo(block.getEndTime()) <= 0) {
                LocalTime slotEnd = cursor.plusMinutes(block.getSlotDurationMinutes());
                boolean slotBookable = blockBookable && !takenStartTimes.contains(cursor);

                slots.add(AvailableSlotResponse.builder()
                        .availabilityId(block.getId())
                        .availableDate(block.getAvailableDate())
                        .slotStartTime(cursor)
                        .slotEndTime(slotEnd)
                        .consultationMode(block.getConsultationMode())
                        .bookable(slotBookable)
                        .build());

                cursor = slotEnd;
            }
        }

        return slots;
    }

    private StaffProfile findStaffByUserId(Long userId) {
        return staffProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff profile not found for the logged-in user"));
    }

    private StaffAvailability findOwnedAvailabilityOrThrow(Long staffUserId, Long availabilityId) {
        StaffAvailability availability = availabilityRepository.findById(availabilityId)
                .orElseThrow(() -> new ResourceNotFoundException("Availability not found with id: " + availabilityId));

        if (!availability.getStaffProfile().getUserId().equals(staffUserId)) {
            throw new UnauthorizedActionException("You can only manage your own availability");
        }

        return availability;
    }

    private void validateTimeRange(LocalTime start, LocalTime end) {
        if (!start.isBefore(end)) {
            throw new InvalidRequestException("Start time must be before end time");
        }
    }
}
