package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.BillStatus;
import com.carepulse.hospital.enums.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillResponse {
    private Long id;
    private Long appointmentId;
    private Long patientId;
    private String patientName;
    private BigDecimal amount;
    private String invoiceNumber;
    private BillStatus status;
    private String razorpayOrderId;
    private String razorpayPaymentId;
    private PaymentMethod paymentMethod;
    private LocalDateTime paidAt;
    private LocalDateTime createdAt;
}
