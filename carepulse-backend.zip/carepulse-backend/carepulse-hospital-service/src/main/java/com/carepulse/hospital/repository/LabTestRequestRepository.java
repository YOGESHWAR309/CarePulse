package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.LabTestRequest;
import com.carepulse.hospital.enums.ReportStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LabTestRequestRepository extends JpaRepository<LabTestRequest, Long> {

    /**
     * Pathologist's "View Lab Requests" queue - only requests assigned to THEM (assignment is
     * chosen by the ordering doctor at creation time) that are still open work (not yet READY).
     * Fetch-joins patient/requestingDoctor - LabTestMapper reads both per row.
     */
    @Query("SELECT l FROM LabTestRequest l JOIN FETCH l.patient JOIN FETCH l.requestingDoctor " +
            "WHERE l.assignedPathologistUserId = :pathologistUserId AND l.status IN :statuses ORDER BY l.createdAt ASC")
    List<LabTestRequest> findByAssignedPathologistAndStatusIn(
            @Param("pathologistUserId") Long pathologistUserId, @Param("statuses") List<ReportStatus> statuses);

    /** Patient's "View Lab Reports" screen. */
    @Query("SELECT l FROM LabTestRequest l JOIN FETCH l.patient JOIN FETCH l.requestingDoctor " +
            "WHERE l.patient.id = :patientId ORDER BY l.createdAt DESC")
    List<LabTestRequest> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);
}
