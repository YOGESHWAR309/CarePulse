package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/** Payload for POST /api/hospital/receptionist/appointments - identical to {@link BookAppointmentRequest} plus an explicit patientId, since the caller is staff booking on someone else's behalf. */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BookAppointmentForPatientRequest extends BookAppointmentRequest {

    @NotNull(message = "Patient id is required")
    private Long patientId;
}
