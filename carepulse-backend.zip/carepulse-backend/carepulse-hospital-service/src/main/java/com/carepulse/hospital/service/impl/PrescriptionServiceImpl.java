package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreatePrescriptionRequest;
import com.carepulse.hospital.dto.request.PrescriptionItemRequest;
import com.carepulse.hospital.dto.request.RejectPrescriptionRequest;
import com.carepulse.hospital.dto.response.PrescriptionResponse;
import com.carepulse.hospital.entity.MedicalRecord;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.entity.Prescription;
import com.carepulse.hospital.entity.PrescriptionItem;
import com.carepulse.hospital.enums.PrescriptionStatus;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.PrescriptionMapper;
import com.carepulse.hospital.messaging.NotificationEventPublisher;
import com.carepulse.hospital.messaging.event.PrescriptionGeneratedEvent;
import com.carepulse.hospital.repository.MedicalRecordRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.PrescriptionRepository;
import com.carepulse.hospital.service.PrescriptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrescriptionServiceImpl implements PrescriptionService {

    private final PrescriptionRepository prescriptionRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;
    private final PrescriptionMapper prescriptionMapper;
    private final NotificationEventPublisher notificationEventPublisher;

    @Override
    @Transactional
    public PrescriptionResponse createPrescription(Long doctorUserId, CreatePrescriptionRequest request) {
        MedicalRecord medicalRecord = medicalRecordRepository.findById(request.getMedicalRecordId())
                .orElseThrow(() -> new ResourceNotFoundException("Medical record not found with id: " + request.getMedicalRecordId()));

        if (!medicalRecord.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only write prescriptions against your own medical records");
        }

        Prescription prescription = Prescription.builder()
                .medicalRecord(medicalRecord)
                .patient(medicalRecord.getPatient())
                .doctor(medicalRecord.getDoctor())
                .status(PrescriptionStatus.PENDING)
                .build();

        for (PrescriptionItemRequest itemRequest : request.getItems()) {
            PrescriptionItem item = PrescriptionItem.builder()
                    .prescription(prescription)
                    .medicineName(itemRequest.getMedicineName())
                    .dosage(itemRequest.getDosage())
                    .frequency(itemRequest.getFrequency())
                    .durationDays(itemRequest.getDurationDays())
                    .instructions(itemRequest.getInstructions())
                    .build();
            prescription.getItems().add(item);
        }

        Prescription saved = prescriptionRepository.save(prescription);

        notificationEventPublisher.publishPrescriptionGenerated(
                PrescriptionGeneratedEvent.builder()
                        .prescriptionId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .doctorName(saved.getDoctor().getFullName())
                        .build());

        log.info("Prescription created: id={} for patient={}", saved.getId(), saved.getPatient().getFullName());
        return prescriptionMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public PrescriptionResponse getPrescriptionById(Long prescriptionId) {
        return prescriptionMapper.toResponse(findByIdOrThrow(prescriptionId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<PrescriptionResponse> getMyPrescriptions(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return prescriptionRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(prescriptionMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PrescriptionResponse> getPendingPrescriptions() {
        return prescriptionRepository.findByStatusOrderByCreatedAtAsc(PrescriptionStatus.PENDING)
                .stream().map(prescriptionMapper::toResponse).toList();
    }

    @Override
    @Transactional
    public PrescriptionResponse verifyPrescription(Long pharmacistUserId, Long prescriptionId) {
        Prescription prescription = findByIdOrThrow(prescriptionId);

        if (prescription.getStatus() != PrescriptionStatus.PENDING) {
            throw new InvalidRequestException("Only PENDING prescriptions can be verified");
        }

        prescription.setStatus(PrescriptionStatus.VERIFIED);
        prescription.setProcessedByUserId(pharmacistUserId);
        prescription.setVerifiedAt(LocalDateTime.now());

        Prescription saved = prescriptionRepository.save(prescription);
        log.info("Prescription verified: id={}", saved.getId());
        return prescriptionMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public PrescriptionResponse dispensePrescription(Long pharmacistUserId, Long prescriptionId) {
        Prescription prescription = findByIdOrThrow(prescriptionId);

        if (prescription.getStatus() != PrescriptionStatus.VERIFIED) {
            throw new InvalidRequestException("Only VERIFIED prescriptions can be dispensed");
        }

        prescription.setStatus(PrescriptionStatus.DISPENSED);
        prescription.setProcessedByUserId(pharmacistUserId);
        prescription.setDispensedAt(LocalDateTime.now());

        Prescription saved = prescriptionRepository.save(prescription);
        log.info("Prescription dispensed: id={}", saved.getId());
        return prescriptionMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public PrescriptionResponse rejectPrescription(Long pharmacistUserId, Long prescriptionId, RejectPrescriptionRequest request) {
        Prescription prescription = findByIdOrThrow(prescriptionId);

        if (prescription.getStatus() == PrescriptionStatus.DISPENSED) {
            throw new InvalidRequestException("A prescription that has already been dispensed cannot be rejected");
        }

        prescription.setStatus(PrescriptionStatus.REJECTED);
        prescription.setProcessedByUserId(pharmacistUserId);
        prescription.setRejectionReason(request.getReason());

        Prescription saved = prescriptionRepository.save(prescription);
        log.info("Prescription rejected: id={} reason={}", saved.getId(), request.getReason());
        return prescriptionMapper.toResponse(saved);
    }

    private Prescription findByIdOrThrow(Long prescriptionId) {
        return prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found with id: " + prescriptionId));
    }
}
