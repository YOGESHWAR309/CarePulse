package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Carries an uploaded report PDF's bytes + metadata from the service layer to a controller's binary download endpoint. */
@Getter
@AllArgsConstructor
public class ReportFileDownload {
    private final byte[] data;
    private final String fileName;
    private final String contentType;
}
