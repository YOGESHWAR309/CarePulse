package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.Gender;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Clinical profile for a patient, auto-created the moment
 * {@link com.carepulse.hospital.messaging.listener.PatientRegisteredEventListener}
 * consumes a PatientRegisteredEvent from Auth Service. Extended clinical
 * fields (blood group, DOB, address) are filled in later via the patient's
 * own profile-update screen since they aren't collected at registration time.
 */
@Entity
@Table(name = "patients", uniqueConstraints = {
        @UniqueConstraint(name = "uk_patient_user_id", columnNames = "user_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nullable: a self-registered patient always has one (linked via
     * PatientRegisteredEvent). A walk-in patient registered directly by a
     * Receptionist may not have a login account yet - this stays null until/
     * unless they later self-register with the same email, at which point
     * the walk-in record should be reconciled by an Admin (manual merge,
     * out of scope for this build).
     */
    @Column(name = "user_id", unique = true)
    private Long userId;

    /** Denormalized from Auth Service at registration time, refreshed if the patient updates their Auth profile. */
    @Column(nullable = false, length = 200)
    private String fullName;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(length = 15)
    private String phoneNumber;

    private LocalDate dateOfBirth;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Gender gender;

    @Column(length = 10)
    private String bloodGroup;

    @Column(length = 500)
    private String address;

    @Column(length = 100)
    private String emergencyContactName;

    @Column(length = 15)
    private String emergencyContactPhone;

    /** True if this profile was created by a Receptionist's walk-in registration rather than via patient self-registration + PatientRegisteredEvent. */
    @Column(nullable = false)
    @Builder.Default
    private boolean walkIn = false;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
