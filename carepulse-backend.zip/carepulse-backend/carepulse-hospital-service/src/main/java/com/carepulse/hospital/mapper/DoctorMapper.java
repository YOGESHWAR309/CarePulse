package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.DoctorResponse;
import com.carepulse.hospital.entity.Doctor;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DoctorMapper {

    @Mapping(target = "departmentId", expression = "java(doctor.getDepartment() != null ? doctor.getDepartment().getId() : null)")
    @Mapping(target = "departmentName", expression = "java(doctor.getDepartment() != null ? doctor.getDepartment().getName() : null)")
    DoctorResponse toResponse(Doctor doctor);
}
