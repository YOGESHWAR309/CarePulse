package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.UserRole;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Lightweight clinical/operational profile for every staff role EXCEPT
 * Doctor - Receptionist, Pharmacist, Pathologist, Radiologist, Dietician,
 * Nutritionist. These roles don't need Doctor's richer fields (specialization,
 * fee, availability), so one shared table avoids five nearly-identical ones.
 * Auto-created by {@link com.carepulse.hospital.messaging.listener.StaffCreatedEventListener}.
 */
@Entity
@Table(name = "staff_profiles", uniqueConstraints = {
        @UniqueConstraint(name = "uk_staff_user_id", columnNames = "user_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;

    @Column(nullable = false, length = 200)
    private String fullName;

    @Column(nullable = false, length = 150)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private UserRole role;

    /** Education/qualification (e.g. "B.Pharm", "B.Sc Nursing") - captured at creation time via CreateStaffRequest, editable later. */
    @Column(length = 200)
    private String qualification;

    /** Optional - e.g. a Receptionist or Pharmacist may be assigned to a specific department's front desk/counter. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
