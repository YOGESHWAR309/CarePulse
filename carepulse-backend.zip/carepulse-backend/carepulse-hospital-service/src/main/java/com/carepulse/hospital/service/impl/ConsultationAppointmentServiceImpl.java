package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.BookConsultationAppointmentRequest;
import com.carepulse.hospital.dto.request.CancelAppointmentRequest;
import com.carepulse.hospital.dto.response.ConsultationAppointmentResponse;
import com.carepulse.hospital.entity.ConsultationAppointment;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.entity.StaffAvailability;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.ConsultationAppointmentMapper;
import com.carepulse.hospital.repository.ConsultationAppointmentRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.StaffAvailabilityRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.ConsultationAppointmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/** Mirrors {@link AppointmentServiceImpl}'s booking/slot-capacity mechanics, scoped to Dietician/Nutritionist consultations. */
@Service
@RequiredArgsConstructor
@Slf4j
public class ConsultationAppointmentServiceImpl implements ConsultationAppointmentService {

    private static final List<AppointmentStatus> ACTIVE_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED);

    /**
     * Every status that means an exact clock-time slot is already spoken for -
     * everything except CANCELLED. Deliberately broader than ACTIVE_STATUSES above
     * (which only governs what the patient can still cancel): a COMPLETED
     * consultation can no longer be cancelled, but it still consumed that slot, so
     * it must keep blocking new bookings against the same time.
     */
    private static final List<AppointmentStatus> SLOT_TAKEN_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN,
                    AppointmentStatus.IN_CONSULTATION, AppointmentStatus.COMPLETED, AppointmentStatus.NO_SHOW);

    private final ConsultationAppointmentRepository appointmentRepository;
    private final StaffAvailabilityRepository availabilityRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final PatientRepository patientRepository;
    private final ConsultationAppointmentMapper appointmentMapper;

    @Override
    @Transactional
    public ConsultationAppointmentResponse bookAppointment(Long patientUserId, BookConsultationAppointmentRequest request) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));

        StaffProfile staffProfile = staffProfileRepository.findById(request.getStaffProfileId())
                .orElseThrow(() -> new ResourceNotFoundException("Staff member not found with id: " + request.getStaffProfileId()));

        StaffAvailability availability = availabilityRepository.findById(request.getAvailabilityId())
                .orElseThrow(() -> new ResourceNotFoundException("Availability not found with id: " + request.getAvailabilityId()));

        if (availability.getStatus() != AvailabilityStatus.ACTIVE) {
            throw new InvalidRequestException("This availability slot is no longer open for booking");
        }

        if (availability.getBookedCount() >= availability.getMaximumPatients()) {
            throw new InvalidRequestException("This slot is fully booked. Please choose a different time.");
        }

        boolean slotAlreadyTaken = appointmentRepository
                .findBookedStartTimesByAvailabilityId(availability.getId(), SLOT_TAKEN_STATUSES)
                .contains(request.getSlotStartTime());
        if (slotAlreadyTaken) {
            throw new InvalidRequestException("This slot has just been booked by someone else. Please choose a different time.");
        }

        var slotEnd = request.getSlotStartTime().plusMinutes(availability.getSlotDurationMinutes());

        ConsultationAppointment appointment = ConsultationAppointment.builder()
                .patient(patient)
                .staffProfile(staffProfile)
                .availability(availability)
                .appointmentDate(request.getAppointmentDate())
                .startTime(request.getSlotStartTime())
                .endTime(slotEnd)
                .consultationMode(availability.getConsultationMode())
                .status(AppointmentStatus.BOOKED)
                .reasonForVisit(request.getReasonForVisit())
                .bookedByUserId(patientUserId)
                .build();

        ConsultationAppointment saved = appointmentRepository.save(appointment);

        consumeSlotCapacity(availability);

        log.info("Consultation booked: id={} patient={} staff={}", saved.getId(), patient.getFullName(), staffProfile.getFullName());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public ConsultationAppointmentResponse cancelAppointment(Long patientUserId, Long appointmentId, CancelAppointmentRequest request) {
        ConsultationAppointment appointment = findAppointmentOrThrow(appointmentId);

        Long owningPatientUserId = appointment.getPatient().getUserId();
        if (owningPatientUserId == null || !owningPatientUserId.equals(patientUserId)) {
            throw new UnauthorizedActionException("You can only cancel your own consultations");
        }

        if (!ACTIVE_STATUSES.contains(appointment.getStatus())) {
            throw new InvalidRequestException("Only booked/rescheduled consultations can be cancelled");
        }

        releaseSlotCapacity(appointment.getAvailability());

        appointment.setStatus(AppointmentStatus.CANCELLED);
        appointment.setCancelReason(request.getReason());

        ConsultationAppointment saved = appointmentRepository.save(appointment);
        log.info("Consultation cancelled: id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public ConsultationAppointmentResponse completeConsultation(Long staffUserId, Long appointmentId) {
        ConsultationAppointment appointment = findAppointmentOrThrow(appointmentId);

        if (!appointment.getStaffProfile().getUserId().equals(staffUserId)) {
            throw new UnauthorizedActionException("You can only complete your own consultations");
        }

        if (appointment.getStatus() == AppointmentStatus.CANCELLED || appointment.getStatus() == AppointmentStatus.COMPLETED) {
            throw new InvalidRequestException("This consultation cannot be completed from its current status: " + appointment.getStatus());
        }

        appointment.setStatus(AppointmentStatus.COMPLETED);

        ConsultationAppointment saved = appointmentRepository.save(appointment);
        log.info("Consultation completed: id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public ConsultationAppointmentResponse getAppointmentById(Long appointmentId) {
        return appointmentMapper.toResponse(findAppointmentOrThrow(appointmentId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConsultationAppointmentResponse> getMyAppointments(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return appointmentRepository.findByPatientIdOrderByAppointmentDateDescStartTimeDesc(patient.getId())
                .stream().map(appointmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConsultationAppointmentResponse> getTodayAppointments(Long staffUserId) {
        StaffProfile staffProfile = findStaffByUserId(staffUserId);
        return appointmentRepository.findByStaffProfileIdAndAppointmentDateOrderByStartTimeAsc(staffProfile.getId(), LocalDate.now())
                .stream().map(appointmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConsultationAppointmentResponse> getUpcomingAppointments(Long staffUserId) {
        StaffProfile staffProfile = findStaffByUserId(staffUserId);
        return appointmentRepository
                .findByStaffProfileIdAndAppointmentDateGreaterThanEqualAndStatusInOrderByAppointmentDateAscStartTimeAsc(
                        staffProfile.getId(), LocalDate.now(), ACTIVE_STATUSES)
                .stream().map(appointmentMapper::toResponse).toList();
    }

    private void consumeSlotCapacity(StaffAvailability availability) {
        availability.setBookedCount(availability.getBookedCount() + 1);
        if (availability.getBookedCount() >= availability.getMaximumPatients()) {
            availability.setStatus(AvailabilityStatus.FULLY_BOOKED);
        }
        availabilityRepository.save(availability);
    }

    private void releaseSlotCapacity(StaffAvailability availability) {
        availability.setBookedCount(Math.max(0, availability.getBookedCount() - 1));
        if (availability.getStatus() == AvailabilityStatus.FULLY_BOOKED
                && availability.getBookedCount() < availability.getMaximumPatients()) {
            availability.setStatus(AvailabilityStatus.ACTIVE);
        }
        availabilityRepository.save(availability);
    }

    private ConsultationAppointment findAppointmentOrThrow(Long appointmentId) {
        return appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Consultation appointment not found with id: " + appointmentId));
    }

    private StaffProfile findStaffByUserId(Long userId) {
        return staffProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff profile not found for the logged-in user"));
    }
}
