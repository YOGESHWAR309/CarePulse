package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.GenerateBillRequest;
import com.carepulse.hospital.dto.request.VerifyPaymentRequest;
import com.carepulse.hospital.dto.response.BillResponse;
import com.carepulse.hospital.dto.response.PaymentOrderResponse;
import com.carepulse.hospital.entity.Appointment;
import com.carepulse.hospital.entity.Bill;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.BillStatus;
import com.carepulse.hospital.enums.PaymentMethod;
import com.carepulse.hospital.exception.DuplicateResourceException;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.mapper.BillMapper;
import com.carepulse.hospital.messaging.NotificationEventPublisher;
import com.carepulse.hospital.messaging.event.BillGeneratedEvent;
import com.carepulse.hospital.messaging.event.BillPaidEvent;
import com.carepulse.hospital.repository.AppointmentRepository;
import com.carepulse.hospital.repository.BillRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingServiceImpl implements com.carepulse.hospital.service.BillingService {

    private static final String CURRENCY = "INR";

    private final BillRepository billRepository;
    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final BillMapper billMapper;
    private final RazorpayClient razorpayClient;
    private final NotificationEventPublisher notificationEventPublisher;
    private final SecureRandom secureRandom = new SecureRandom();

    @Value("${razorpay.key-id}")
    private String razorpayKeyId;

    @Value("${razorpay.key-secret}")
    private String razorpayKeySecret;

    /**
     * Generates a Bill row only once a consultation is COMPLETED (per the
     * spec's billing workflow: "Consultation Completed -> Bill Generated"),
     * with a unique human-readable invoice number, and fires
     * BillGeneratedEvent so the patient is prompted to pay.
     */
    @Override
    @Transactional
    public BillResponse generateBill(GenerateBillRequest request) {
        Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + request.getAppointmentId()));

        if (appointment.getStatus() != AppointmentStatus.COMPLETED) {
            throw new InvalidRequestException("A bill can only be generated for a COMPLETED appointment");
        }

        if (billRepository.existsByAppointmentId(appointment.getId())) {
            throw new DuplicateResourceException("A bill already exists for this appointment");
        }

        Bill bill = Bill.builder()
                .appointment(appointment)
                .patient(appointment.getPatient())
                .amount(request.getAmount())
                .invoiceNumber(generateInvoiceNumber())
                .status(BillStatus.PENDING)
                .build();

        Bill saved = billRepository.save(bill);

        notificationEventPublisher.publishBillGenerated(
                BillGeneratedEvent.builder()
                        .billId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .amount(saved.getAmount())
                        .invoiceNumber(saved.getInvoiceNumber())
                        .build());

        log.info("Bill generated: id={} invoice={} amount={}", saved.getId(), saved.getInvoiceNumber(), saved.getAmount());
        return billMapper.toResponse(saved);
    }

    /**
     * Creates a Razorpay Order for the bill's amount (converted to paise,
     * since Razorpay's API operates in the smallest currency unit) and
     * stashes the returned order id on the Bill so {@link #verifyPayment}
     * can later confirm it matches.
     */
    @Override
    @Transactional
    public PaymentOrderResponse createPaymentOrder(Long billId) {
        Bill bill = findByIdOrThrow(billId);

        if (bill.getStatus() != BillStatus.PENDING) {
            throw new InvalidRequestException("Only PENDING bills can have a payment order created");
        }

        long amountInPaise = bill.getAmount().multiply(BigDecimal.valueOf(100)).longValue();

        try {
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amountInPaise);
            orderRequest.put("currency", CURRENCY);
            orderRequest.put("receipt", bill.getInvoiceNumber());

            Order order = razorpayClient.orders.create(orderRequest);
            String razorpayOrderId = order.get("id");

            bill.setRazorpayOrderId(razorpayOrderId);
            billRepository.save(bill);

            log.info("Razorpay order created: billId={} orderId={}", bill.getId(), razorpayOrderId);

            return PaymentOrderResponse.builder()
                    .billId(bill.getId())
                    .razorpayOrderId(razorpayOrderId)
                    .amountInPaise(amountInPaise)
                    .currency(CURRENCY)
                    .razorpayKeyId(razorpayKeyId)
                    .build();

        } catch (RazorpayException ex) {
            log.error("Razorpay order creation failed for billId={}: {}", bill.getId(), ex.getMessage());
            throw new InvalidRequestException("Unable to initiate payment at this time. Please try again.");
        }
    }

    /**
     * Independently re-derives the HMAC-SHA256 signature from
     * {@code orderId|paymentId} using our Razorpay secret and compares it
     * against what the frontend submitted - this is what actually proves
     * the payment succeeded; the frontend's own "success" callback is
     * NEVER trusted on its own, since it could be spoofed.
     */
    @Override
    @Transactional
    public BillResponse verifyPayment(Long billId, VerifyPaymentRequest request) {
        Bill bill = findByIdOrThrow(billId);

        if (bill.getRazorpayOrderId() == null || !bill.getRazorpayOrderId().equals(request.getRazorpayOrderId())) {
            throw new InvalidRequestException("Order id does not match this bill's payment order");
        }

        try {
            JSONObject options = new JSONObject();
            options.put("razorpay_order_id", request.getRazorpayOrderId());
            options.put("razorpay_payment_id", request.getRazorpayPaymentId());
            options.put("razorpay_signature", request.getRazorpaySignature());

            boolean isValidSignature = Utils.verifyPaymentSignature(options, razorpayKeySecret);

            if (!isValidSignature) {
                bill.setStatus(BillStatus.FAILED);
                billRepository.save(bill);
                throw new InvalidRequestException("Payment signature verification failed");
            }

            bill.setStatus(BillStatus.PAID);
            bill.setRazorpayPaymentId(request.getRazorpayPaymentId());
            bill.setRazorpaySignature(request.getRazorpaySignature());
            bill.setPaidAt(LocalDateTime.now());
            bill.setPaymentMethod(PaymentMethod.ONLINE);

            Bill saved = billRepository.save(bill);

            notificationEventPublisher.publishBillPaid(
                    BillPaidEvent.builder()
                            .billId(saved.getId())
                            .patientEmail(saved.getPatient().getEmail())
                            .patientName(saved.getPatient().getFullName())
                            .amountPaid(saved.getAmount())
                            .invoiceNumber(saved.getInvoiceNumber())
                            .razorpayPaymentId(saved.getRazorpayPaymentId())
                            .build());

            log.info("Payment verified and bill marked PAID: id={}", saved.getId());
            return billMapper.toResponse(saved);

        } catch (RazorpayException ex) {
            log.error("Razorpay signature verification threw an exception for billId={}: {}", bill.getId(), ex.getMessage());
            throw new InvalidRequestException("Unable to verify payment at this time. Please contact support.");
        }
    }

    @Override
    @Transactional
    public BillResponse markPaymentFailed(Long billId) {
        Bill bill = findByIdOrThrow(billId);
        bill.setStatus(BillStatus.FAILED);
        Bill saved = billRepository.save(bill);
        log.info("Bill marked FAILED: id={}", saved.getId());
        return billMapper.toResponse(saved);
    }

    /**
     * Records an in-person cash payment collected at the front desk - e.g. a
     * walk-in patient who pays the receptionist directly rather than through
     * Razorpay checkout. Skips the Razorpay order/signature machinery entirely
     * since no online transaction ever happened; Receptionist/Admin vouching
     * for the cash received IS the confirmation here; that's why this action
     * is restricted to those two roles and never exposed to the patient.
     */
    @Override
    @Transactional
    public BillResponse markPaidByCash(Long billId) {
        Bill bill = findByIdOrThrow(billId);

        if (bill.getStatus() == BillStatus.PAID) {
            throw new InvalidRequestException("This bill has already been paid");
        }
        if (bill.getStatus() == BillStatus.REFUNDED) {
            throw new InvalidRequestException("This bill has been refunded and cannot be marked as paid");
        }

        bill.setStatus(BillStatus.PAID);
        bill.setPaymentMethod(PaymentMethod.CASH);
        bill.setPaidAt(LocalDateTime.now());

        Bill saved = billRepository.save(bill);

        notificationEventPublisher.publishBillPaid(
                BillPaidEvent.builder()
                        .billId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .amountPaid(saved.getAmount())
                        .invoiceNumber(saved.getInvoiceNumber())
                        .razorpayPaymentId(null)
                        .build());

        log.info("Bill marked PAID via cash: id={}", saved.getId());
        return billMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public BillResponse getBillById(Long billId) {
        return billMapper.toResponse(findByIdOrThrow(billId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BillResponse> getMyBills(Long patientUserId) {
        var patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return billRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(billMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BillResponse> getAllBills() {
        return billRepository.findAll().stream().map(billMapper::toResponse).toList();
    }

    private Bill findByIdOrThrow(Long billId) {
        return billRepository.findById(billId)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with id: " + billId));
    }

    /** Generates a simple, sortable, collision-resistant invoice number: INV-<epochSeconds>-<4 random digits>. */
    private String generateInvoiceNumber() {
        long epochSeconds = System.currentTimeMillis() / 1000;
        int randomSuffix = 1000 + secureRandom.nextInt(9000);
        return "INV-" + epochSeconds + "-" + randomSuffix;
    }
}
