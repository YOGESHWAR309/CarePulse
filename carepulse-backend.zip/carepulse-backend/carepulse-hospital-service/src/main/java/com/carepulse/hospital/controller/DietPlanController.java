package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateDietPlanRequest;
import com.carepulse.hospital.dto.request.UpdateDietPlanRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.DietPlanResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.DietPlanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Dietician", description = "Diet plan management")
@SecurityRequirement(name = "bearerAuth")
public class DietPlanController {

    private final DietPlanService dietPlanService;

    @Operation(summary = "[Dietician] Create a diet plan for a completed consultation")
    @PostMapping("/diet-plans")
    @PreAuthorize("hasRole('DIETICIAN')")
    public ResponseEntity<ApiResponse<DietPlanResponse>> createDietPlan(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateDietPlanRequest request) {
        DietPlanResponse response = dietPlanService.createDietPlan(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Diet plan created successfully", response));
    }

    @Operation(summary = "[Dietician] Update my own diet plan")
    @PutMapping("/diet-plans/{dietPlanId}")
    @PreAuthorize("hasRole('DIETICIAN')")
    public ResponseEntity<ApiResponse<DietPlanResponse>> updateDietPlan(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long dietPlanId,
            @Valid @RequestBody UpdateDietPlanRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Diet plan updated successfully", dietPlanService.updateDietPlan(user.userId(), dietPlanId, request)));
    }

    @Operation(summary = "[Patient] View my own diet plans")
    @GetMapping("/patients/me/diet-plans")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<DietPlanResponse>>> getMyDietPlans(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Diet plans fetched successfully", dietPlanService.getMyDietPlans(user.userId())));
    }

    @Operation(summary = "[Dietician] View a patient's diet plan history")
    @GetMapping("/patients/{patientId}/diet-plans")
    @PreAuthorize("hasRole('DIETICIAN')")
    public ResponseEntity<ApiResponse<List<DietPlanResponse>>> getPatientDietPlans(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success("Diet plans fetched successfully", dietPlanService.getPatientDietPlans(patientId)));
    }
}
