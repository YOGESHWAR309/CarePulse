package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.StaffDirectoryResponse;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.mapper.StaffDirectoryMapper;
import com.carepulse.hospital.repository.StaffProfileRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Read-only staff directory endpoints. {@code /staff} is what a patient browses BEFORE
 * booking a consultation - the Dietician/Nutritionist counterpart to browsing the Doctor
 * directory via {@link DoctorController}. {@code /doctors/me/staff/search} is the Doctor-facing
 * counterpart: searching Radiologist/Pathologist staff by name to assign a scan/lab test to.
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Staff Directory", description = "Browse bookable staff (Dietician/Nutritionist for patients; Radiologist/Pathologist for doctors)")
@SecurityRequirement(name = "bearerAuth")
public class StaffDirectoryController {

    private final StaffProfileRepository staffProfileRepository;
    private final StaffDirectoryMapper staffDirectoryMapper;

    @Operation(summary = "View all active Dieticians or Nutritionists available to book")
    @GetMapping("/staff")
    public ResponseEntity<ApiResponse<List<StaffDirectoryResponse>>> getBookableStaff(@RequestParam UserRole role) {
        if (role != UserRole.DIETICIAN && role != UserRole.NUTRITIONIST) {
            throw new InvalidRequestException("Only DIETICIAN and NUTRITIONIST staff can be browsed for booking");
        }

        List<StaffDirectoryResponse> response = staffProfileRepository.findByRole(role).stream()
                .filter(profile -> profile.isActive())
                .map(staffDirectoryMapper::toResponse)
                .toList();

        return ResponseEntity.ok(ApiResponse.success("Staff fetched successfully", response));
    }

    @Operation(summary = "[Doctor] Search Radiologist/Pathologist staff by name, to assign a scan or lab test request to a specific person")
    @GetMapping("/doctors/me/staff/search")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<StaffDirectoryResponse>>> searchStaffForDoctor(
            @RequestParam UserRole role, @RequestParam String name) {
        if (role != UserRole.RADIOLOGIST && role != UserRole.PATHOLOGIST) {
            throw new InvalidRequestException("Only RADIOLOGIST and PATHOLOGIST staff can be searched by a doctor");
        }

        List<StaffDirectoryResponse> response = staffProfileRepository.findByRoleAndFullNameContainingIgnoreCase(role, name).stream()
                .filter(profile -> profile.isActive())
                .map(staffDirectoryMapper::toResponse)
                .toList();

        return ResponseEntity.ok(ApiResponse.success("Staff fetched successfully", response));
    }
}
