package com.carepulse.hospital.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * A diet plan authored by a Dietician for a patient, tied to a specific
 * {@link ConsultationAppointment} - the plan is evidence that an actual
 * consultation took place, rather than the Dietician being able to write
 * a plan against any patientId with no visit on record.
 */
@Entity
@Table(name = "diet_plans", uniqueConstraints = {
        @UniqueConstraint(name = "uk_diet_plan_consultation", columnNames = "consultation_appointment_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DietPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "consultation_appointment_id", nullable = false)
    private ConsultationAppointment consultationAppointment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    /** The Dietician's Auth Service userId - no dedicated Dietician entity exists (see StaffProfile), so ownership is checked directly against this field. */
    @Column(nullable = false)
    private Long dieticianUserId;

    @Column(length = 200)
    private String dieticianName;

    @Column(nullable = false, length = 3000)
    private String planDetails;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
