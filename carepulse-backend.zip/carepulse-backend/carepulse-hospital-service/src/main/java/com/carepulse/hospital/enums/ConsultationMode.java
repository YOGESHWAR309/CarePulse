package com.carepulse.hospital.enums;

/** How a doctor's slot/appointment is conducted. */
public enum ConsultationMode {
    IN_PERSON,
    ONLINE
}
