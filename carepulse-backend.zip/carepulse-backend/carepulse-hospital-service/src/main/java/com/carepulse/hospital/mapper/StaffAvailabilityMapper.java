package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.StaffAvailabilityResponse;
import com.carepulse.hospital.entity.StaffAvailability;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StaffAvailabilityMapper {

    @Mapping(target = "staffProfileId", expression = "java(availability.getStaffProfile().getId())")
    @Mapping(target = "staffName", expression = "java(availability.getStaffProfile().getFullName())")
    @Mapping(target = "staffRole", expression = "java(availability.getStaffProfile().getRole())")
    StaffAvailabilityResponse toResponse(StaffAvailability availability);
}
