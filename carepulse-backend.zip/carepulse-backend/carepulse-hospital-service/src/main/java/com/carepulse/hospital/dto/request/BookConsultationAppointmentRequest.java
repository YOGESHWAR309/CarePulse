package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/** Payload for POST /api/hospital/patients/me/consultations - a patient booking a Dietician/Nutritionist consultation. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookConsultationAppointmentRequest {

    @NotNull(message = "Staff profile id is required")
    private Long staffProfileId;

    @NotNull(message = "Availability id is required")
    private Long availabilityId;

    @NotNull(message = "Appointment date is required")
    @FutureOrPresent(message = "Appointment date cannot be in the past")
    private LocalDate appointmentDate;

    @NotNull(message = "Slot start time is required")
    private LocalTime slotStartTime;

    @Size(max = 500, message = "Reason for visit must not exceed 500 characters")
    private String reasonForVisit;
}
