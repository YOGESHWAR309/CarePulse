package com.carepulse.hospital.enums;

/** Lifecycle state of a single DoctorAvailability slot-block. */
public enum AvailabilityStatus {
    /** Published and open for patients to book against. */
    ACTIVE,
    /** Doctor pulled it down (e.g. on leave) - existing bookings are NOT auto-cancelled, only new bookings are blocked. */
    INACTIVE,
    /** Every slot generated from this block has been booked. */
    FULLY_BOOKED
}
