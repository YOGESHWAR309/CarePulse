package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateBulkAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateAvailabilityRequest;
import com.carepulse.hospital.dto.response.AvailabilityResponse;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.BulkAvailabilityResponse;

import java.time.LocalDate;
import java.util.List;

/**
 * Doctor-owned availability CRUD, plus the patient-facing read side that
 * computes concrete bookable slots from published blocks. Every write
 * operation takes the CALLING doctor's userId (from JWT) and verifies it
 * against the availability's owning doctor - a doctor can only ever
 * CRUD their own availability, enforced here, never trusted from the request body.
 */
public interface AvailabilityService {

    AvailabilityResponse createAvailability(Long doctorUserId, CreateAvailabilityRequest request);

    /**
     * Publishes availability across a date range in one call (e.g. "every
     * Mon/Wed/Fri for the next two weeks") instead of requiring one
     * {@link #createAvailability} call per day. Silently skips any date
     * that would exactly duplicate an already-published block, so calling
     * this twice with the same range is safe.
     */
    BulkAvailabilityResponse createBulkAvailability(Long doctorUserId, CreateBulkAvailabilityRequest request);

    AvailabilityResponse updateAvailability(Long doctorUserId, Long availabilityId, UpdateAvailabilityRequest request);

    /** Toggles ACTIVE/INACTIVE only, without re-validating the rest of the block (see {@link com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest}). */
    AvailabilityResponse updateAvailabilityStatus(Long doctorUserId, Long availabilityId, com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request);

    void deleteAvailability(Long doctorUserId, Long availabilityId);

    /** The doctor's own "View Availability" screen - every block they've ever published. */
    List<AvailabilityResponse> getMyAvailability(Long doctorUserId);

    /** Patient-facing: every ACTIVE, future-dated block for a doctor - step "system displays only the selected doctor's published availability". */
    List<AvailabilityResponse> getDoctorAvailability(Long doctorId);

    /** Patient-facing: concrete bookable slots for one doctor on one specific date, computed from all matching ACTIVE blocks. */
    List<AvailableSlotResponse> getAvailableSlots(Long doctorId, LocalDate date);
}
