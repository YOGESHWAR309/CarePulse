package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    /** Central lookup used everywhere a request carries the caller's userId (from JWT/X-User-Id) and we need their Doctor row. */
    Optional<Doctor> findByUserId(Long userId);

    boolean existsByUserId(Long userId);

    /** Backs "patient selects department -> system shows only doctors in that department". Department is already known/fixed here, so no fetch join needed. */
    List<Doctor> findByDepartmentIdAndActiveTrue(Long departmentId);

    /**
     * Backs Admin's "View All Doctors" and general doctor directory screens.
     * Fetch-joins department - DoctorMapper reads departmentName per row, and
     * each doctor can belong to a different department, so this is a real N+1
     * without the join.
     */
    @Query("SELECT doc FROM Doctor doc LEFT JOIN FETCH doc.department ORDER BY doc.fullName ASC")
    List<Doctor> findAllByOrderByFullNameAsc();
}
