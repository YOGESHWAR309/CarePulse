package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.UpdateDoctorRequest;
import com.carepulse.hospital.dto.response.DoctorResponse;

import java.util.List;

/**
 * Doctor clinical-profile management. Doctor ROWS themselves are created
 * automatically by {@link com.carepulse.hospital.messaging.listener.StaffCreatedEventListener}
 * the moment Admin creates the account in Auth Service - this service only
 * fills in / edits the clinical fields and provides the read-side directory
 * patients browse.
 */
public interface DoctorService {

    /** Admin sets/updates department, specialization, qualification, experience, and fee. */
    DoctorResponse updateDoctorProfile(Long doctorId, UpdateDoctorRequest request);

    DoctorResponse getDoctorById(Long doctorId);

    /** Resolves a Doctor row from the CALLING doctor's own userId (from JWT) - used by "my profile"/"my availability" endpoints. */
    DoctorResponse getMyProfile(Long userId);

    /** Full directory - Admin's "View All Doctors" screen. */
    List<DoctorResponse> getAllDoctors();

    /** Backs "patient selects department -> system shows only doctors in that department", active doctors only. */
    List<DoctorResponse> getDoctorsByDepartment(Long departmentId);
}
