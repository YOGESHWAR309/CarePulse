package com.carepulse.hospital.exception;

/** Thrown when creating something would violate a uniqueness rule (e.g. duplicate department name) - mapped to HTTP 409. */
public class DuplicateResourceException extends RuntimeException {
    public DuplicateResourceException(String message) {
        super(message);
    }
}
