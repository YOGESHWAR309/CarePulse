package com.carepulse.hospital.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

/** Published after a successful booking so Notification Service can email both patient and doctor a confirmation. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentBookedEvent implements Serializable {
    private Long appointmentId;
    private String patientEmail;
    private String patientName;
    private String doctorEmail;
    private String doctorName;
    private LocalDate appointmentDate;
    private LocalTime startTime;
}
