package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Bookable time block for a non-Doctor clinical staff member - currently
 * DIETICIAN and NUTRITIONIST. Mirrors {@link DoctorAvailability}'s shape
 * and slot-capacity mechanics exactly, but points at a {@link StaffProfile}
 * instead of a {@link Doctor}, since Dieticians/Nutritionists have no
 * dedicated entity of their own.
 * <p>
 * Only the OWNING staff member may CRUD their own availability - enforced
 * in the service layer by comparing the caller's userId against
 * {@link StaffProfile#getUserId()}, the same pattern used for Doctor availability.
 */
@Entity
@Table(name = "staff_availabilities")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "staff_profile_id", nullable = false)
    private StaffProfile staffProfile;

    @Column(nullable = false)
    private LocalDate availableDate;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private LocalTime endTime;

    @Column(nullable = false)
    private Integer slotDurationMinutes;

    @Column(nullable = false)
    private Integer maximumPatients;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ConsultationMode consultationMode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private AvailabilityStatus status = AvailabilityStatus.ACTIVE;

    @Column(nullable = false)
    @Builder.Default
    private Integer bookedCount = 0;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
