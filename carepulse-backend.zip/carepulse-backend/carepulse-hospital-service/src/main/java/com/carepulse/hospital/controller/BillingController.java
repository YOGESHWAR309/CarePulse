package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.GenerateBillRequest;
import com.carepulse.hospital.dto.request.VerifyPaymentRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.BillResponse;
import com.carepulse.hospital.dto.response.PaymentOrderResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.BillingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Billing lifecycle and Razorpay payment integration. */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Billing", description = "Bill generation and Razorpay payment integration")
@SecurityRequirement(name = "bearerAuth")
public class BillingController {

    private final BillingService billingService;

    @Operation(summary = "[Receptionist/Admin] Generate a bill for a completed appointment")
    @PostMapping("/billing/bills")
    @PreAuthorize("hasAnyRole('RECEPTIONIST', 'ADMIN')")
    public ResponseEntity<ApiResponse<BillResponse>> generateBill(@Valid @RequestBody GenerateBillRequest request) {
        BillResponse response = billingService.generateBill(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Bill generated successfully", response));
    }

    @Operation(summary = "[Patient] Create a Razorpay payment order for a pending bill")
    @PostMapping("/billing/bills/{billId}/payment-order")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<PaymentOrderResponse>> createPaymentOrder(@PathVariable Long billId) {
        return ResponseEntity.ok(ApiResponse.success("Payment order created successfully", billingService.createPaymentOrder(billId)));
    }

    @Operation(summary = "[Patient] Verify a completed Razorpay payment")
    @PostMapping("/billing/bills/{billId}/verify-payment")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<BillResponse>> verifyPayment(
            @PathVariable Long billId, @Valid @RequestBody VerifyPaymentRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Payment verified successfully", billingService.verifyPayment(billId, request)));
    }

    @Operation(summary = "[Patient] Report a failed/cancelled Razorpay checkout")
    @PutMapping("/billing/bills/{billId}/payment-failed")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<BillResponse>> markPaymentFailed(@PathVariable Long billId) {
        return ResponseEntity.ok(ApiResponse.success("Payment marked as failed", billingService.markPaymentFailed(billId)));
    }

    @Operation(summary = "[Receptionist/Admin] Record an in-person cash payment for a bill (e.g. walk-in patient paying at the front desk)")
    @PutMapping("/billing/bills/{billId}/mark-paid-cash")
    @PreAuthorize("hasAnyRole('RECEPTIONIST', 'ADMIN')")
    public ResponseEntity<ApiResponse<BillResponse>> markPaidByCash(@PathVariable Long billId) {
        return ResponseEntity.ok(ApiResponse.success("Bill marked as paid", billingService.markPaidByCash(billId)));
    }

    @Operation(summary = "Get a single bill / download invoice details by id")
    @GetMapping("/billing/bills/{billId}")
    public ResponseEntity<ApiResponse<BillResponse>> getBillById(@PathVariable Long billId) {
        return ResponseEntity.ok(ApiResponse.success("Bill fetched successfully", billingService.getBillById(billId)));
    }

    @Operation(summary = "[Patient] View my own billing history")
    @GetMapping("/patients/me/bills")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<BillResponse>>> getMyBills(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Bills fetched successfully", billingService.getMyBills(user.userId())));
    }

    @Operation(summary = "[Admin] View all bills (billing reports / revenue dashboard)")
    @GetMapping("/admin/bills")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<BillResponse>>> getAllBills() {
        return ResponseEntity.ok(ApiResponse.success("Bills fetched successfully", billingService.getAllBills()));
    }

    @Operation(summary = "[Receptionist] View all bills, to collect cash payments from walk-in/front-desk patients")
    @GetMapping("/receptionist/bills")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<List<BillResponse>>> getBillsForReceptionist() {
        return ResponseEntity.ok(ApiResponse.success("Bills fetched successfully", billingService.getAllBills()));
    }
}
