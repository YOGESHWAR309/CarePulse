package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.ReportStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * A lab test a Doctor has requested against a {@link MedicalRecord}, worked
 * through by a Pathologist: REQUESTED -> SAMPLE_COLLECTED -> IN_PROGRESS -> READY.
 */
@Entity
@Table(name = "lab_test_requests")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabTestRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medical_record_id", nullable = false)
    private MedicalRecord medicalRecord;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    /** The doctor who ORDERED the test (distinct from the pathologist who performs it). */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requesting_doctor_id", nullable = false)
    private Doctor requestingDoctor;

    @Column(nullable = false, length = 200)
    private String testName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private ReportStatus status = ReportStatus.REQUESTED;

    /** userId of the Pathologist this request is assigned to, chosen by the ordering doctor at creation time (via staff search). */
    @Column(name = "assigned_pathologist_user_id")
    private Long assignedPathologistUserId;

    /** Snapshot of the assigned Pathologist's name at assignment time, so responses don't need a join back to StaffProfile. */
    @Column(name = "assigned_pathologist_name", length = 200)
    private String assignedPathologistName;

    @Column(length = 2000)
    private String resultSummary;

    /** The uploaded report PDF's bytes, stored directly in the database. */
    @Lob
    @Column(name = "report_file_data", columnDefinition = "LONGBLOB")
    private byte[] reportFileData;

    @Column(name = "report_file_name", length = 255)
    private String reportFileName;

    @Column(name = "report_content_type", length = 100)
    private String reportContentType;

    /** userId of the Pathologist who has picked this up / is processing it. */
    private Long processedByUserId;

    private LocalDateTime sampleCollectedAt;

    private LocalDateTime readyAt;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
