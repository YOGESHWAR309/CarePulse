package com.carepulse.hospital.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * A nutrition plan authored by a Nutritionist for a patient, tied to a
 * specific {@link ConsultationAppointment} - mirrors {@link DietPlan}'s structure.
 */
@Entity
@Table(name = "nutrition_plans", uniqueConstraints = {
        @UniqueConstraint(name = "uk_nutrition_plan_consultation", columnNames = "consultation_appointment_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NutritionPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "consultation_appointment_id", nullable = false)
    private ConsultationAppointment consultationAppointment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @Column(nullable = false)
    private Long nutritionistUserId;

    @Column(length = 200)
    private String nutritionistName;

    @Column(nullable = false, length = 3000)
    private String planDetails;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
