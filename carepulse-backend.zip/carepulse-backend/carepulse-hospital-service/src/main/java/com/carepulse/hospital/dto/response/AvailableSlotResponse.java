package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.ConsultationMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * One concrete, bookable time slot computed on the fly from a
 * {@link com.carepulse.hospital.entity.DoctorAvailability} block (e.g. a
 * 09:00-13:00 block with a 15-minute duration produces sixteen of these).
 * This, not the raw availability block, is what a patient actually picks
 * from and sends back as {@code availabilityId + slotStartTime} when booking.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvailableSlotResponse {
    private Long availabilityId;
    private LocalDate availableDate;
    private LocalTime slotStartTime;
    private LocalTime slotEndTime;
    private ConsultationMode consultationMode;
    private boolean bookable;
}
