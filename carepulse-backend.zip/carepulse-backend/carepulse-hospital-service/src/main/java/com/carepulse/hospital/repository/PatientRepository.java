package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Long> {

    Optional<Patient> findByUserId(Long userId);

    boolean existsByUserId(Long userId);

    /** Backs Receptionist's "Search Patient" screen (simple contains-match on name; a real system would add pagination/full-text search). */
    List<Patient> findByFullNameContainingIgnoreCase(String name);
}
