package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.LabTestResponse;
import com.carepulse.hospital.entity.LabTestRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LabTestMapper {

    @Mapping(target = "medicalRecordId", expression = "java(labTest.getMedicalRecord().getId())")
    @Mapping(target = "patientId", expression = "java(labTest.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(labTest.getPatient().getFullName())")
    @Mapping(target = "requestingDoctorName", expression = "java(labTest.getRequestingDoctor().getFullName())")
    @Mapping(target = "reportAvailable", expression = "java(labTest.getReportFileData() != null)")
    LabTestResponse toResponse(LabTestRequest labTest);
}
