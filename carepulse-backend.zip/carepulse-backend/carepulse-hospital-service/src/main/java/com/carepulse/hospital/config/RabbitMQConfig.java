package com.carepulse.hospital.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Declares BOTH sides of Hospital Service's RabbitMQ topology:
 * <ol>
 *     <li><b>Consumer side</b> - re-declares Auth Service's
 *     {@code carepulse.notification.exchange} (idempotent - same name/type/
 *     durability, so whichever service starts first "wins" with no conflict)
 *     plus the two queues Hospital Service listens on
 *     ({@code hospital.patient-registered}, {@code hospital.staff-created})
 *     for profile auto-provisioning.</li>
 *     <li><b>Publisher side</b> - a NEW exchange
 *     {@code carepulse.hospital.events.exchange} that Hospital Service
 *     publishes clinical/appointment/billing events to. Notification
 *     Service binds its own queues to this exchange to send the various
 *     confirmation/reminder emails.</li>
 * </ol>
 */
@Configuration
public class RabbitMQConfig {

    // ================= Consumer side (from Auth Service) =================

    public static final String NOTIFICATION_EXCHANGE = "carepulse.notification.exchange";

    public static final String HOSPITAL_PATIENT_REGISTERED_QUEUE = "carepulse.hospital.patient-registered.queue";
    public static final String PATIENT_REGISTERED_ROUTING_KEY = "hospital.patient-registered";

    public static final String HOSPITAL_STAFF_CREATED_QUEUE = "carepulse.hospital.staff-created.queue";
    public static final String STAFF_CREATED_ROUTING_KEY = "notification.staff-created";

    @Bean
    public TopicExchange notificationExchange() {
        return new TopicExchange(NOTIFICATION_EXCHANGE, true, false);
    }

    @Bean
    public Queue hospitalPatientRegisteredQueue() {
        return new Queue(HOSPITAL_PATIENT_REGISTERED_QUEUE, true);
    }

    @Bean
    public Binding hospitalPatientRegisteredBinding() {
        return BindingBuilder.bind(hospitalPatientRegisteredQueue()).to(notificationExchange()).with(PATIENT_REGISTERED_ROUTING_KEY);
    }

    @Bean
    public Queue hospitalStaffCreatedQueue() {
        return new Queue(HOSPITAL_STAFF_CREATED_QUEUE, true);
    }

    @Bean
    public Binding hospitalStaffCreatedBinding() {
        return BindingBuilder.bind(hospitalStaffCreatedQueue()).to(notificationExchange()).with(STAFF_CREATED_ROUTING_KEY);
    }

    // ================= Publisher side (to Notification Service) =================

    public static final String HOSPITAL_EVENTS_EXCHANGE = "carepulse.hospital.events.exchange";

    public static final String APPOINTMENT_BOOKED_QUEUE = "carepulse.notification.appointment-booked.queue";
    public static final String APPOINTMENT_BOOKED_ROUTING_KEY = "hospital.appointment.booked";

    public static final String APPOINTMENT_CANCELLED_QUEUE = "carepulse.notification.appointment-cancelled.queue";
    public static final String APPOINTMENT_CANCELLED_ROUTING_KEY = "hospital.appointment.cancelled";

    public static final String PRESCRIPTION_GENERATED_QUEUE = "carepulse.notification.prescription-generated.queue";
    public static final String PRESCRIPTION_GENERATED_ROUTING_KEY = "hospital.prescription.generated";

    public static final String BILL_GENERATED_QUEUE = "carepulse.notification.bill-generated.queue";
    public static final String BILL_GENERATED_ROUTING_KEY = "hospital.bill.generated";

    public static final String BILL_PAID_QUEUE = "carepulse.notification.bill-paid.queue";
    public static final String BILL_PAID_ROUTING_KEY = "hospital.bill.paid";

    public static final String LAB_REPORT_READY_QUEUE = "carepulse.notification.lab-report-ready.queue";
    public static final String LAB_REPORT_READY_ROUTING_KEY = "hospital.lab-report.ready";

    public static final String RADIOLOGY_REPORT_READY_QUEUE = "carepulse.notification.radiology-report-ready.queue";
    public static final String RADIOLOGY_REPORT_READY_ROUTING_KEY = "hospital.radiology-report.ready";

    @Bean
    public TopicExchange hospitalEventsExchange() {
        return new TopicExchange(HOSPITAL_EVENTS_EXCHANGE, true, false);
    }

    @Bean
    public Queue appointmentBookedQueue() {
        return new Queue(APPOINTMENT_BOOKED_QUEUE, true);
    }

    @Bean
    public Binding appointmentBookedBinding() {
        return BindingBuilder.bind(appointmentBookedQueue()).to(hospitalEventsExchange()).with(APPOINTMENT_BOOKED_ROUTING_KEY);
    }

    @Bean
    public Queue appointmentCancelledQueue() {
        return new Queue(APPOINTMENT_CANCELLED_QUEUE, true);
    }

    @Bean
    public Binding appointmentCancelledBinding() {
        return BindingBuilder.bind(appointmentCancelledQueue()).to(hospitalEventsExchange()).with(APPOINTMENT_CANCELLED_ROUTING_KEY);
    }

    @Bean
    public Queue prescriptionGeneratedQueue() {
        return new Queue(PRESCRIPTION_GENERATED_QUEUE, true);
    }

    @Bean
    public Binding prescriptionGeneratedBinding() {
        return BindingBuilder.bind(prescriptionGeneratedQueue()).to(hospitalEventsExchange()).with(PRESCRIPTION_GENERATED_ROUTING_KEY);
    }

    @Bean
    public Queue billGeneratedQueue() {
        return new Queue(BILL_GENERATED_QUEUE, true);
    }

    @Bean
    public Binding billGeneratedBinding() {
        return BindingBuilder.bind(billGeneratedQueue()).to(hospitalEventsExchange()).with(BILL_GENERATED_ROUTING_KEY);
    }

    @Bean
    public Queue billPaidQueue() {
        return new Queue(BILL_PAID_QUEUE, true);
    }

    @Bean
    public Binding billPaidBinding() {
        return BindingBuilder.bind(billPaidQueue()).to(hospitalEventsExchange()).with(BILL_PAID_ROUTING_KEY);
    }

    @Bean
    public Queue labReportReadyQueue() {
        return new Queue(LAB_REPORT_READY_QUEUE, true);
    }

    @Bean
    public Binding labReportReadyBinding() {
        return BindingBuilder.bind(labReportReadyQueue()).to(hospitalEventsExchange()).with(LAB_REPORT_READY_ROUTING_KEY);
    }

    @Bean
    public Queue radiologyReportReadyQueue() {
        return new Queue(RADIOLOGY_REPORT_READY_QUEUE, true);
    }

    @Bean
    public Binding radiologyReportReadyBinding() {
        return BindingBuilder.bind(radiologyReportReadyQueue()).to(hospitalEventsExchange()).with(RADIOLOGY_REPORT_READY_ROUTING_KEY);
    }

    /** JSON (not Java-serialization) so messages stay language-agnostic and readable on the RabbitMQ management UI. */
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}
