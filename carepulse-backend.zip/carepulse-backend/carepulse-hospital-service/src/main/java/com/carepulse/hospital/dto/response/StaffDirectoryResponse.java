package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffDirectoryResponse {
    private Long staffProfileId;
    private Long userId;
    private String fullName;
    private UserRole role;
    private String qualification;
    private Long departmentId;
    private String departmentName;
    private boolean active;
}
