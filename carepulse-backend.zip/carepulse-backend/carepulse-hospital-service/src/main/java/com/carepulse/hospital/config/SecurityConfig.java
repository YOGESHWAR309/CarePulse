package com.carepulse.hospital.config;

import com.carepulse.hospital.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Stateless JWT-based security for Hospital Service. Coarse role gating is
 * done here per path prefix; the FINE-grained rules (e.g. "a doctor may
 * only edit THEIR OWN availability", "a patient may only view THEIR OWN
 * medical records") are enforced in the service layer by comparing the
 * authenticated userId against the resource's owning userId - a path-level
 * rule alone can never express that ownership check.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // Public browsing - matches the Gateway's open-endpoint allowlist so these
                        // work identically whether hit through the Gateway or this service directly.
                        .requestMatchers(
                                "/api/hospital/departments",
                                "/api/hospital/departments/**",
                                "/api/hospital/doctors/public/**",
                                "/swagger-ui/**",
                                "/v3/api-docs/**",
                                "/actuator/**"
                        ).permitAll()

                        // Admin-only department and staff-lifecycle management
                        .requestMatchers("/api/hospital/admin/**").hasRole("ADMIN")

                        // Doctor-only own-availability and consultation workflow
                        .requestMatchers("/api/hospital/doctors/me/**").hasRole("DOCTOR")

                        // Dietician/Nutritionist-only own-availability and consultation workflow
                        .requestMatchers("/api/hospital/staff/me/**").hasAnyRole("DIETICIAN", "NUTRITIONIST")

                        // Receptionist-only front-desk operations
                        .requestMatchers("/api/hospital/receptionist/**").hasRole("RECEPTIONIST")

                        // Pharmacist-only dispensing workflow
                        .requestMatchers("/api/hospital/pharmacy/**").hasRole("PHARMACIST")

                        // Pathologist-only lab workflow
                        .requestMatchers("/api/hospital/pathology/**").hasRole("PATHOLOGIST")

                        // Radiologist-only scan workflow
                        .requestMatchers("/api/hospital/radiology/**").hasRole("RADIOLOGIST")

                        // Dietician-only diet plan workflow
                        .requestMatchers("/api/hospital/diet-plans/**").hasRole("DIETICIAN")

                        // Nutritionist-only nutrition plan workflow
                        .requestMatchers("/api/hospital/nutrition-plans/**").hasRole("NUTRITIONIST")

                        // Everything else (departments read, doctor directory, appointments, billing,
                        // medical records) requires SOME authenticated role; per-endpoint role/ownership
                        // checks are layered on top via @PreAuthorize and service-layer ownership checks.
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
