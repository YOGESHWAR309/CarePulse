package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for PUT /api/hospital/pharmacy/prescriptions/{id}/reject - a Pharmacist flagging a prescription they won't dispense (e.g. drug interaction concern). */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RejectPrescriptionRequest {

    @NotBlank(message = "Rejection reason is required")
    @Size(max = 500, message = "Reason must not exceed 500 characters")
    private String reason;
}
