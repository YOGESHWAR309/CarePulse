package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateMedicalRecordRequest;
import com.carepulse.hospital.dto.request.UpdateMedicalRecordRequest;
import com.carepulse.hospital.dto.response.MedicalRecordResponse;

import java.util.List;

public interface MedicalRecordService {

    /** [Doctor] Creates the one-and-only MedicalRecord for a given appointment - the doctor must own that appointment. */
    MedicalRecordResponse createMedicalRecord(Long doctorUserId, CreateMedicalRecordRequest request);

    /** [Doctor] Amends their own record's diagnosis/notes. */
    MedicalRecordResponse updateMedicalRecord(Long doctorUserId, Long medicalRecordId, UpdateMedicalRecordRequest request);

    MedicalRecordResponse getMedicalRecordById(Long medicalRecordId);

    /**
     * Looks up the (at most one) MedicalRecord already written for an appointment.
     * Lets the consultation workflow recover its medicalRecordId - e.g. after a
     * page refresh mid-consultation - instead of dead-ending into "A medical
     * record already exists for this appointment" on re-submit with no way back.
     */
    MedicalRecordResponse getMedicalRecordByAppointmentId(Long appointmentId);

    /** [Patient] Own medical history, most recent first. */
    List<MedicalRecordResponse> getMyMedicalRecords(Long patientUserId);

    /** [Doctor] Any patient's medical history, used to review before a consultation - "View Patient Medical History". */
    List<MedicalRecordResponse> getPatientMedicalRecords(Long patientId);
}
