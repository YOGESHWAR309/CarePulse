package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.DepartmentResponse;
import com.carepulse.hospital.entity.Department;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DepartmentMapper {
    DepartmentResponse toResponse(Department department);
}
