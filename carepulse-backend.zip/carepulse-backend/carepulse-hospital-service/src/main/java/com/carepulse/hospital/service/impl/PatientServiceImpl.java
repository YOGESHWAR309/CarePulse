package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateWalkInPatientRequest;
import com.carepulse.hospital.dto.request.UpdatePatientProfileRequest;
import com.carepulse.hospital.dto.response.PatientResponse;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.mapper.PatientMapper;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.service.PatientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PatientServiceImpl implements PatientService {

    private final PatientRepository patientRepository;
    private final PatientMapper patientMapper;

    @Override
    @Transactional
    public PatientResponse updateMyProfile(Long userId, UpdatePatientProfileRequest request) {
        Patient patient = patientRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));

        patient.setDateOfBirth(request.getDateOfBirth());
        patient.setGender(request.getGender());
        patient.setBloodGroup(request.getBloodGroup());
        patient.setAddress(request.getAddress());
        patient.setEmergencyContactName(request.getEmergencyContactName());
        patient.setEmergencyContactPhone(request.getEmergencyContactPhone());

        Patient saved = patientRepository.save(patient);
        log.info("Patient profile updated for userId={}", userId);
        return patientMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public PatientResponse getMyProfile(Long userId) {
        Patient patient = patientRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return patientMapper.toResponse(patient);
    }

    @Override
    @Transactional(readOnly = true)
    public PatientResponse getPatientById(Long patientId) {
        return patientMapper.toResponse(findByIdOrThrow(patientId));
    }

    @Override
    @Transactional
    public PatientResponse registerWalkInPatient(CreateWalkInPatientRequest request) {
        Patient patient = Patient.builder()
                .userId(null)
                .fullName(request.getFullName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .dateOfBirth(request.getDateOfBirth())
                .gender(request.getGender())
                .bloodGroup(request.getBloodGroup())
                .address(request.getAddress())
                .walkIn(true)
                .build();

        Patient saved = patientRepository.save(patient);
        log.info("Walk-in patient registered: {}", saved.getFullName());
        return patientMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PatientResponse> searchPatientsByName(String name) {
        return patientRepository.findByFullNameContainingIgnoreCase(name).stream().map(patientMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PatientResponse> getAllPatients() {
        return patientRepository.findAll().stream().map(patientMapper::toResponse).toList();
    }

    private Patient findByIdOrThrow(Long patientId) {
        return patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));
    }
}
