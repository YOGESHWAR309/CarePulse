package com.carepulse.hospital.dto.request;

import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

/**
 * Payload for POST /api/hospital/doctors/me/availability/bulk - lets a
 * doctor publish a whole week/fortnight/month of availability in a single
 * call instead of repeating {@link CreateAvailabilityRequest} once per day.
 * <p>
 * One {@link com.carepulse.hospital.entity.DoctorAvailability} row is
 * created for every date between {@code startDate} and {@code endDate}
 * (inclusive) whose day-of-week appears in {@code daysOfWeek} - e.g.
 * "every Mon/Wed/Fri from 2026-08-04 to 2026-08-15, 09:00-13:00" publishes
 * six separate days in one request.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBulkAvailabilityRequest {

    @NotNull(message = "Start date is required")
    @FutureOrPresent(message = "Start date cannot be in the past")
    private LocalDate startDate;

    @NotNull(message = "End date is required")
    @FutureOrPresent(message = "End date cannot be in the past")
    private LocalDate endDate;

    /** Which weekdays within the range to publish - e.g. [MONDAY, WEDNESDAY, FRIDAY]. Leave all 7 to publish every day in range. */
    @NotEmpty(message = "At least one day of week must be selected")
    private Set<DayOfWeek> daysOfWeek;

    @NotNull(message = "Start time is required")
    private LocalTime startTime;

    @NotNull(message = "End time is required")
    private LocalTime endTime;

    @NotNull(message = "Slot duration is required")
    @Min(value = 5, message = "Slot duration must be at least 5 minutes")
    private Integer slotDurationMinutes;

    @NotNull(message = "Maximum patients is required")
    @Min(value = 1, message = "Maximum patients must be at least 1")
    private Integer maximumPatients;

    @NotNull(message = "Consultation mode is required")
    private ConsultationMode consultationMode;
}
