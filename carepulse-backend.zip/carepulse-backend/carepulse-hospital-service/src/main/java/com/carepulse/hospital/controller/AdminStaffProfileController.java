package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.UpdateStaffProfileRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.StaffDirectoryResponse;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.service.StaffProfileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Admin management of Receptionist/Pharmacist/Pathologist/Radiologist/
 * Dietician/Nutritionist profiles - the counterpart to {@link DoctorController}'s
 * admin endpoints for Doctors.
 */
@RestController
@RequestMapping("/api/hospital/admin/staff")
@RequiredArgsConstructor//lambok
@Tag(name = "Admin - Staff Profiles", description = "Admin-only qualification/department management for non-doctor staff")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasRole('ADMIN')")
public class AdminStaffProfileController {

    private final StaffProfileService staffProfileService;

    @Operation(summary = "[Admin] Add/update a staff member's qualification and department assignment")
    @PutMapping("/{staffProfileId}")
    public ResponseEntity<ApiResponse<StaffDirectoryResponse>> updateStaffProfile(
            @PathVariable Long staffProfileId, @Valid @RequestBody UpdateStaffProfileRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Staff profile updated successfully",
                staffProfileService.updateStaffProfile(staffProfileId, request)));
    }

    @Operation(summary = "[Admin] Get a single staff profile by id")
    @GetMapping("/{staffProfileId}")
    public ResponseEntity<ApiResponse<StaffDirectoryResponse>> getStaffProfileById(@PathVariable Long staffProfileId) {
        return ResponseEntity.ok(ApiResponse.success("Staff profile fetched successfully",
                staffProfileService.getStaffProfileById(staffProfileId)));
    }

    @Operation(summary = "[Admin] View all staff of a given role")
    @GetMapping
    public ResponseEntity<ApiResponse<List<StaffDirectoryResponse>>> getStaffByRole(@RequestParam(required = false) UserRole role) {
        List<StaffDirectoryResponse> response = role != null
                ? staffProfileService.getStaffByRole(role)
                : staffProfileService.getAllStaff();
        return ResponseEntity.ok(ApiResponse.success("Staff fetched successfully", response));
    }
}
