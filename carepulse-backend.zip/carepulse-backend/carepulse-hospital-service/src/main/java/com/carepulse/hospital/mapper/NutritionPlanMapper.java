package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.NutritionPlanResponse;
import com.carepulse.hospital.entity.NutritionPlan;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface NutritionPlanMapper {

    @Mapping(target = "consultationAppointmentId", expression = "java(nutritionPlan.getConsultationAppointment().getId())")
    @Mapping(target = "patientId", expression = "java(nutritionPlan.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(nutritionPlan.getPatient().getFullName())")
    NutritionPlanResponse toResponse(NutritionPlan nutritionPlan);
}
