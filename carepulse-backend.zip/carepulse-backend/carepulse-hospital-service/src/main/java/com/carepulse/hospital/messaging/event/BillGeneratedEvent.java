package com.carepulse.hospital.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/** Published when a bill is generated after consultation completion, prompting the patient to pay. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillGeneratedEvent implements Serializable {
    private Long billId;
    private String patientEmail;
    private String patientName;
    private BigDecimal amount;
    private String invoiceNumber;
}
