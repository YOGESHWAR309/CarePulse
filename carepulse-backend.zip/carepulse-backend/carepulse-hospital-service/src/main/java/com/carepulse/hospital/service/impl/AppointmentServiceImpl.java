package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.*;
import com.carepulse.hospital.dto.response.AppointmentResponse;
import com.carepulse.hospital.entity.Appointment;
import com.carepulse.hospital.entity.Doctor;
import com.carepulse.hospital.entity.DoctorAvailability;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.AppointmentMapper;
import com.carepulse.hospital.messaging.NotificationEventPublisher;
import com.carepulse.hospital.messaging.event.AppointmentBookedEvent;
import com.carepulse.hospital.messaging.event.AppointmentCancelledEvent;
import com.carepulse.hospital.repository.AppointmentRepository;
import com.carepulse.hospital.repository.DoctorAvailabilityRepository;
import com.carepulse.hospital.repository.DoctorRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.service.AppointmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AppointmentServiceImpl implements AppointmentService {

    private static final List<AppointmentStatus> ACTIVE_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN);

    /**
     * Every status that means an exact clock-time slot is already spoken for -
     * everything except CANCELLED. Deliberately broader than ACTIVE_STATUSES above
     * (which only governs what can still be rescheduled/cancelled): a COMPLETED or
     * NO_SHOW appointment can no longer be touched by the patient, but it still
     * consumed that slot, so it must keep blocking new bookings against the same time.
     */
    private static final List<AppointmentStatus> SLOT_TAKEN_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN,
                    AppointmentStatus.IN_CONSULTATION, AppointmentStatus.COMPLETED, AppointmentStatus.NO_SHOW);

    private final AppointmentRepository appointmentRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final AppointmentMapper appointmentMapper;
    private final NotificationEventPublisher notificationEventPublisher;

    @Override
    @Transactional
    public AppointmentResponse bookAppointment(Long patientUserId, BookAppointmentRequest request) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));

        return doBooking(patient, patientUserId, request);
    }

    @Override
    @Transactional
    public AppointmentResponse bookAppointmentForPatient(Long receptionistUserId, BookAppointmentForPatientRequest request) {
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + request.getPatientId()));

        return doBooking(patient, receptionistUserId, request);
    }

    /**
     * Shared booking logic for both the patient self-service and
     * Receptionist-on-behalf-of flows. Validates the slot still has
     * capacity, consumes one unit of it, snapshots the slot's date/time
     * onto the Appointment row, and fires the confirmation event.
     */
    private AppointmentResponse doBooking(Patient patient, Long bookedByUserId, BookAppointmentRequest request) {
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + request.getDoctorId()));

        DoctorAvailability availability = availabilityRepository.findById(request.getAvailabilityId())
                .orElseThrow(() -> new ResourceNotFoundException("Availability not found with id: " + request.getAvailabilityId()));

        if (availability.getStatus() != AvailabilityStatus.ACTIVE) {
            throw new InvalidRequestException("This availability slot is no longer open for booking");
        }

        if (availability.getBookedCount() >= availability.getMaximumPatients()) {
            throw new InvalidRequestException("This slot is fully booked. Please choose a different time.");
        }

        boolean slotAlreadyTaken = appointmentRepository
                .findBookedStartTimesByAvailabilityId(availability.getId(), SLOT_TAKEN_STATUSES)
                .contains(request.getSlotStartTime());
        if (slotAlreadyTaken) {
            throw new InvalidRequestException("This slot has just been booked by someone else. Please choose a different time.");
        }

        LocalDate appointmentEndDate = request.getAppointmentDate();
        var slotEnd = request.getSlotStartTime().plusMinutes(availability.getSlotDurationMinutes());

        Appointment appointment = Appointment.builder()
                .patient(patient)
                .doctor(doctor)
                .availability(availability)
                .appointmentDate(appointmentEndDate)
                .startTime(request.getSlotStartTime())
                .endTime(slotEnd)
                .consultationMode(availability.getConsultationMode())
                .status(AppointmentStatus.BOOKED)
                .reasonForVisit(request.getReasonForVisit())
                .bookedByUserId(bookedByUserId)
                .build();

        Appointment saved = appointmentRepository.save(appointment);

        consumeSlotCapacity(availability);

        notificationEventPublisher.publishAppointmentBooked(
                AppointmentBookedEvent.builder()
                        .appointmentId(saved.getId())
                        .patientEmail(patient.getEmail())
                        .patientName(patient.getFullName())
                        .doctorEmail(doctor.getEmail())
                        .doctorName(doctor.getFullName())
                        .appointmentDate(saved.getAppointmentDate())
                        .startTime(saved.getStartTime())
                        .build());

        log.info("Appointment booked: id={} patient={} doctor={}", saved.getId(), patient.getFullName(), doctor.getFullName());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AppointmentResponse rescheduleAppointment(Long callerUserId, String callerRole, Long appointmentId, RescheduleAppointmentRequest request) {
        Appointment appointment = findAppointmentOrThrow(appointmentId);
        verifyOwnershipOrStaff(appointment, callerUserId, callerRole);

        if (!ACTIVE_STATUSES.contains(appointment.getStatus())) {
            throw new InvalidRequestException("Only booked/rescheduled/checked-in appointments can be rescheduled");
        }

        DoctorAvailability newAvailability = availabilityRepository.findById(request.getNewAvailabilityId())
                .orElseThrow(() -> new ResourceNotFoundException("Availability not found with id: " + request.getNewAvailabilityId()));

        if (newAvailability.getStatus() != AvailabilityStatus.ACTIVE
                || newAvailability.getBookedCount() >= newAvailability.getMaximumPatients()) {
            throw new InvalidRequestException("The requested new slot is not available");
        }

        boolean newSlotAlreadyTaken = appointmentRepository
                .findBookedStartTimesByAvailabilityId(newAvailability.getId(), SLOT_TAKEN_STATUSES)
                .contains(request.getNewSlotStartTime());
        if (newSlotAlreadyTaken) {
            throw new InvalidRequestException("The requested new slot is not available");
        }

        // Release the OLD slot's capacity before consuming the new one.
        releaseSlotCapacity(appointment.getAvailability());

        appointment.setAvailability(newAvailability);
        appointment.setAppointmentDate(request.getNewAppointmentDate());
        appointment.setStartTime(request.getNewSlotStartTime());
        appointment.setEndTime(request.getNewSlotStartTime().plusMinutes(newAvailability.getSlotDurationMinutes()));
        appointment.setConsultationMode(newAvailability.getConsultationMode());
        appointment.setStatus(AppointmentStatus.RESCHEDULED);

        consumeSlotCapacity(newAvailability);

        Appointment saved = appointmentRepository.save(appointment);
        log.info("Appointment rescheduled: id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AppointmentResponse cancelAppointment(Long callerUserId, String callerRole, Long appointmentId, CancelAppointmentRequest request) {
        Appointment appointment = findAppointmentOrThrow(appointmentId);
        verifyOwnershipOrStaff(appointment, callerUserId, callerRole);

        if (!ACTIVE_STATUSES.contains(appointment.getStatus())) {
            throw new InvalidRequestException("Only booked/rescheduled/checked-in appointments can be cancelled");
        }

        releaseSlotCapacity(appointment.getAvailability());

        appointment.setStatus(AppointmentStatus.CANCELLED);
        appointment.setCancelReason(request.getReason());
        appointment.setCancelledByRole(callerRole);

        Appointment saved = appointmentRepository.save(appointment);

        notificationEventPublisher.publishAppointmentCancelled(
                AppointmentCancelledEvent.builder()
                        .appointmentId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .doctorEmail(saved.getDoctor().getEmail())
                        .doctorName(saved.getDoctor().getFullName())
                        .appointmentDate(saved.getAppointmentDate())
                        .startTime(saved.getStartTime())
                        .cancelledBy(callerRole)
                        .build());

        log.info("Appointment cancelled: id={} by={}", saved.getId(), callerRole);
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AppointmentResponse checkIn(Long appointmentId) {
        Appointment appointment = findAppointmentOrThrow(appointmentId);

        if (!ACTIVE_STATUSES.contains(appointment.getStatus())) {
            throw new InvalidRequestException("Only booked/rescheduled appointments can be checked in");
        }

        appointment.setStatus(AppointmentStatus.CHECKED_IN);
        appointment.setCheckedInAt(LocalDateTime.now());

        Appointment saved = appointmentRepository.save(appointment);
        log.info("Patient checked in for appointment id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AppointmentResponse checkOut(Long appointmentId) {
        Appointment appointment = findAppointmentOrThrow(appointmentId);

        if (appointment.getCheckedInAt() == null) {
            throw new InvalidRequestException("Patient must be checked in before they can be checked out");
        }

        appointment.setCheckedOutAt(LocalDateTime.now());

        Appointment saved = appointmentRepository.save(appointment);
        log.info("Patient checked out for appointment id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AppointmentResponse completeConsultation(Long doctorUserId, Long appointmentId) {
        Appointment appointment = findAppointmentOrThrow(appointmentId);

        if (!appointment.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only complete consultations for your own appointments");
        }

        if (appointment.getStatus() == AppointmentStatus.CANCELLED || appointment.getStatus() == AppointmentStatus.COMPLETED) {
            throw new InvalidRequestException("This appointment cannot be completed from its current status: " + appointment.getStatus());
        }

        appointment.setStatus(AppointmentStatus.COMPLETED);

        Appointment saved = appointmentRepository.save(appointment);
        log.info("Consultation completed for appointment id={}", saved.getId());
        return appointmentMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public AppointmentResponse getAppointmentById(Long appointmentId) {
        return appointmentMapper.toResponse(findAppointmentOrThrow(appointmentId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getMyAppointments(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return appointmentRepository.findByPatientIdOrderByAppointmentDateDescStartTimeDesc(patient.getId())
                .stream().map(appointmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getDoctorTodayAppointments(Long doctorUserId) {
        Doctor doctor = findDoctorByUserId(doctorUserId);
        return appointmentRepository.findByDoctorIdAndAppointmentDateOrderByStartTimeAsc(doctor.getId(), LocalDate.now())
                .stream().map(appointmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getDoctorUpcomingAppointments(Long doctorUserId) {
        Doctor doctor = findDoctorByUserId(doctorUserId);
        return appointmentRepository
                .findByDoctorIdAndAppointmentDateGreaterThanEqualAndStatusInOrderByAppointmentDateAscStartTimeAsc(
                        doctor.getId(), LocalDate.now(), ACTIVE_STATUSES)
                .stream().map(appointmentMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getAppointmentQueue(LocalDate date) {
        return appointmentRepository.findByAppointmentDateOrderByStartTimeAsc(date)
                .stream().map(appointmentMapper::toResponse).toList();
    }

    /** Increments booked-count on the block and auto-flips it to FULLY_BOOKED once capacity is hit. */
    private void consumeSlotCapacity(DoctorAvailability availability) {
        availability.setBookedCount(availability.getBookedCount() + 1);
        if (availability.getBookedCount() >= availability.getMaximumPatients()) {
            availability.setStatus(AvailabilityStatus.FULLY_BOOKED);
        }
        availabilityRepository.save(availability);
    }

    /** Decrements booked-count and, if the block was FULLY_BOOKED purely due to capacity, reopens it to ACTIVE. */
    private void releaseSlotCapacity(DoctorAvailability availability) {
        availability.setBookedCount(Math.max(0, availability.getBookedCount() - 1));
        if (availability.getStatus() == AvailabilityStatus.FULLY_BOOKED
                && availability.getBookedCount() < availability.getMaximumPatients()) {
            availability.setStatus(AvailabilityStatus.ACTIVE);
        }
        availabilityRepository.save(availability);
    }

    /**
     * Patients may only act on their OWN appointment (matched by the
     * Patient row's userId); Receptionist and Admin may act on any
     * appointment regardless of ownership.
     */
    private void verifyOwnershipOrStaff(Appointment appointment, Long callerUserId, String callerRole) {
        boolean isStaff = "RECEPTIONIST".equals(callerRole) || "ADMIN".equals(callerRole);
        if (isStaff) {
            return;
        }

        Long owningPatientUserId = appointment.getPatient().getUserId();
        if (owningPatientUserId == null || !owningPatientUserId.equals(callerUserId)) {
            throw new UnauthorizedActionException("You can only manage your own appointments");
        }
    }

    private Appointment findAppointmentOrThrow(Long appointmentId) {
        return appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + appointmentId));
    }

    private Doctor findDoctorByUserId(Long userId) {
        return doctorRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor profile not found for the logged-in user"));
    }
}
