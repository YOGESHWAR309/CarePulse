package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateMedicalRecordRequest;
import com.carepulse.hospital.dto.request.UpdateMedicalRecordRequest;
import com.carepulse.hospital.dto.response.MedicalRecordResponse;
import com.carepulse.hospital.entity.Appointment;
import com.carepulse.hospital.entity.MedicalRecord;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.exception.DuplicateResourceException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.MedicalRecordMapper;
import com.carepulse.hospital.repository.AppointmentRepository;
import com.carepulse.hospital.repository.MedicalRecordRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.service.MedicalRecordService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class MedicalRecordServiceImpl implements MedicalRecordService {

    private final MedicalRecordRepository medicalRecordRepository;
    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final MedicalRecordMapper medicalRecordMapper;

    @Override
    @Transactional
    public MedicalRecordResponse createMedicalRecord(Long doctorUserId, CreateMedicalRecordRequest request) {
        Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + request.getAppointmentId()));

        if (!appointment.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only create medical records for your own appointments");
        }

        if (medicalRecordRepository.existsByAppointmentId(appointment.getId())) {
            throw new DuplicateResourceException("A medical record already exists for this appointment. Use update instead.");
        }

        MedicalRecord record = MedicalRecord.builder()
                .appointment(appointment)
                .patient(appointment.getPatient())
                .doctor(appointment.getDoctor())
                .symptoms(request.getSymptoms())
                .diagnosis(request.getDiagnosis())
                .consultationNotes(request.getConsultationNotes())
                .build();

        MedicalRecord saved = medicalRecordRepository.save(record);
        log.info("Medical record created for appointmentId={}", appointment.getId());
        return medicalRecordMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public MedicalRecordResponse updateMedicalRecord(Long doctorUserId, Long medicalRecordId, UpdateMedicalRecordRequest request) {
        MedicalRecord record = findOwnedRecordOrThrow(doctorUserId, medicalRecordId);

        record.setSymptoms(request.getSymptoms());
        record.setDiagnosis(request.getDiagnosis());
        record.setConsultationNotes(request.getConsultationNotes());

        MedicalRecord saved = medicalRecordRepository.save(record);
        log.info("Medical record updated: id={}", saved.getId());
        return medicalRecordMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public MedicalRecordResponse getMedicalRecordById(Long medicalRecordId) {
        return medicalRecordMapper.toResponse(findByIdOrThrow(medicalRecordId));
    }

    @Override
    @Transactional(readOnly = true)
    public MedicalRecordResponse getMedicalRecordByAppointmentId(Long appointmentId) {
        MedicalRecord record = medicalRecordRepository.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("No medical record exists yet for appointment id: " + appointmentId));
        return medicalRecordMapper.toResponse(record);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MedicalRecordResponse> getMyMedicalRecords(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return medicalRecordRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(medicalRecordMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<MedicalRecordResponse> getPatientMedicalRecords(Long patientId) {
        return medicalRecordRepository.findByPatientIdOrderByCreatedAtDesc(patientId)
                .stream().map(medicalRecordMapper::toResponse).toList();
    }

    private MedicalRecord findByIdOrThrow(Long medicalRecordId) {
        return medicalRecordRepository.findById(medicalRecordId)
                .orElseThrow(() -> new ResourceNotFoundException("Medical record not found with id: " + medicalRecordId));
    }

    private MedicalRecord findOwnedRecordOrThrow(Long doctorUserId, Long medicalRecordId) {
        MedicalRecord record = findByIdOrThrow(medicalRecordId);
        if (!record.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only update your own medical records");
        }
        return record;
    }
}
