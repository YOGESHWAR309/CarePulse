package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateWalkInPatientRequest;
import com.carepulse.hospital.dto.request.UpdatePatientProfileRequest;
import com.carepulse.hospital.dto.response.PatientResponse;

import java.util.List;

/**
 * Patient clinical-profile management. Self-registered patients get their
 * base row auto-created by {@link com.carepulse.hospital.messaging.listener.PatientRegisteredEventListener};
 * this service fills in extended clinical fields and provides the
 * Receptionist-facing walk-in creation + search.
 */
public interface PatientService {

    /** Patient fills in DOB/gender/blood-group/address/emergency contact - fields Auth Service's registration form never collected. */
    PatientResponse updateMyProfile(Long userId, UpdatePatientProfileRequest request);

    PatientResponse getMyProfile(Long userId);

    PatientResponse getPatientById(Long patientId);

    /** [Receptionist] Registers a walk-in patient with no Auth Service login. */
    PatientResponse registerWalkInPatient(CreateWalkInPatientRequest request);

    /** [Receptionist] Simple name-based search across all patients (walk-in and self-registered alike). */
    List<PatientResponse> searchPatientsByName(String name);

    /** [Admin] Every patient in the system. */
    List<PatientResponse> getAllPatients();
}
