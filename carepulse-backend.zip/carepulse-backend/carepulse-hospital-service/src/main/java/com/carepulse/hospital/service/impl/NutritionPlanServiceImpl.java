package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateNutritionPlanRequest;
import com.carepulse.hospital.dto.request.UpdateNutritionPlanRequest;
import com.carepulse.hospital.dto.response.NutritionPlanResponse;
import com.carepulse.hospital.entity.ConsultationAppointment;
import com.carepulse.hospital.entity.NutritionPlan;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.exception.DuplicateResourceException;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.NutritionPlanMapper;
import com.carepulse.hospital.repository.ConsultationAppointmentRepository;
import com.carepulse.hospital.repository.NutritionPlanRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.NutritionPlanService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class NutritionPlanServiceImpl implements NutritionPlanService {

    private final NutritionPlanRepository nutritionPlanRepository;
    private final PatientRepository patientRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final ConsultationAppointmentRepository consultationAppointmentRepository;
    private final NutritionPlanMapper nutritionPlanMapper;

    /**
     * Requires the consultation appointment to belong to the calling
     * Nutritionist and to be COMPLETED - mirrors {@link DietPlanServiceImpl#createDietPlan}.
     */
    @Override
    @Transactional
    public NutritionPlanResponse createNutritionPlan(Long nutritionistUserId, CreateNutritionPlanRequest request) {
        ConsultationAppointment appointment = consultationAppointmentRepository.findById(request.getConsultationAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Consultation appointment not found with id: " + request.getConsultationAppointmentId()));

        if (!appointment.getStaffProfile().getUserId().equals(nutritionistUserId)) {
            throw new UnauthorizedActionException("You can only write a nutrition plan for your own consultations");
        }

        if (appointment.getStatus() != AppointmentStatus.COMPLETED) {
            throw new InvalidRequestException("The consultation must be marked COMPLETED before a nutrition plan can be written");
        }

        if (nutritionPlanRepository.existsByConsultationAppointmentId(appointment.getId())) {
            throw new DuplicateResourceException("A nutrition plan already exists for this consultation. Use update instead.");
        }

        Patient patient = appointment.getPatient();
        String nutritionistName = staffProfileRepository.findByUserId(nutritionistUserId)
                .map(profile -> profile.getFullName())
                .orElse("Nutritionist");

        NutritionPlan nutritionPlan = NutritionPlan.builder()
                .consultationAppointment(appointment)
                .patient(patient)
                .nutritionistUserId(nutritionistUserId)
                .nutritionistName(nutritionistName)
                .planDetails(request.getPlanDetails())
                .build();

        NutritionPlan saved = nutritionPlanRepository.save(nutritionPlan);
        log.info("Nutrition plan created for consultationAppointmentId={} by nutritionistUserId={}", appointment.getId(), nutritionistUserId);
        return nutritionPlanMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public NutritionPlanResponse updateNutritionPlan(Long nutritionistUserId, Long nutritionPlanId, UpdateNutritionPlanRequest request) {
        NutritionPlan nutritionPlan = nutritionPlanRepository.findById(nutritionPlanId)
                .orElseThrow(() -> new ResourceNotFoundException("Nutrition plan not found with id: " + nutritionPlanId));

        if (!nutritionPlan.getNutritionistUserId().equals(nutritionistUserId)) {
            throw new UnauthorizedActionException("You can only update your own nutrition plans");
        }

        nutritionPlan.setPlanDetails(request.getPlanDetails());

        NutritionPlan saved = nutritionPlanRepository.save(nutritionPlan);
        log.info("Nutrition plan updated: id={}", saved.getId());
        return nutritionPlanMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NutritionPlanResponse> getMyNutritionPlans(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return nutritionPlanRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(nutritionPlanMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<NutritionPlanResponse> getPatientNutritionPlans(Long patientId) {
        return nutritionPlanRepository.findByPatientIdOrderByCreatedAtDesc(patientId)
                .stream().map(nutritionPlanMapper::toResponse).toList();
    }
}
