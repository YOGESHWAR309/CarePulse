package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateRadiologyRequest;
import com.carepulse.hospital.dto.request.UploadScanImageRequest;
import com.carepulse.hospital.dto.response.RadiologyResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import com.carepulse.hospital.entity.MedicalRecord;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.entity.RadiologyRequest;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.ReportStatus;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.RadiologyMapper;
import com.carepulse.hospital.messaging.NotificationEventPublisher;
import com.carepulse.hospital.messaging.event.RadiologyReportReadyEvent;
import com.carepulse.hospital.repository.MedicalRecordRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.RadiologyRequestRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.RadiologyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class RadiologyServiceImpl implements RadiologyService {

    private static final List<ReportStatus> OPEN_STATUSES = List.of(ReportStatus.REQUESTED, ReportStatus.IN_PROGRESS);

    private final RadiologyRequestRepository radiologyRequestRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final RadiologyMapper radiologyMapper;
    private final NotificationEventPublisher notificationEventPublisher;

    @Override
    @Transactional
    public RadiologyResponse createRadiologyRequest(Long doctorUserId, CreateRadiologyRequest request) {
        MedicalRecord medicalRecord = medicalRecordRepository.findById(request.getMedicalRecordId())
                .orElseThrow(() -> new ResourceNotFoundException("Medical record not found with id: " + request.getMedicalRecordId()));

        if (!medicalRecord.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only order scans against your own medical records");
        }

        StaffProfile radiologist = staffProfileRepository.findByUserId(request.getRadiologistId())
                .orElseThrow(() -> new ResourceNotFoundException("Radiologist not found with id: " + request.getRadiologistId()));
        if (radiologist.getRole() != UserRole.RADIOLOGIST || !radiologist.isActive()) {
            throw new InvalidRequestException("Selected staff member is not an active radiologist");
        }

        RadiologyRequest radiologyRequest = RadiologyRequest.builder()
                .medicalRecord(medicalRecord)
                .patient(medicalRecord.getPatient())
                .requestingDoctor(medicalRecord.getDoctor())
                .scanType(request.getScanType())
                .status(ReportStatus.REQUESTED)
                .assignedRadiologistUserId(radiologist.getUserId())
                .assignedRadiologistName(radiologist.getFullName())
                .build();

        RadiologyRequest saved = radiologyRequestRepository.save(radiologyRequest);
        log.info("Radiology scan requested: id={} type={} assignedRadiologist={}", saved.getId(), saved.getScanType(), radiologist.getFullName());
        return radiologyMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public RadiologyResponse uploadScanImages(Long radiologistUserId, Long radiologyId, UploadScanImageRequest request) {
        RadiologyRequest radiologyRequest = findByIdOrThrow(radiologyId);
        requireAssignedRadiologist(radiologyRequest, radiologistUserId);

        if (radiologyRequest.getStatus() != ReportStatus.REQUESTED && radiologyRequest.getStatus() != ReportStatus.IN_PROGRESS) {
            throw new InvalidRequestException("Scan images can only be uploaded for REQUESTED or IN_PROGRESS scans");
        }

        radiologyRequest.setImageUrl(request.getImageUrl());
        radiologyRequest.setStatus(ReportStatus.IN_PROGRESS);
        radiologyRequest.setProcessedByUserId(radiologistUserId);

        RadiologyRequest saved = radiologyRequestRepository.save(radiologyRequest);
        log.info("Scan images uploaded for radiology request id={}", saved.getId());
        return radiologyMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public RadiologyResponse uploadReport(Long radiologistUserId, Long radiologyId, String resultSummary, MultipartFile reportFile) {
        RadiologyRequest radiologyRequest = findByIdOrThrow(radiologyId);
        requireAssignedRadiologist(radiologyRequest, radiologistUserId);

        if (radiologyRequest.getImageUrl() == null) {
            throw new InvalidRequestException("Scan images must be uploaded before a report can be written");
        }
        if (resultSummary == null || resultSummary.isBlank()) {
            throw new InvalidRequestException("Result summary is required");
        }

        byte[] fileBytes = readPdfBytesOrThrow(reportFile);

        radiologyRequest.setResultSummary(resultSummary);
        radiologyRequest.setReportFileData(fileBytes);
        radiologyRequest.setReportFileName(reportFile.getOriginalFilename());
        radiologyRequest.setReportContentType(reportFile.getContentType());
        radiologyRequest.setStatus(ReportStatus.IN_PROGRESS);
        radiologyRequest.setProcessedByUserId(radiologistUserId);

        RadiologyRequest saved = radiologyRequestRepository.save(radiologyRequest);
        log.info("Report uploaded for radiology request id={}", saved.getId());
        return radiologyMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public RadiologyResponse markReportReady(Long radiologistUserId, Long radiologyId) {
        RadiologyRequest radiologyRequest = findByIdOrThrow(radiologyId);
        requireAssignedRadiologist(radiologyRequest, radiologistUserId);

        if (radiologyRequest.getReportFileData() == null) {
            throw new InvalidRequestException("A report must be uploaded before it can be marked ready");
        }

        radiologyRequest.setStatus(ReportStatus.READY);
        radiologyRequest.setProcessedByUserId(radiologistUserId);
        radiologyRequest.setReadyAt(LocalDateTime.now());

        RadiologyRequest saved = radiologyRequestRepository.save(radiologyRequest);

        notificationEventPublisher.publishRadiologyReportReady(
                RadiologyReportReadyEvent.builder()
                        .reportId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .scanType(saved.getScanType())
                        .build());

        log.info("Radiology report marked READY: id={}", saved.getId());
        return radiologyMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public RadiologyResponse getRadiologyRequestById(Long radiologyId) {
        return radiologyMapper.toResponse(findByIdOrThrow(radiologyId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<RadiologyResponse> getRequestedScans(Long radiologistUserId) {
        return radiologyRequestRepository.findByAssignedRadiologistAndStatusIn(radiologistUserId, OPEN_STATUSES)
                .stream().map(radiologyMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<RadiologyResponse> getMyRadiologyRequests(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return radiologyRequestRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(radiologyMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ReportFileDownload getReportFile(Long userId, String role, Long radiologyId) {
        RadiologyRequest radiologyRequest = findByIdOrThrow(radiologyId);

        boolean allowed = switch (role) {
            case "RADIOLOGIST" -> userId.equals(radiologyRequest.getAssignedRadiologistUserId());
            case "DOCTOR" -> userId.equals(radiologyRequest.getRequestingDoctor().getUserId());
            case "PATIENT" -> userId.equals(radiologyRequest.getPatient().getUserId());
            default -> false;
        };
        if (!allowed) {
            throw new UnauthorizedActionException("You do not have access to this report");
        }
        if (radiologyRequest.getReportFileData() == null) {
            throw new ResourceNotFoundException("No report has been uploaded for this scan yet");
        }

        return new ReportFileDownload(radiologyRequest.getReportFileData(), radiologyRequest.getReportFileName(), radiologyRequest.getReportContentType());
    }

    private void requireAssignedRadiologist(RadiologyRequest radiologyRequest, Long radiologistUserId) {
        if (!radiologistUserId.equals(radiologyRequest.getAssignedRadiologistUserId())) {
            throw new UnauthorizedActionException("You are not the radiologist assigned to this scan");
        }
    }

    private byte[] readPdfBytesOrThrow(MultipartFile reportFile) {
        if (reportFile == null || reportFile.isEmpty()) {
            throw new InvalidRequestException("A report PDF file is required");
        }
        String contentType = reportFile.getContentType();
        if (contentType == null || !contentType.equalsIgnoreCase("application/pdf")) {
            throw new InvalidRequestException("Only PDF files are allowed for reports");
        }
        try {
            return reportFile.getBytes();
        } catch (IOException e) {
            throw new InvalidRequestException("Unable to read the uploaded report file");
        }
    }

    private RadiologyRequest findByIdOrThrow(Long radiologyId) {
        return radiologyRequestRepository.findById(radiologyId)
                .orElseThrow(() -> new ResourceNotFoundException("Radiology request not found with id: " + radiologyId));
    }
}
