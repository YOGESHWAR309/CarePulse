package com.carepulse.hospital.messaging;

import com.carepulse.hospital.config.RabbitMQConfig;
import com.carepulse.hospital.messaging.event.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/**
 * Single point through which Hospital Service publishes clinical/billing
 * events to RabbitMQ for Notification Service to act on. Keeps AMQP details
 * (exchange name, routing keys) out of every service class that needs to
 * fire a notification.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class NotificationEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    /** Fired right after a booking succeeds - both patient and doctor get an email. */
    public void publishAppointmentBooked(AppointmentBookedEvent event) {
        log.info("Publishing AppointmentBookedEvent for appointmentId={}", event.getAppointmentId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.APPOINTMENT_BOOKED_ROUTING_KEY, event);
    }

    /** Fired right after a cancellation, regardless of whether the patient or the receptionist/doctor initiated it. */
    public void publishAppointmentCancelled(AppointmentCancelledEvent event) {
        log.info("Publishing AppointmentCancelledEvent for appointmentId={}", event.getAppointmentId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.APPOINTMENT_CANCELLED_ROUTING_KEY, event);
    }

    /** Fired when a doctor finalizes a prescription. */
    public void publishPrescriptionGenerated(PrescriptionGeneratedEvent event) {
        log.info("Publishing PrescriptionGeneratedEvent for prescriptionId={}", event.getPrescriptionId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.PRESCRIPTION_GENERATED_ROUTING_KEY, event);
    }

    /** Fired the moment a Bill row is created after consultation completion. */
    public void publishBillGenerated(BillGeneratedEvent event) {
        log.info("Publishing BillGeneratedEvent for billId={}", event.getBillId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.BILL_GENERATED_ROUTING_KEY, event);
    }

    /** Fired immediately after Razorpay confirms payment and the Bill status flips to PAID. */
    public void publishBillPaid(BillPaidEvent event) {
        log.info("Publishing BillPaidEvent for billId={}", event.getBillId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.BILL_PAID_ROUTING_KEY, event);
    }

    /** Fired when a Pathologist marks a lab report READY. */
    public void publishLabReportReady(LabReportReadyEvent event) {
        log.info("Publishing LabReportReadyEvent for reportId={}", event.getReportId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.LAB_REPORT_READY_ROUTING_KEY, event);
    }

    /** Fired when a Radiologist marks a scan report READY. */
    public void publishRadiologyReportReady(RadiologyReportReadyEvent event) {
        log.info("Publishing RadiologyReportReadyEvent for reportId={}", event.getReportId());
        rabbitTemplate.convertAndSend(RabbitMQConfig.HOSPITAL_EVENTS_EXCHANGE,
                RabbitMQConfig.RADIOLOGY_REPORT_READY_ROUTING_KEY, event);
    }
}
