package com.carepulse.hospital.enums;

/** Payment lifecycle of a Bill, driven by the Razorpay integration. */
public enum BillStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED
}
