package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.RadiologyRequest;
import com.carepulse.hospital.enums.ReportStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RadiologyRequestRepository extends JpaRepository<RadiologyRequest, Long> {

    /**
     * Radiologist's "View Scan Requests" queue - only requests assigned to THEM (assignment is
     * chosen by the ordering doctor at creation time) that are still open work (not yet READY).
     * Fetch-joins patient/requestingDoctor - RadiologyMapper reads both per row.
     */
    @Query("SELECT r FROM RadiologyRequest r JOIN FETCH r.patient JOIN FETCH r.requestingDoctor " +
            "WHERE r.assignedRadiologistUserId = :radiologistUserId AND r.status IN :statuses ORDER BY r.createdAt ASC")
    List<RadiologyRequest> findByAssignedRadiologistAndStatusIn(
            @Param("radiologistUserId") Long radiologistUserId, @Param("statuses") List<ReportStatus> statuses);

    /** Patient's "View Radiology Reports" screen. */
    @Query("SELECT r FROM RadiologyRequest r JOIN FETCH r.patient JOIN FETCH r.requestingDoctor " +
            "WHERE r.patient.id = :patientId ORDER BY r.createdAt DESC")
    List<RadiologyRequest> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);
}
