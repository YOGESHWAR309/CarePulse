package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreatePrescriptionRequest;
import com.carepulse.hospital.dto.request.RejectPrescriptionRequest;
import com.carepulse.hospital.dto.response.PrescriptionResponse;

import java.util.List;

/**
 * Prescription lifecycle: a Doctor writes it (PENDING), then a Pharmacist
 * verifies it (VERIFIED) and dispenses the medicines (DISPENSED), or
 * rejects it with a reason if something's wrong (REJECTED).
 */
public interface PrescriptionService {

    /** [Doctor] Writes a prescription against a MedicalRecord they own. */
    PrescriptionResponse createPrescription(Long doctorUserId, CreatePrescriptionRequest request);

    PrescriptionResponse getPrescriptionById(Long prescriptionId);

    /** [Patient] Own prescriptions. */
    List<PrescriptionResponse> getMyPrescriptions(Long patientUserId);

    /** [Pharmacist] The work queue - every PENDING prescription awaiting review. */
    List<PrescriptionResponse> getPendingPrescriptions();

    /** [Pharmacist] Confirms the prescription is legitimate/safe to fulfill. */
    PrescriptionResponse verifyPrescription(Long pharmacistUserId, Long prescriptionId);

    /** [Pharmacist] Marks medicines as handed over to the patient - only allowed after verification. */
    PrescriptionResponse dispensePrescription(Long pharmacistUserId, Long prescriptionId);

    /** [Pharmacist] Flags a prescription as one they will not fulfill. */
    PrescriptionResponse rejectPrescription(Long pharmacistUserId, Long prescriptionId, RejectPrescriptionRequest request);
}
