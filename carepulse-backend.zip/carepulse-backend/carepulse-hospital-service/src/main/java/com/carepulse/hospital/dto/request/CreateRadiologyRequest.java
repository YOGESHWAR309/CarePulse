package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for POST /api/hospital/doctors/me/radiology - a doctor ordering a scan. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateRadiologyRequest {

    @NotNull(message = "Medical record id is required")
    private Long medicalRecordId;

    @NotBlank(message = "Scan type is required")
    @Size(max = 100, message = "Scan type must not exceed 100 characters")
    private String scanType;

    /** userId of the Radiologist to assign this scan to - selected by the doctor from a name search (GET /doctors/me/staff/search). */
    @NotNull(message = "A radiologist must be selected")
    private Long radiologistId;
}
