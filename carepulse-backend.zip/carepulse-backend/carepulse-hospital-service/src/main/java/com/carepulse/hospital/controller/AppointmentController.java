package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.*;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.AppointmentResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * The core appointment-booking workflow. Split by caller role: patients
 * book/reschedule/cancel their OWN appointments; Receptionists do the same
 * on behalf of any patient plus check-in/out/queue management; Doctors get
 * read-only "today's"/"upcoming" views plus consultation completion.
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Appointments", description = "Booking, rescheduling, cancellation, check-in/out, and doctor/receptionist views")
@SecurityRequirement(name = "bearerAuth")
public class AppointmentController {

    private final AppointmentService appointmentService;

    // ================= Patient =================

    @Operation(summary = "[Patient] Book an appointment for myself")
    @PostMapping("/patients/me/appointments")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> bookAppointment(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody BookAppointmentRequest request) {
        AppointmentResponse response = appointmentService.bookAppointment(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Appointment booked successfully", response));
    }

    @Operation(summary = "[Patient] View my own appointment history")
    @GetMapping("/patients/me/appointments")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<AppointmentResponse>>> getMyAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Appointments fetched successfully", appointmentService.getMyAppointments(user.userId())));
    }

    // ================= Patient or Receptionist (ownership enforced in service layer) =================

    @Operation(summary = "[Patient/Receptionist] Reschedule an appointment")
    @PutMapping("/appointments/{appointmentId}/reschedule")
    @PreAuthorize("hasAnyRole('PATIENT', 'RECEPTIONIST')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> rescheduleAppointment(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long appointmentId,
            @Valid @RequestBody RescheduleAppointmentRequest request) {
        AppointmentResponse response = appointmentService.rescheduleAppointment(user.userId(), user.role(), appointmentId, request);
        return ResponseEntity.ok(ApiResponse.success("Appointment rescheduled successfully", response));
    }

    @Operation(summary = "[Patient/Receptionist] Cancel an appointment")
    @PutMapping("/appointments/{appointmentId}/cancel")
    @PreAuthorize("hasAnyRole('PATIENT', 'RECEPTIONIST')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> cancelAppointment(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long appointmentId,
            @Valid @RequestBody CancelAppointmentRequest request) {
        AppointmentResponse response = appointmentService.cancelAppointment(user.userId(), user.role(), appointmentId, request);
        return ResponseEntity.ok(ApiResponse.success("Appointment cancelled successfully", response));
    }

    @Operation(summary = "Get a single appointment by id")
    @GetMapping("/appointments/{appointmentId}")
    public ResponseEntity<ApiResponse<AppointmentResponse>> getAppointmentById(@PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Appointment fetched successfully", appointmentService.getAppointmentById(appointmentId)));
    }

    // ================= Doctor =================

    @Operation(summary = "[Doctor] View today's appointments")
    @GetMapping("/doctors/me/appointments/today")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<AppointmentResponse>>> getTodayAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Today's appointments fetched successfully", appointmentService.getDoctorTodayAppointments(user.userId())));
    }

    @Operation(summary = "[Doctor] View upcoming appointments")
    @GetMapping("/doctors/me/appointments/upcoming")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<AppointmentResponse>>> getUpcomingAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Upcoming appointments fetched successfully", appointmentService.getDoctorUpcomingAppointments(user.userId())));
    }

    @Operation(summary = "[Doctor] Mark a consultation as completed (required before billing)")
    @PutMapping("/doctors/me/appointments/{appointmentId}/complete")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> completeConsultation(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long appointmentId) {
        AppointmentResponse response = appointmentService.completeConsultation(user.userId(), appointmentId);
        return ResponseEntity.ok(ApiResponse.success("Consultation marked as completed", response));
    }

    // ================= Receptionist =================

    @Operation(summary = "[Receptionist] Book an appointment on behalf of a patient")
    @PostMapping("/receptionist/appointments")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> bookAppointmentForPatient(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody BookAppointmentForPatientRequest request) {
        AppointmentResponse response = appointmentService.bookAppointmentForPatient(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Appointment booked successfully", response));
    }

    @Operation(summary = "[Receptionist] Check in a patient who has arrived")
    @PutMapping("/receptionist/appointments/{appointmentId}/check-in")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> checkIn(@PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Patient checked in successfully", appointmentService.checkIn(appointmentId)));
    }

    @Operation(summary = "[Receptionist] Check out a patient after their visit")
    @PutMapping("/receptionist/appointments/{appointmentId}/check-out")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<AppointmentResponse>> checkOut(@PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Patient checked out successfully", appointmentService.checkOut(appointmentId)));
    }

    @Operation(summary = "[Receptionist] View the full appointment queue for a given day, across all doctors")
    @GetMapping("/receptionist/appointments/queue")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<List<AppointmentResponse>>> getAppointmentQueue(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(ApiResponse.success("Queue fetched successfully", appointmentService.getAppointmentQueue(date)));
    }
}
