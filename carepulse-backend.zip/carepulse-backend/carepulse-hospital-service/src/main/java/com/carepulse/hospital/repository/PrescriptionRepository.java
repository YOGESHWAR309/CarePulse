package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Prescription;
import com.carepulse.hospital.enums.PrescriptionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {

    /** Patient's own "View Prescriptions" screen. Fetch-joins patient/doctor - PrescriptionMapper reads both per row. */
    @Query("SELECT p FROM Prescription p JOIN FETCH p.patient JOIN FETCH p.doctor " +
            "WHERE p.patient.id = :patientId ORDER BY p.createdAt DESC")
    List<Prescription> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);

    /** Pharmacist's "View Prescriptions" queue, filterable by status (PENDING to work through, VERIFIED to dispense, etc). */
    @Query("SELECT p FROM Prescription p JOIN FETCH p.patient JOIN FETCH p.doctor " +
            "WHERE p.status = :status ORDER BY p.createdAt ASC")
    List<Prescription> findByStatusOrderByCreatedAtAsc(@Param("status") PrescriptionStatus status);
}
