package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * One block of time a doctor has published as bookable (e.g. "2026-08-10,
 * 09:00-13:00, 15-minute slots, max 16 patients"). Individual bookable slots
 * are computed on the fly from this block rather than pre-materialized as
 * rows, so changing slotDuration/maximumPatients doesn't require rewriting
 * hundreds of slot records.
 * <p>
 * Only the OWNING doctor may create/update/delete their own availability -
 * enforced in the service layer by comparing the caller's userId against
 * {@link Doctor#getUserId()}, never by trusting a doctorId passed in the request body.
 */
@Entity
@Table(name = "doctor_availabilities")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoctorAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor;

    @Column(nullable = false)
    private LocalDate availableDate;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private LocalTime endTime;

    @Column(nullable = false)
    private Integer slotDurationMinutes;

    /** Caps how many patients can be booked across this whole block (independent of how many discrete slots fit). */
    @Column(nullable = false)
    private Integer maximumPatients;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ConsultationMode consultationMode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private AvailabilityStatus status = AvailabilityStatus.ACTIVE;

    /** Running count of how many patients have booked against this block - compared to maximumPatients to auto-flip status to FULLY_BOOKED. */
    @Column(nullable = false)
    @Builder.Default
    private Integer bookedCount = 0;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
