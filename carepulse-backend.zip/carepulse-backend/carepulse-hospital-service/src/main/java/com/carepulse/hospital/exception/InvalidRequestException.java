package com.carepulse.hospital.exception;

/** Thrown for business-rule violations that aren't simple field validation - e.g. booking a fully-booked slot, cancelling an already-completed appointment. Mapped to HTTP 400. */
public class InvalidRequestException extends RuntimeException {
    public InvalidRequestException(String message) {
        super(message);
    }
}
