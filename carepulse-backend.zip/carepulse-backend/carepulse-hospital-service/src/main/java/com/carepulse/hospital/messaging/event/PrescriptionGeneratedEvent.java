package com.carepulse.hospital.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/** Published when a doctor finalizes a prescription, so the patient gets an email pointing them to view it. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PrescriptionGeneratedEvent implements Serializable {
    private Long prescriptionId;
    private String patientEmail;
    private String patientName;
    private String doctorName;
}
