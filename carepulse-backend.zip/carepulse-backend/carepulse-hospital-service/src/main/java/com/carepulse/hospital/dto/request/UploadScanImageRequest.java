package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for PUT /api/hospital/radiology/scans/{id}/images - a Radiologist uploading the raw scan image(s), separate from the written report. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadScanImageRequest {

    @NotBlank(message = "Image URL is required")
    @Size(max = 500, message = "Image URL must not exceed 500 characters")
    private String imageUrl;
}
