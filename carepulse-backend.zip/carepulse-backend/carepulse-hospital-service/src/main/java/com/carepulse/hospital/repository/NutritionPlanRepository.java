package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.NutritionPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NutritionPlanRepository extends JpaRepository<NutritionPlan, Long> {

    /** Patient's own "View Nutrition Plan" screen. Fetch-joins patient - NutritionPlanMapper reads patientName per row. */
    @Query("SELECT n FROM NutritionPlan n JOIN FETCH n.patient WHERE n.patient.id = :patientId ORDER BY n.createdAt DESC")
    List<NutritionPlan> findByPatientIdOrderByCreatedAtDesc(@Param("patientId") Long patientId);

    boolean existsByConsultationAppointmentId(Long consultationAppointmentId);
}
