package com.carepulse.hospital.security;

/**
 * Minimal identity of the calling user, extracted straight from JWT claims
 * (no database lookup needed - Hospital Service trusts what Auth Service
 * already signed). This is what {@code @AuthenticationPrincipal} resolves
 * to across every controller in this service.
 */
public record AuthenticatedUser(Long userId, String email, String role) {
}
