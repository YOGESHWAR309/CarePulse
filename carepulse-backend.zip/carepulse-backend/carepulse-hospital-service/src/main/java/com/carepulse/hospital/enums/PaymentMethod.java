package com.carepulse.hospital.enums;

/**
 * How a {@code Bill} was actually settled. Set the moment a bill transitions
 * to PAID - either by {@code verifyPayment} (Razorpay checkout, self-service)
 * or by {@code markPaidByCash} (Receptionist/Admin recording an in-person
 * cash payment, e.g. from a walk-in patient at the front desk).
 */
public enum PaymentMethod {
    ONLINE,
    CASH
}
