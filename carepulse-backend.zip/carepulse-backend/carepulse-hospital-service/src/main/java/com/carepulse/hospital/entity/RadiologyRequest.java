package com.carepulse.hospital.entity;

import com.carepulse.hospital.enums.ReportStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * A scan/imaging study a Doctor has requested, worked through by a
 * Radiologist. Distinct from {@link LabTestRequest} in having a separate
 * "scan images" upload step in addition to the written report.
 */
@Entity
@Table(name = "radiology_requests")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RadiologyRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medical_record_id", nullable = false)
    private MedicalRecord medicalRecord;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requesting_doctor_id", nullable = false)
    private Doctor requestingDoctor;

    @Column(nullable = false, length = 100)
    private String scanType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private ReportStatus status = ReportStatus.REQUESTED;

    /** userId of the Radiologist this request is assigned to, chosen by the ordering doctor at creation time (via staff search). */
    @Column(name = "assigned_radiologist_user_id")
    private Long assignedRadiologistUserId;

    /** Snapshot of the assigned Radiologist's name at assignment time, so responses don't need a join back to StaffProfile. */
    @Column(name = "assigned_radiologist_name", length = 200)
    private String assignedRadiologistName;

    /** URL/path to the uploaded scan image(s) - separate from the written report per the spec's distinct "Upload Scan Images" step. */
    @Column(length = 500)
    private String imageUrl;

    @Column(length = 2000)
    private String resultSummary;

    /** The uploaded report PDF's bytes, stored directly in the database. */
    @Lob
    @Column(name = "report_file_data", columnDefinition = "LONGBLOB")
    private byte[] reportFileData;

    @Column(name = "report_file_name", length = 255)
    private String reportFileName;

    @Column(name = "report_content_type", length = 100)
    private String reportContentType;

    private Long processedByUserId;

    private LocalDateTime readyAt;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
