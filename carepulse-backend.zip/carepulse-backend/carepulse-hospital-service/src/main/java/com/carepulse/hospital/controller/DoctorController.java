package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.UpdateDoctorRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.DoctorResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.DoctorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Doctor directory and clinical-profile management. The Doctor ROW itself
 * is auto-created when Admin creates the account in Auth Service
 * (see {@link com.carepulse.hospital.messaging.listener.StaffCreatedEventListener});
 * Admin then fills in clinical fields here.
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Doctors", description = "Doctor directory and clinical-profile management")
@SecurityRequirement(name = "bearerAuth")
public class DoctorController {

    private final DoctorService doctorService;

    @Operation(summary = "[Admin] Set/update a doctor's department, specialization, qualification, experience, and fee")
    @PutMapping("/admin/doctors/{doctorId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<DoctorResponse>> updateDoctorProfile(
            @PathVariable Long doctorId, @Valid @RequestBody UpdateDoctorRequest request) {
        DoctorResponse response = doctorService.updateDoctorProfile(doctorId, request);
        return ResponseEntity.ok(ApiResponse.success("Doctor profile updated successfully", response));
    }

    @Operation(summary = "[Admin] View all doctors")
    @GetMapping("/admin/doctors")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<DoctorResponse>>> getAllDoctors() {
        return ResponseEntity.ok(ApiResponse.success("Doctors fetched successfully", doctorService.getAllDoctors()));
    }

    @Operation(summary = "[Doctor] View my own clinical profile")
    @GetMapping("/doctors/me")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<DoctorResponse>> getMyProfile(@AuthenticationPrincipal AuthenticatedUser user) {
        DoctorResponse response = doctorService.getMyProfile(user.userId());
        return ResponseEntity.ok(ApiResponse.success("Profile fetched successfully", response));
    }

    @Operation(summary = "Get a single doctor's public profile (patients browsing before booking)")
    @GetMapping("/doctors/{doctorId}")
    public ResponseEntity<ApiResponse<DoctorResponse>> getDoctorById(@PathVariable Long doctorId) {
        return ResponseEntity.ok(ApiResponse.success("Doctor fetched successfully", doctorService.getDoctorById(doctorId)));
    }

    @Operation(summary = "View doctors belonging to a department (patient department -> doctor selection step)")
    @GetMapping("/departments/{departmentId}/doctors")
    public ResponseEntity<ApiResponse<List<DoctorResponse>>> getDoctorsByDepartment(@PathVariable Long departmentId) {
        return ResponseEntity.ok(ApiResponse.success("Doctors fetched successfully", doctorService.getDoctorsByDepartment(departmentId)));
    }
}
