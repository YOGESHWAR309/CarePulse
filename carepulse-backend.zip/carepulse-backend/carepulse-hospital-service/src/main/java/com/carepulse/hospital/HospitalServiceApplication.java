package com.carepulse.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * CarePulse - Hospital Service
 * <p>
 * The largest microservice: owns every clinical/operational module -
 * Departments, Doctors + Availability, Patients, Receptionist workflows,
 * Appointments, Medical Records, Prescriptions, Pathology, Radiology,
 * Pharmacy, Dietician/Nutritionist plans, and Billing (via Razorpay).
 * Backed by its own {@code hospital_db} MySQL database. Identity data
 * (name/email/password/role) is never duplicated here beyond a denormalized
 * read copy - Auth Service remains the single source of truth for who a
 * user is; this service owns what they DO in the hospital.
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class HospitalServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalServiceApplication.class, args);
    }
}
