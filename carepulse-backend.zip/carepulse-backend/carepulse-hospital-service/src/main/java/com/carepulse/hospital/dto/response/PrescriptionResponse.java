package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.PrescriptionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PrescriptionResponse {
    private Long id;
    private Long medicalRecordId;
    private Long patientId;
    private String patientName;
    private Long doctorId;
    private String doctorName;
    private PrescriptionStatus status;
    private List<PrescriptionItemResponse> items;
    private String rejectionReason;
    private LocalDateTime createdAt;
}
