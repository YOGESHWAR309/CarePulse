package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Payload for POST /api/hospital/nutrition-plans - a Nutritionist writing a plan against a completed consultation appointment. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateNutritionPlanRequest {

    @NotNull(message = "Consultation appointment id is required")
    private Long consultationAppointmentId;

    @NotBlank(message = "Plan details are required")
    @Size(max = 3000, message = "Plan details must not exceed 3000 characters")
    private String planDetails;
}
