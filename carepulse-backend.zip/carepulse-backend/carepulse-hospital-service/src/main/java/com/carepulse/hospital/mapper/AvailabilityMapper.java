package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.AvailabilityResponse;
import com.carepulse.hospital.entity.DoctorAvailability;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AvailabilityMapper {

    @Mapping(target = "doctorId", expression = "java(availability.getDoctor().getId())")
    @Mapping(target = "doctorName", expression = "java(availability.getDoctor().getFullName())")
    AvailabilityResponse toResponse(DoctorAvailability availability);
}
