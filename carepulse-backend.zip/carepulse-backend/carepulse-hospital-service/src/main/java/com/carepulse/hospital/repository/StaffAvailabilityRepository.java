package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.StaffAvailability;
import com.carepulse.hospital.enums.AvailabilityStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface StaffAvailabilityRepository extends JpaRepository<StaffAvailability, Long> {

    /** The staff member's own "View Availability" screen - every block regardless of status. */
    List<StaffAvailability> findByStaffProfileIdOrderByAvailableDateAscStartTimeAsc(Long staffProfileId);

    /** Patient-facing: every ACTIVE, future-dated block for a Dietician/Nutritionist. */
    List<StaffAvailability> findByStaffProfileIdAndStatusAndAvailableDateGreaterThanEqualOrderByAvailableDateAscStartTimeAsc(
            Long staffProfileId, AvailabilityStatus status, LocalDate fromDate);

    /** Patient-facing: concrete slots for one staff member on one specific date. */
    List<StaffAvailability> findByStaffProfileIdAndAvailableDateAndStatus(
            Long staffProfileId, LocalDate date, AvailabilityStatus status);

    /** Guards bulk publishing from creating a duplicate block if re-run with the same date range/time. */
    boolean existsByStaffProfileIdAndAvailableDateAndStartTimeAndEndTime(
            Long staffProfileId, LocalDate availableDate, java.time.LocalTime startTime, java.time.LocalTime endTime);
}
