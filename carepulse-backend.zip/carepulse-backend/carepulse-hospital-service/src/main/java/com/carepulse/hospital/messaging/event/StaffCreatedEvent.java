package com.carepulse.hospital.messaging.event;

import com.carepulse.hospital.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Mirrors {@code com.carepulse.auth.messaging.event.StaffCreatedEvent}.
 * Hospital Service's copy of this event is used ONLY to provision a
 * Doctor/StaffProfile row - the {@code temporaryPassword} field is present
 * for structural compatibility but deliberately never read or stored here
 * (Hospital Service has no business knowing credentials).
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffCreatedEvent implements Serializable {
    private Long userId;
    private String recipientEmail;
    private String recipientName;
    private UserRole role;
    private String temporaryPassword;
    private String qualification;
    private String specialization;
}
