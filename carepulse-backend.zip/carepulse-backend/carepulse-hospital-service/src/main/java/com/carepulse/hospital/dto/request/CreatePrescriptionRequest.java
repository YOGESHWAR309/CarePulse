package com.carepulse.hospital.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/** Payload for POST /api/hospital/doctors/me/prescriptions - a doctor writing a prescription against a MedicalRecord they just created. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreatePrescriptionRequest {

    @NotNull(message = "Medical record id is required")
    private Long medicalRecordId;

    @NotEmpty(message = "At least one medicine must be prescribed")
    @Valid
    private List<PrescriptionItemRequest> items;
}
