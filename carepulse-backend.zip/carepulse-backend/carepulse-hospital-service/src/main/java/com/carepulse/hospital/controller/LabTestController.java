package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateLabTestRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.LabTestResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.LabTestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Pathology / Lab Tests", description = "Doctor-ordered lab tests, assigned to and worked through by a specific Pathologist")
@SecurityRequirement(name = "bearerAuth")
public class LabTestController {

    private final LabTestService labTestService;

    @Operation(summary = "[Doctor] Order a lab test, assigned to a specific Pathologist")
    @PostMapping("/doctors/me/lab-tests")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<LabTestResponse>> createLabTestRequest(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateLabTestRequest request) {
        LabTestResponse response = labTestService.createLabTestRequest(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Lab test requested successfully", response));
    }

    @Operation(summary = "[Pathologist] View lab tests assigned to me that are still open (REQUESTED/SAMPLE_COLLECTED/IN_PROGRESS)")
    @GetMapping("/pathology/lab-tests/requested")
    @PreAuthorize("hasRole('PATHOLOGIST')")
    public ResponseEntity<ApiResponse<List<LabTestResponse>>> getRequestedLabTests(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Requested lab tests fetched successfully", labTestService.getRequestedLabTests(user.userId())));
    }

    @Operation(summary = "[Pathologist] Mark a sample as collected")
    @PutMapping("/pathology/lab-tests/{labTestId}/collect-sample")
    @PreAuthorize("hasRole('PATHOLOGIST')")
    public ResponseEntity<ApiResponse<LabTestResponse>> collectSample(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long labTestId) {
        return ResponseEntity.ok(ApiResponse.success("Sample marked as collected", labTestService.collectSample(user.userId(), labTestId)));
    }

    @Operation(summary = "[Pathologist] Upload lab test results as a PDF file")
    @PutMapping(value = "/pathology/lab-tests/{labTestId}/report", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('PATHOLOGIST')")
    public ResponseEntity<ApiResponse<LabTestResponse>> uploadReport(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long labTestId,
            @RequestParam("resultSummary") String resultSummary,
            @RequestPart("file") MultipartFile file) {
        return ResponseEntity.ok(ApiResponse.success("Lab report uploaded successfully",
                labTestService.uploadReport(user.userId(), labTestId, resultSummary, file)));
    }

    @Operation(summary = "[Pathologist] Mark a lab report as ready (notifies the patient)")
    @PutMapping("/pathology/lab-tests/{labTestId}/mark-ready")
    @PreAuthorize("hasRole('PATHOLOGIST')")
    public ResponseEntity<ApiResponse<LabTestResponse>> markReportReady(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long labTestId) {
        return ResponseEntity.ok(ApiResponse.success("Lab report marked as ready", labTestService.markReportReady(user.userId(), labTestId)));
    }

    @Operation(summary = "Get a single lab test by id")
    @GetMapping("/lab-tests/{labTestId}")
    public ResponseEntity<ApiResponse<LabTestResponse>> getLabTestById(@PathVariable Long labTestId) {
        return ResponseEntity.ok(ApiResponse.success("Lab test fetched successfully", labTestService.getLabTestById(labTestId)));
    }

    @Operation(summary = "[Doctor/Pathologist/Patient] Download the uploaded lab report PDF - access is limited to the assigned pathologist, the ordering doctor, or the owning patient")
    @GetMapping("/lab-tests/{labTestId}/report/file")
    public ResponseEntity<byte[]> downloadReportFile(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long labTestId) {
        ReportFileDownload file = labTestService.getReportFile(user.userId(), user.role(), labTestId);
        MediaType mediaType = file.getContentType() != null ? MediaType.parseMediaType(file.getContentType()) : MediaType.APPLICATION_OCTET_STREAM;
        return ResponseEntity.ok()
                .contentType(mediaType)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFileName() + "\"")
                .body(file.getData());
    }

    @Operation(summary = "[Patient] View my own lab reports")
    @GetMapping("/patients/me/lab-tests")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<LabTestResponse>>> getMyLabTests(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Lab tests fetched successfully", labTestService.getMyLabTests(user.userId())));
    }
}
