package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateBulkAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateAvailabilityRequest;
import com.carepulse.hospital.dto.response.AvailabilityResponse;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.BulkAvailabilityResponse;
import com.carepulse.hospital.entity.Doctor;
import com.carepulse.hospital.entity.DoctorAvailability;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.AvailabilityMapper;
import com.carepulse.hospital.repository.AppointmentRepository;
import com.carepulse.hospital.repository.DoctorAvailabilityRepository;
import com.carepulse.hospital.repository.DoctorRepository;
import com.carepulse.hospital.service.AvailabilityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class AvailabilityServiceImpl implements AvailabilityService {

    /**
     * Every status that means this exact clock-time slot is already spoken for and
     * must not be offered again - i.e. everything except CANCELLED. A COMPLETED or
     * NO_SHOW appointment still consumed that slot in the doctor's calendar; only a
     * CANCELLED one frees it back up for someone else to book.
     */
    private static final List<AppointmentStatus> SLOT_TAKEN_STATUSES =
            List.of(AppointmentStatus.BOOKED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN,
                    AppointmentStatus.IN_CONSULTATION, AppointmentStatus.COMPLETED, AppointmentStatus.NO_SHOW);

    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorRepository doctorRepository;
    private final AppointmentRepository appointmentRepository;
    private final AvailabilityMapper availabilityMapper;

    @Override
    @Transactional
    public AvailabilityResponse createAvailability(Long doctorUserId, CreateAvailabilityRequest request) {
        Doctor doctor = findDoctorByUserId(doctorUserId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        DoctorAvailability availability = DoctorAvailability.builder()
                .doctor(doctor)
                .availableDate(request.getAvailableDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .slotDurationMinutes(request.getSlotDurationMinutes())
                .maximumPatients(request.getMaximumPatients())
                .consultationMode(request.getConsultationMode())
                .status(AvailabilityStatus.ACTIVE)
                .bookedCount(0)
                .build();

        DoctorAvailability saved = availabilityRepository.save(availability);
        log.info("Availability created for doctorId={} on {}", doctor.getId(), saved.getAvailableDate());
        return availabilityMapper.toResponse(saved);
    }

    /**
     * Walks every date from {@code startDate} to {@code endDate}
     * (inclusive), and for each date whose day-of-week is in
     * {@code daysOfWeek}, creates one ACTIVE block with the given
     * time/capacity/mode - this is how a doctor publishes "next week" or
     * "the next 15 days" in a single call instead of one request per day.
     * A 60-day cap prevents accidentally publishing years of availability
     * in one shot; a date that would exactly duplicate an existing block
     * is silently skipped rather than erroring the whole batch.
     */
    @Override
    @Transactional
    public BulkAvailabilityResponse createBulkAvailability(Long doctorUserId, CreateBulkAvailabilityRequest request) {
        Doctor doctor = findDoctorByUserId(doctorUserId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        if (request.getEndDate().isBefore(request.getStartDate())) {
            throw new InvalidRequestException("End date cannot be before start date");
        }

        long spanDays = java.time.temporal.ChronoUnit.DAYS.between(request.getStartDate(), request.getEndDate()) + 1;
        if (spanDays > 60) {
            throw new InvalidRequestException("Bulk availability can be published for at most 60 days at a time");
        }

        List<AvailabilityResponse> created = new ArrayList<>();
        int skipped = 0;

        for (LocalDate date = request.getStartDate(); !date.isAfter(request.getEndDate()); date = date.plusDays(1)) {
            if (!request.getDaysOfWeek().contains(date.getDayOfWeek())) {
                continue;
            }

            boolean duplicate = availabilityRepository.existsByDoctorIdAndAvailableDateAndStartTimeAndEndTime(
                    doctor.getId(), date, request.getStartTime(), request.getEndTime());

            if (duplicate) {
                skipped++;
                continue;
            }

            DoctorAvailability availability = DoctorAvailability.builder()
                    .doctor(doctor)
                    .availableDate(date)
                    .startTime(request.getStartTime())
                    .endTime(request.getEndTime())
                    .slotDurationMinutes(request.getSlotDurationMinutes())
                    .maximumPatients(request.getMaximumPatients())
                    .consultationMode(request.getConsultationMode())
                    .status(AvailabilityStatus.ACTIVE)
                    .bookedCount(0)
                    .build();

            DoctorAvailability saved = availabilityRepository.save(availability);
            created.add(availabilityMapper.toResponse(saved));
        }

        log.info("Bulk availability published for doctorId={}: created={} skipped={} range={}..{}",
                doctor.getId(), created.size(), skipped, request.getStartDate(), request.getEndDate());

        return BulkAvailabilityResponse.builder()
                .createdCount(created.size())
                .skippedCount(skipped)
                .created(created)
                .build();
    }

    @Override
    @Transactional
    public AvailabilityResponse updateAvailability(Long doctorUserId, Long availabilityId, UpdateAvailabilityRequest request) {
        DoctorAvailability availability = findOwnedAvailabilityOrThrow(doctorUserId, availabilityId);
        validateTimeRange(request.getStartTime(), request.getEndTime());

        if (request.getMaximumPatients() < availability.getBookedCount()) {
            throw new InvalidRequestException(
                    "Cannot set maximum patients below the number already booked (" + availability.getBookedCount() + ")");
        }

        availability.setAvailableDate(request.getAvailableDate());
        availability.setStartTime(request.getStartTime());
        availability.setEndTime(request.getEndTime());
        availability.setSlotDurationMinutes(request.getSlotDurationMinutes());
        availability.setMaximumPatients(request.getMaximumPatients());
        availability.setConsultationMode(request.getConsultationMode());
        availability.setStatus(request.getStatus());

        DoctorAvailability saved = availabilityRepository.save(availability);
        log.info("Availability updated: id={}", saved.getId());
        return availabilityMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AvailabilityResponse updateAvailabilityStatus(
            Long doctorUserId, Long availabilityId, com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request) {
        DoctorAvailability availability = findOwnedAvailabilityOrThrow(doctorUserId, availabilityId);
        availability.setStatus(request.getStatus());
        DoctorAvailability saved = availabilityRepository.save(availability);
        log.info("Availability status updated: id={} status={}", saved.getId(), saved.getStatus());
        return availabilityMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public void deleteAvailability(Long doctorUserId, Long availabilityId) {
        DoctorAvailability availability = findOwnedAvailabilityOrThrow(doctorUserId, availabilityId);

        if (availability.getBookedCount() > 0) {
            throw new InvalidRequestException(
                    "Cannot delete availability with existing bookings. Set it to INACTIVE instead to stop new bookings.");
        }

        availabilityRepository.delete(availability);
        log.info("Availability deleted: id={}", availabilityId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AvailabilityResponse> getMyAvailability(Long doctorUserId) {
        Doctor doctor = findDoctorByUserId(doctorUserId);
        return availabilityRepository.findByDoctorIdOrderByAvailableDateAscStartTimeAsc(doctor.getId())
                .stream().map(availabilityMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AvailabilityResponse> getDoctorAvailability(Long doctorId) {
        return availabilityRepository
                .findByDoctorIdAndStatusAndAvailableDateGreaterThanEqualOrderByAvailableDateAscStartTimeAsc(
                        doctorId, AvailabilityStatus.ACTIVE, LocalDate.now())
                .stream().map(availabilityMapper::toResponse).toList();
    }

    /**
     * Splits every ACTIVE block for this doctor/date into discrete
     * {@code slotDurationMinutes}-sized slots. A slot is marked
     * {@code bookable=false} once the block's bookedCount has reached its
     * maximumPatients cap - the UI can grey those out - since we don't
     * pre-materialize per-slot booking rows (see DoctorAvailability's class doc).
     * <p>
     * Block-level capacity alone isn't enough though: with maximumPatients > 1,
     * the aggregate count can stay under the cap while one specific clock time
     * within the block already has an active appointment against it. So each
     * slot is additionally checked against the exact start times already booked
     * for this block and excluded individually, rather than only checking the
     * block as a whole.
     */
    @Override
    @Transactional(readOnly = true)
    public List<AvailableSlotResponse> getAvailableSlots(Long doctorId, LocalDate date) {
        List<DoctorAvailability> blocks = availabilityRepository
                .findByDoctorIdAndAvailableDateAndStatus(doctorId, date, AvailabilityStatus.ACTIVE);

        List<AvailableSlotResponse> slots = new ArrayList<>();

        for (DoctorAvailability block : blocks) {
            boolean blockBookable = block.getBookedCount() < block.getMaximumPatients();
            Set<LocalTime> takenStartTimes = new HashSet<>(
                    appointmentRepository.findBookedStartTimesByAvailabilityId(block.getId(), SLOT_TAKEN_STATUSES));
            LocalTime cursor = block.getStartTime();

            while (cursor.plusMinutes(block.getSlotDurationMinutes()).compareTo(block.getEndTime()) <= 0) {
                LocalTime slotEnd = cursor.plusMinutes(block.getSlotDurationMinutes());
                boolean slotBookable = blockBookable && !takenStartTimes.contains(cursor);

                slots.add(AvailableSlotResponse.builder()
                        .availabilityId(block.getId())
                        .availableDate(block.getAvailableDate())
                        .slotStartTime(cursor)
                        .slotEndTime(slotEnd)
                        .consultationMode(block.getConsultationMode())
                        .bookable(slotBookable)
                        .build());

                cursor = slotEnd;
            }
        }

        return slots;
    }

    private Doctor findDoctorByUserId(Long userId) {
        return doctorRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor profile not found for the logged-in user"));
    }

    /** Loads the availability and verifies the calling doctor actually owns it - the core of "doctors can't touch each other's availability". */
    private DoctorAvailability findOwnedAvailabilityOrThrow(Long doctorUserId, Long availabilityId) {
        DoctorAvailability availability = availabilityRepository.findById(availabilityId)
                .orElseThrow(() -> new ResourceNotFoundException("Availability not found with id: " + availabilityId));

        if (!availability.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only manage your own availability");
        }

        return availability;
    }

    private void validateTimeRange(LocalTime start, LocalTime end) {
        if (!start.isBefore(end)) {
            throw new InvalidRequestException("Start time must be before end time");
        }
    }
}
