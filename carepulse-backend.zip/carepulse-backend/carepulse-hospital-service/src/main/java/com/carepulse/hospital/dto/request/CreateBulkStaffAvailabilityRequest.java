package com.carepulse.hospital.dto.request;

import com.carepulse.hospital.enums.ConsultationMode;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

/** Payload for POST /api/hospital/staff/me/availability/bulk - the Dietician/Nutritionist counterpart to {@link CreateBulkAvailabilityRequest}. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBulkStaffAvailabilityRequest {

    @NotNull(message = "Start date is required")
    @FutureOrPresent(message = "Start date cannot be in the past")
    private LocalDate startDate;

    @NotNull(message = "End date is required")
    @FutureOrPresent(message = "End date cannot be in the past")
    private LocalDate endDate;

    @NotEmpty(message = "At least one day of week must be selected")
    private Set<DayOfWeek> daysOfWeek;

    @NotNull(message = "Start time is required")
    private LocalTime startTime;

    @NotNull(message = "End time is required")
    private LocalTime endTime;

    @NotNull(message = "Slot duration is required")
    @Min(value = 5, message = "Slot duration must be at least 5 minutes")
    private Integer slotDurationMinutes;

    @NotNull(message = "Maximum patients is required")
    @Min(value = 1, message = "Maximum patients must be at least 1")
    private Integer maximumPatients;

    @NotNull(message = "Consultation mode is required")
    private ConsultationMode consultationMode;
}
