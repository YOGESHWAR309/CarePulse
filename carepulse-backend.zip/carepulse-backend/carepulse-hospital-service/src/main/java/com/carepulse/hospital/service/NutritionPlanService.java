package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateNutritionPlanRequest;
import com.carepulse.hospital.dto.request.UpdateNutritionPlanRequest;
import com.carepulse.hospital.dto.response.NutritionPlanResponse;

import java.util.List;

public interface NutritionPlanService {

    /** [Nutritionist] Creates a nutrition plan for a patient. */
    NutritionPlanResponse createNutritionPlan(Long nutritionistUserId, CreateNutritionPlanRequest request);

    /** [Nutritionist] Updates their own previously created plan. */
    NutritionPlanResponse updateNutritionPlan(Long nutritionistUserId, Long nutritionPlanId, UpdateNutritionPlanRequest request);

    /** [Patient] Own nutrition plans. */
    List<NutritionPlanResponse> getMyNutritionPlans(Long patientUserId);

    /** [Nutritionist] Any patient's nutrition plan history. */
    List<NutritionPlanResponse> getPatientNutritionPlans(Long patientId);
}
