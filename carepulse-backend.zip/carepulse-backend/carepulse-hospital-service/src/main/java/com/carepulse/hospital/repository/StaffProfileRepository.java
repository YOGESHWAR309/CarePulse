package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StaffProfileRepository extends JpaRepository<StaffProfile, Long> {

    Optional<StaffProfile> findByUserId(Long userId);

    boolean existsByUserId(Long userId);

    /**
     * Used by Pharmacist/Pathologist/Radiologist/Dietician/Nutritionist "who am I" lookups
     * and admin directory screens. Fetch-joins department - StaffDirectoryMapper reads
     * departmentName per row, and it varies row to row, so this avoids N+1.
     */
    @Query("SELECT s FROM StaffProfile s LEFT JOIN FETCH s.department WHERE s.role = :role")
    List<StaffProfile> findByRole(@Param("role") UserRole role);

    /** Admin's "View All Staff" screen. Overrides the inherited findAll() with the same fetch join as findByRole above. */
    @Query("SELECT s FROM StaffProfile s LEFT JOIN FETCH s.department")
    List<StaffProfile> findAll();

    /** [Doctor] Search Radiologist/Pathologist staff by (partial, case-insensitive) name, to pick who a scan/lab test request is assigned to. */
    @Query("SELECT s FROM StaffProfile s LEFT JOIN FETCH s.department " +
            "WHERE s.role = :role AND LOWER(s.fullName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<StaffProfile> findByRoleAndFullNameContainingIgnoreCase(@Param("role") UserRole role, @Param("name") String name);
}
