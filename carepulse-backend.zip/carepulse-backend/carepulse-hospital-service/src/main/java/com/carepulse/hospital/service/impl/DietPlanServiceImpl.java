package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateDietPlanRequest;
import com.carepulse.hospital.dto.request.UpdateDietPlanRequest;
import com.carepulse.hospital.dto.response.DietPlanResponse;
import com.carepulse.hospital.entity.ConsultationAppointment;
import com.carepulse.hospital.entity.DietPlan;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.enums.AppointmentStatus;
import com.carepulse.hospital.exception.DuplicateResourceException;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.DietPlanMapper;
import com.carepulse.hospital.repository.ConsultationAppointmentRepository;
import com.carepulse.hospital.repository.DietPlanRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.DietPlanService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DietPlanServiceImpl implements DietPlanService {

    private final DietPlanRepository dietPlanRepository;
    private final PatientRepository patientRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final ConsultationAppointmentRepository consultationAppointmentRepository;
    private final DietPlanMapper dietPlanMapper;

    /**
     * Requires the consultation appointment to actually belong to the
     * calling Dietician (ownership check) and to be COMPLETED (proof the
     * consultation actually happened) - a Dietician can no longer write a
     * plan against an arbitrary patientId with no visit on record. Also
     * enforces one plan per appointment via the entity's unique constraint.
     */
    @Override
    @Transactional
    public DietPlanResponse createDietPlan(Long dieticianUserId, CreateDietPlanRequest request) {
        ConsultationAppointment appointment = consultationAppointmentRepository.findById(request.getConsultationAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Consultation appointment not found with id: " + request.getConsultationAppointmentId()));

        if (!appointment.getStaffProfile().getUserId().equals(dieticianUserId)) {
            throw new UnauthorizedActionException("You can only write a diet plan for your own consultations");
        }

        if (appointment.getStatus() != AppointmentStatus.COMPLETED) {
            throw new InvalidRequestException("The consultation must be marked COMPLETED before a diet plan can be written");
        }

        if (dietPlanRepository.existsByConsultationAppointmentId(appointment.getId())) {
            throw new DuplicateResourceException("A diet plan already exists for this consultation. Use update instead.");
        }

        Patient patient = appointment.getPatient();
        String dieticianName = staffProfileRepository.findByUserId(dieticianUserId)
                .map(profile -> profile.getFullName())
                .orElse("Dietician");

        DietPlan dietPlan = DietPlan.builder()
                .consultationAppointment(appointment)
                .patient(patient)
                .dieticianUserId(dieticianUserId)
                .dieticianName(dieticianName)
                .planDetails(request.getPlanDetails())
                .build();

        DietPlan saved = dietPlanRepository.save(dietPlan);
        log.info("Diet plan created for consultationAppointmentId={} by dieticianUserId={}", appointment.getId(), dieticianUserId);
        return dietPlanMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public DietPlanResponse updateDietPlan(Long dieticianUserId, Long dietPlanId, UpdateDietPlanRequest request) {
        DietPlan dietPlan = dietPlanRepository.findById(dietPlanId)
                .orElseThrow(() -> new ResourceNotFoundException("Diet plan not found with id: " + dietPlanId));

        if (!dietPlan.getDieticianUserId().equals(dieticianUserId)) {
            throw new UnauthorizedActionException("You can only update your own diet plans");
        }

        dietPlan.setPlanDetails(request.getPlanDetails());

        DietPlan saved = dietPlanRepository.save(dietPlan);
        log.info("Diet plan updated: id={}", saved.getId());
        return dietPlanMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DietPlanResponse> getMyDietPlans(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return dietPlanRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(dietPlanMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<DietPlanResponse> getPatientDietPlans(Long patientId) {
        return dietPlanRepository.findByPatientIdOrderByCreatedAtDesc(patientId)
                .stream().map(dietPlanMapper::toResponse).toList();
    }
}
