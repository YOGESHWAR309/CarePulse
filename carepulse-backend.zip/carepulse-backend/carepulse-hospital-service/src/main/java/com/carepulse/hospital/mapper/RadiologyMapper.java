package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.RadiologyResponse;
import com.carepulse.hospital.entity.RadiologyRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RadiologyMapper {

    @Mapping(target = "medicalRecordId", expression = "java(radiologyRequest.getMedicalRecord().getId())")
    @Mapping(target = "patientId", expression = "java(radiologyRequest.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(radiologyRequest.getPatient().getFullName())")
    @Mapping(target = "requestingDoctorName", expression = "java(radiologyRequest.getRequestingDoctor().getFullName())")
    @Mapping(target = "reportAvailable", expression = "java(radiologyRequest.getReportFileData() != null)")
    RadiologyResponse toResponse(RadiologyRequest radiologyRequest);
}
