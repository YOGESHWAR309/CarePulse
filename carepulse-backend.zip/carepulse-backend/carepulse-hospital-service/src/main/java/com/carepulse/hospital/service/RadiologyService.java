package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.CreateRadiologyRequest;
import com.carepulse.hospital.dto.request.UploadScanImageRequest;
import com.carepulse.hospital.dto.response.RadiologyResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/** Doctor picks a Radiologist and orders a scan -> that Radiologist uploads images -> uploads report -> marks ready. */
public interface RadiologyService {

    /** [Doctor] Orders a scan against a medical record they own, assigned to a specific (searched) Radiologist. */
    RadiologyResponse createRadiologyRequest(Long doctorUserId, CreateRadiologyRequest request);

    /** [Radiologist] Attaches the raw scan image(s), moving REQUESTED -> IN_PROGRESS. Must be the assigned radiologist. */
    RadiologyResponse uploadScanImages(Long radiologistUserId, Long radiologyId, UploadScanImageRequest request);

    /** [Radiologist] Attaches the written findings + report PDF. Must be the assigned radiologist. */
    RadiologyResponse uploadReport(Long radiologistUserId, Long radiologyId, String resultSummary, MultipartFile reportFile);

    /** [Radiologist] Finalizes the report as READY - fires RadiologyReportReadyEvent. */
    RadiologyResponse markReportReady(Long radiologistUserId, Long radiologyId);

    RadiologyResponse getRadiologyRequestById(Long radiologyId);

    /** [Radiologist] Their own work queue - REQUESTED/IN_PROGRESS scans assigned to them. */
    List<RadiologyResponse> getRequestedScans(Long radiologistUserId);

    /** [Patient] Own radiology reports. */
    List<RadiologyResponse> getMyRadiologyRequests(Long patientUserId);

    /** [Doctor/Radiologist/Patient - ownership enforced internally] Downloads the uploaded report PDF's bytes. */
    ReportFileDownload getReportFile(Long userId, String role, Long radiologyId);
}
