package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.BookConsultationAppointmentRequest;
import com.carepulse.hospital.dto.request.CancelAppointmentRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.ConsultationAppointmentResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.ConsultationAppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Patient bookings with Dietician/Nutritionist staff - mirrors {@link AppointmentController} for Doctor bookings. */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Consultation Appointments", description = "Patient bookings with Dietician/Nutritionist staff")
@SecurityRequirement(name = "bearerAuth")
public class ConsultationAppointmentController {

    private final ConsultationAppointmentService consultationAppointmentService;

    @Operation(summary = "[Patient] Book a consultation with a Dietician or Nutritionist")
    @PostMapping("/patients/me/consultations")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<ConsultationAppointmentResponse>> bookAppointment(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody BookConsultationAppointmentRequest request) {
        ConsultationAppointmentResponse response = consultationAppointmentService.bookAppointment(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Consultation booked successfully", response));
    }

    @Operation(summary = "[Patient] Cancel my own consultation")
    @PutMapping("/consultations/{appointmentId}/cancel")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<ConsultationAppointmentResponse>> cancelAppointment(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long appointmentId,
            @Valid @RequestBody CancelAppointmentRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Consultation cancelled successfully",
                consultationAppointmentService.cancelAppointment(user.userId(), appointmentId, request)));
    }

    @Operation(summary = "[Patient] View my own consultation history")
    @GetMapping("/patients/me/consultations")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<ConsultationAppointmentResponse>>> getMyAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Consultations fetched successfully", consultationAppointmentService.getMyAppointments(user.userId())));
    }

    @Operation(summary = "[Dietician/Nutritionist] Mark a consultation as completed (required before writing a plan)")
    @PutMapping("/staff/me/consultations/{appointmentId}/complete")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<ConsultationAppointmentResponse>> completeConsultation(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Consultation marked as completed",
                consultationAppointmentService.completeConsultation(user.userId(), appointmentId)));
    }

    @Operation(summary = "[Dietician/Nutritionist] View today's consultations")
    @GetMapping("/staff/me/consultations/today")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<List<ConsultationAppointmentResponse>>> getTodayAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Today's consultations fetched successfully", consultationAppointmentService.getTodayAppointments(user.userId())));
    }

    @Operation(summary = "[Dietician/Nutritionist] View upcoming consultations")
    @GetMapping("/staff/me/consultations/upcoming")
    @PreAuthorize("hasAnyRole('DIETICIAN', 'NUTRITIONIST')")
    public ResponseEntity<ApiResponse<List<ConsultationAppointmentResponse>>> getUpcomingAppointments(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Upcoming consultations fetched successfully", consultationAppointmentService.getUpcomingAppointments(user.userId())));
    }

    @Operation(summary = "Get a single consultation appointment by id")
    @GetMapping("/consultations/{appointmentId}")
    public ResponseEntity<ApiResponse<ConsultationAppointmentResponse>> getAppointmentById(@PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Consultation fetched successfully", consultationAppointmentService.getAppointmentById(appointmentId)));
    }
}
