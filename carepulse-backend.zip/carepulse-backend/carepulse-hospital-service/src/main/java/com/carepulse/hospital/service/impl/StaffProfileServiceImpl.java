package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.UpdateStaffProfileRequest;
import com.carepulse.hospital.dto.response.StaffDirectoryResponse;
import com.carepulse.hospital.entity.Department;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.mapper.StaffDirectoryMapper;
import com.carepulse.hospital.repository.DepartmentRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.StaffProfileService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class StaffProfileServiceImpl implements StaffProfileService {

    private final StaffProfileRepository staffProfileRepository;
    private final DepartmentRepository departmentRepository;
    private final StaffDirectoryMapper staffDirectoryMapper;

    @Override
    @Transactional
    public StaffDirectoryResponse updateStaffProfile(Long staffProfileId, UpdateStaffProfileRequest request) {
        StaffProfile profile = staffProfileRepository.findById(staffProfileId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff profile not found with id: " + staffProfileId));

        profile.setQualification(request.getQualification());

        if (request.getDepartmentId() != null) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + request.getDepartmentId()));
            profile.setDepartment(department);
        } else {
            profile.setDepartment(null);
        }

        StaffProfile saved = staffProfileRepository.save(profile);
        log.info("Staff profile updated: id={} role={}", saved.getId(), saved.getRole());
        return staffDirectoryMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public StaffDirectoryResponse getStaffProfileById(Long staffProfileId) {
        StaffProfile profile = staffProfileRepository.findById(staffProfileId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff profile not found with id: " + staffProfileId));
        return staffDirectoryMapper.toResponse(profile);
    }

    @Override
    @Transactional(readOnly = true)
    public List<StaffDirectoryResponse> getStaffByRole(UserRole role) {
        return staffProfileRepository.findByRole(role).stream().map(staffDirectoryMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<StaffDirectoryResponse> getAllStaff() {
        return staffProfileRepository.findAll().stream().map(staffDirectoryMapper::toResponse).toList();
    }
}
