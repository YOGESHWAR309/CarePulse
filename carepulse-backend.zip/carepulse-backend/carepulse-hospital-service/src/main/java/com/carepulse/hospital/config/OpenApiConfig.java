package com.carepulse.hospital.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Configures Swagger/OpenAPI UI with a bearerAuth scheme so every module's endpoints are directly testable per Phase 11. */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI hospitalServiceOpenApi() {
        final String securitySchemeName = "bearerAuth";
        return new OpenAPI()
                .info(new Info()
                        .title("CarePulse - Hospital Service API")
                        .description("Departments, Doctors, Patients, Appointments, Medical Records, Prescriptions, Pathology, Radiology, Pharmacy, Dietician, Nutritionist, Billing")
                        .version("1.0.0")
                        .contact(new Contact().name("CarePulse Engineering")))
                .addSecurityItem(new SecurityRequirement().addList(securitySchemeName))
                .components(new Components()
                        .addSecuritySchemes(securitySchemeName, new SecurityScheme()
                                .name(securitySchemeName)
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")));
    }
}
