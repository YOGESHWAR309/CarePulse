package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.MedicalRecordResponse;
import com.carepulse.hospital.entity.MedicalRecord;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface MedicalRecordMapper {

    @Mapping(target = "appointmentId", expression = "java(medicalRecord.getAppointment().getId())")
    @Mapping(target = "patientId", expression = "java(medicalRecord.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(medicalRecord.getPatient().getFullName())")
    @Mapping(target = "doctorId", expression = "java(medicalRecord.getDoctor().getId())")
    @Mapping(target = "doctorName", expression = "java(medicalRecord.getDoctor().getFullName())")
    MedicalRecordResponse toResponse(MedicalRecord medicalRecord);
}
