package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.StaffDirectoryResponse;
import com.carepulse.hospital.entity.StaffProfile;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StaffDirectoryMapper {

    @Mapping(target = "staffProfileId", expression = "java(staffProfile.getId())")
    @Mapping(target = "userId", expression = "java(staffProfile.getUserId())")
    @Mapping(target = "departmentId", expression = "java(staffProfile.getDepartment() != null ? staffProfile.getDepartment().getId() : null)")
    @Mapping(target = "departmentName", expression = "java(staffProfile.getDepartment() != null ? staffProfile.getDepartment().getName() : null)")
    StaffDirectoryResponse toResponse(StaffProfile staffProfile);
}
