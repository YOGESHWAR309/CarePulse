package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateNutritionPlanRequest;
import com.carepulse.hospital.dto.request.UpdateNutritionPlanRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.NutritionPlanResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.NutritionPlanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Nutritionist", description = "Nutrition plan management")
@SecurityRequirement(name = "bearerAuth")
public class NutritionPlanController {

    private final NutritionPlanService nutritionPlanService;

    @Operation(summary = "[Nutritionist] Create a nutrition plan for a completed consultation")
    @PostMapping("/nutrition-plans")
    @PreAuthorize("hasRole('NUTRITIONIST')")
    public ResponseEntity<ApiResponse<NutritionPlanResponse>> createNutritionPlan(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateNutritionPlanRequest request) {
        NutritionPlanResponse response = nutritionPlanService.createNutritionPlan(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Nutrition plan created successfully", response));
    }

    @Operation(summary = "[Nutritionist] Update my own nutrition plan")
    @PutMapping("/nutrition-plans/{nutritionPlanId}")
    @PreAuthorize("hasRole('NUTRITIONIST')")
    public ResponseEntity<ApiResponse<NutritionPlanResponse>> updateNutritionPlan(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long nutritionPlanId,
            @Valid @RequestBody UpdateNutritionPlanRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Nutrition plan updated successfully", nutritionPlanService.updateNutritionPlan(user.userId(), nutritionPlanId, request)));
    }

    @Operation(summary = "[Patient] View my own nutrition plans")
    @GetMapping("/patients/me/nutrition-plans")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<NutritionPlanResponse>>> getMyNutritionPlans(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Nutrition plans fetched successfully", nutritionPlanService.getMyNutritionPlans(user.userId())));
    }

    @Operation(summary = "[Nutritionist] View a patient's nutrition plan history")
    @GetMapping("/patients/{patientId}/nutrition-plans")
    @PreAuthorize("hasRole('NUTRITIONIST')")
    public ResponseEntity<ApiResponse<List<NutritionPlanResponse>>> getPatientNutritionPlans(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success("Nutrition plans fetched successfully", nutritionPlanService.getPatientNutritionPlans(patientId)));
    }
}
