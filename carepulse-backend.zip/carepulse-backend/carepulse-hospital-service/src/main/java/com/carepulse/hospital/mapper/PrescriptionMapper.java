package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.PrescriptionItemResponse;
import com.carepulse.hospital.dto.response.PrescriptionResponse;
import com.carepulse.hospital.entity.Prescription;
import com.carepulse.hospital.entity.PrescriptionItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PrescriptionMapper {

    @Mapping(target = "medicalRecordId", expression = "java(prescription.getMedicalRecord().getId())")
    @Mapping(target = "patientId", expression = "java(prescription.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(prescription.getPatient().getFullName())")
    @Mapping(target = "doctorId", expression = "java(prescription.getDoctor().getId())")
    @Mapping(target = "doctorName", expression = "java(prescription.getDoctor().getFullName())")
    PrescriptionResponse toResponse(Prescription prescription);

    PrescriptionItemResponse toItemResponse(PrescriptionItem item);
}
