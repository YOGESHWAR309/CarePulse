package com.carepulse.hospital.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Mirrors {@code com.carepulse.auth.messaging.event.PatientRegisteredEvent}
 * field-for-field. Jackson deserializes Auth Service's published JSON
 * straight into this class - field names must stay in sync between services.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PatientRegisteredEvent implements Serializable {
    private Long userId;
    private String email;
    private String firstName;
    private String lastName;
    private String phoneNumber;
}
