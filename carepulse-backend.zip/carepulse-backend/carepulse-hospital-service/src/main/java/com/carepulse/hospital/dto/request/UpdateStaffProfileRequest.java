package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Payload for PUT /api/hospital/admin/staff/{id} - lets Admin edit or add
 * qualification/department for a Receptionist/Pharmacist/Pathologist/
 * Radiologist/Dietician/Nutritionist after creation, mirroring what
 * {@link UpdateDoctorRequest} does for Doctors.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateStaffProfileRequest {

    @Size(max = 200, message = "Qualification must not exceed 200 characters")
    private String qualification;

    /** Optional - assigns this staff member to a specific department's counter/desk. Null clears any existing assignment. */
    private Long departmentId;
}
