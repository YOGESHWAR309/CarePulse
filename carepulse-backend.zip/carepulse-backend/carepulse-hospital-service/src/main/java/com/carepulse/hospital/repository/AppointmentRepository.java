package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Appointment;
import com.carepulse.hospital.enums.AppointmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    /**
     * Every start time already taken within one availability block, restricted to
     * still-active bookings (a cancelled appointment frees its slot back up). Used to
     * mark individual slots un-bookable in {@code getAvailableSlots} even when the
     * block's aggregate bookedCount hasn't hit maximumPatients yet, and to reject a
     * booking attempt that targets an already-taken exact time.
     */
    @Query("SELECT a.startTime FROM Appointment a WHERE a.availability.id = :availabilityId AND a.status IN :statuses")
    List<LocalTime> findBookedStartTimesByAvailabilityId(
            @Param("availabilityId") Long availabilityId, @Param("statuses") List<AppointmentStatus> statuses);

    /**
     * Patient's own "View Appointment History" screen, most recent first.
     * Fetch-joins patient/doctor/department since AppointmentMapper reads
     * patientName, doctorName and departmentName for every row - without
     * this, each row would fire its own lazy-load query (N+1).
     */
    @Query("SELECT a FROM Appointment a JOIN FETCH a.patient JOIN FETCH a.doctor doc LEFT JOIN FETCH doc.department " +
            "WHERE a.patient.id = :patientId ORDER BY a.appointmentDate DESC, a.startTime DESC")
    List<Appointment> findByPatientIdOrderByAppointmentDateDescStartTimeDesc(@Param("patientId") Long patientId);

    /** Doctor's "View Today's Appointments" screen. */
    @Query("SELECT a FROM Appointment a JOIN FETCH a.patient JOIN FETCH a.doctor doc LEFT JOIN FETCH doc.department " +
            "WHERE a.doctor.id = :doctorId AND a.appointmentDate = :date ORDER BY a.startTime ASC")
    List<Appointment> findByDoctorIdAndAppointmentDateOrderByStartTimeAsc(@Param("doctorId") Long doctorId, @Param("date") LocalDate date);

    /** Doctor's "View Upcoming Appointments" screen - future dates, still-active statuses. */
    @Query("SELECT a FROM Appointment a JOIN FETCH a.patient JOIN FETCH a.doctor doc LEFT JOIN FETCH doc.department " +
            "WHERE a.doctor.id = :doctorId AND a.appointmentDate >= :fromDate AND a.status IN :statuses " +
            "ORDER BY a.appointmentDate ASC, a.startTime ASC")
    List<Appointment> findByDoctorIdAndAppointmentDateGreaterThanEqualAndStatusInOrderByAppointmentDateAscStartTimeAsc(
            @Param("doctorId") Long doctorId, @Param("fromDate") LocalDate fromDate, @Param("statuses") List<AppointmentStatus> statuses);

    /**
     * Doctor's "View Assigned Patients" - every distinct appointment a doctor has ever had.
     * NOTE: currently unused anywhere in the service layer - the "assigned patients" screen
     * this was written for doesn't appear to be wired up to a controller endpoint yet.
     */
    List<Appointment> findByDoctorId(Long doctorId);

    /** Receptionist's "Manage Appointment Queue" - every appointment for a given day across all doctors, ordered for a front-desk view. */
    @Query("SELECT a FROM Appointment a JOIN FETCH a.patient JOIN FETCH a.doctor doc LEFT JOIN FETCH doc.department " +
            "WHERE a.appointmentDate = :date ORDER BY a.startTime ASC")
    List<Appointment> findByAppointmentDateOrderByStartTimeAsc(@Param("date") LocalDate date);
}
