package com.carepulse.hospital.feign;

import com.carepulse.hospital.dto.response.ApiResponseDto;
import com.carepulse.hospital.dto.response.UserSummaryDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Synchronous OpenFeign client to Auth Service, used sparingly and only
 * where Hospital Service's own denormalized copy of a user's data (in
 * Doctor/Patient/StaffProfile) might be stale or insufficient - e.g.
 * double-checking a userId is still active right before a sensitive
 * write. {@code name = "AUTH-SERVICE"} resolves via Eureka, load-balanced
 * automatically by Spring Cloud LoadBalancer.
 */
@FeignClient(name = "AUTH-SERVICE", configuration = FeignClientConfig.class)
public interface AuthServiceClient {

    @GetMapping("/api/auth/internal/users/{userId}")
    ApiResponseDto<UserSummaryDto> getUserById(@PathVariable("userId") Long userId);
}
