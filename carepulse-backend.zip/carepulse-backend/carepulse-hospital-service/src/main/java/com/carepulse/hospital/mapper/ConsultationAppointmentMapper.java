package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.ConsultationAppointmentResponse;
import com.carepulse.hospital.entity.ConsultationAppointment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ConsultationAppointmentMapper {

    @Mapping(target = "patientId", expression = "java(appointment.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(appointment.getPatient().getFullName())")
    @Mapping(target = "staffProfileId", expression = "java(appointment.getStaffProfile().getId())")
    @Mapping(target = "staffName", expression = "java(appointment.getStaffProfile().getFullName())")
    @Mapping(target = "staffRole", expression = "java(appointment.getStaffProfile().getRole())")
    ConsultationAppointmentResponse toResponse(ConsultationAppointment appointment);
}
