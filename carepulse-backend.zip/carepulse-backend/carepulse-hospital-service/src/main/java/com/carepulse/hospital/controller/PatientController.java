package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateWalkInPatientRequest;
import com.carepulse.hospital.dto.request.UpdatePatientProfileRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.PatientResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Patient clinical-profile self-service, Receptionist walk-in registration/search, and Admin's patient directory. */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Patients", description = "Patient profile self-service, walk-in registration, and directory")
@SecurityRequirement(name = "bearerAuth")
public class PatientController {

    private final PatientService patientService;

    @Operation(summary = "[Patient] View my own clinical profile")
    @GetMapping("/patients/me")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<PatientResponse>> getMyProfile(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Profile fetched successfully", patientService.getMyProfile(user.userId())));
    }

    @Operation(summary = "[Patient] Update my own clinical profile (DOB, gender, blood group, address, emergency contact)")
    @PutMapping("/patients/me")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<PatientResponse>> updateMyProfile(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody UpdatePatientProfileRequest request) {
        PatientResponse response = patientService.updateMyProfile(user.userId(), request);
        return ResponseEntity.ok(ApiResponse.success("Profile updated successfully", response));
    }

    @Operation(summary = "Get a patient's profile by id (used by Doctor/Receptionist/Admin in clinical/administrative context)")
    @GetMapping("/patients/{patientId}")
    public ResponseEntity<ApiResponse<PatientResponse>> getPatientById(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success("Patient fetched successfully", patientService.getPatientById(patientId)));
    }

    @Operation(summary = "[Receptionist] Register a walk-in patient")
    @PostMapping("/receptionist/patients")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<PatientResponse>> registerWalkInPatient(@Valid @RequestBody CreateWalkInPatientRequest request) {
        PatientResponse response = patientService.registerWalkInPatient(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Walk-in patient registered successfully", response));
    }

    @Operation(summary = "[Receptionist] Search patients by name")
    @GetMapping("/receptionist/patients/search")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public ResponseEntity<ApiResponse<List<PatientResponse>>> searchPatients(@RequestParam String name) {
        return ResponseEntity.ok(ApiResponse.success("Patients fetched successfully", patientService.searchPatientsByName(name)));
    }

    @Operation(summary = "[Doctor] Search patients by name, to look up a patient's medical history before a consultation")
    @GetMapping("/doctors/me/patients/search")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<PatientResponse>>> searchPatientsForDoctor(@RequestParam String name) {
        return ResponseEntity.ok(ApiResponse.success("Patients fetched successfully", patientService.searchPatientsByName(name)));
    }

    @Operation(summary = "[Admin] View all patients")
    @GetMapping("/admin/patients")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<PatientResponse>>> getAllPatients() {
        return ResponseEntity.ok(ApiResponse.success("Patients fetched successfully", patientService.getAllPatients()));
    }
}
