package com.carepulse.hospital.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Everything the React frontend needs to open Razorpay's Checkout widget:
 * the order id just created server-side, the amount (in the smallest
 * currency unit, paise, as Razorpay expects), and the public key id
 * (never the secret) to initialize checkout.js with.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentOrderResponse {
    private Long billId;
    private String razorpayOrderId;
    private long amountInPaise;
    private String currency;
    private String razorpayKeyId;
}
