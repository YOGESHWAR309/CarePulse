package com.carepulse.hospital.messaging.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

/** Published after a cancellation so Notification Service can inform both parties. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentCancelledEvent implements Serializable {
    private Long appointmentId;
    private String patientEmail;
    private String patientName;
    private String doctorEmail;
    private String doctorName;
    private LocalDate appointmentDate;
    private LocalTime startTime;
    private String cancelledBy;
}
