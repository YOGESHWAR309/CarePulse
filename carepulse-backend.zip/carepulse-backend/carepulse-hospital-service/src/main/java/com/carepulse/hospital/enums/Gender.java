package com.carepulse.hospital.enums;

/** Used on the Patient clinical profile. */
public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
