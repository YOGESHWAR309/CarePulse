package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.CreateLabTestRequest;
import com.carepulse.hospital.dto.response.LabTestResponse;
import com.carepulse.hospital.dto.response.ReportFileDownload;
import com.carepulse.hospital.entity.LabTestRequest;
import com.carepulse.hospital.entity.MedicalRecord;
import com.carepulse.hospital.entity.Patient;
import com.carepulse.hospital.entity.StaffProfile;
import com.carepulse.hospital.enums.ReportStatus;
import com.carepulse.hospital.enums.UserRole;
import com.carepulse.hospital.exception.InvalidRequestException;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.exception.UnauthorizedActionException;
import com.carepulse.hospital.mapper.LabTestMapper;
import com.carepulse.hospital.messaging.NotificationEventPublisher;
import com.carepulse.hospital.messaging.event.LabReportReadyEvent;
import com.carepulse.hospital.repository.LabTestRequestRepository;
import com.carepulse.hospital.repository.MedicalRecordRepository;
import com.carepulse.hospital.repository.PatientRepository;
import com.carepulse.hospital.repository.StaffProfileRepository;
import com.carepulse.hospital.service.LabTestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LabTestServiceImpl implements LabTestService {

    private static final List<ReportStatus> OPEN_STATUSES =
            List.of(ReportStatus.REQUESTED, ReportStatus.SAMPLE_COLLECTED, ReportStatus.IN_PROGRESS);

    private final LabTestRequestRepository labTestRequestRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;
    private final StaffProfileRepository staffProfileRepository;
    private final LabTestMapper labTestMapper;
    private final NotificationEventPublisher notificationEventPublisher;

    @Override
    @Transactional
    public LabTestResponse createLabTestRequest(Long doctorUserId, CreateLabTestRequest request) {
        MedicalRecord medicalRecord = medicalRecordRepository.findById(request.getMedicalRecordId())
                .orElseThrow(() -> new ResourceNotFoundException("Medical record not found with id: " + request.getMedicalRecordId()));

        if (!medicalRecord.getDoctor().getUserId().equals(doctorUserId)) {
            throw new UnauthorizedActionException("You can only order lab tests against your own medical records");
        }

        StaffProfile pathologist = staffProfileRepository.findByUserId(request.getPathologistId())
                .orElseThrow(() -> new ResourceNotFoundException("Pathologist not found with id: " + request.getPathologistId()));
        if (pathologist.getRole() != UserRole.PATHOLOGIST || !pathologist.isActive()) {
            throw new InvalidRequestException("Selected staff member is not an active pathologist");
        }

        LabTestRequest labTest = LabTestRequest.builder()
                .medicalRecord(medicalRecord)
                .patient(medicalRecord.getPatient())
                .requestingDoctor(medicalRecord.getDoctor())
                .testName(request.getTestName())
                .status(ReportStatus.REQUESTED)
                .assignedPathologistUserId(pathologist.getUserId())
                .assignedPathologistName(pathologist.getFullName())
                .build();

        LabTestRequest saved = labTestRequestRepository.save(labTest);
        log.info("Lab test requested: id={} test={} assignedPathologist={}", saved.getId(), saved.getTestName(), pathologist.getFullName());
        return labTestMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public LabTestResponse collectSample(Long pathologistUserId, Long labTestId) {
        LabTestRequest labTest = findByIdOrThrow(labTestId);
        requireAssignedPathologist(labTest, pathologistUserId);

        if (labTest.getStatus() != ReportStatus.REQUESTED) {
            throw new InvalidRequestException("Only REQUESTED tests can have a sample collected");
        }

        labTest.setStatus(ReportStatus.SAMPLE_COLLECTED);
        labTest.setProcessedByUserId(pathologistUserId);
        labTest.setSampleCollectedAt(LocalDateTime.now());

        LabTestRequest saved = labTestRequestRepository.save(labTest);
        log.info("Sample collected for lab test id={}", saved.getId());
        return labTestMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public LabTestResponse uploadReport(Long pathologistUserId, Long labTestId, String resultSummary, MultipartFile reportFile) {
        LabTestRequest labTest = findByIdOrThrow(labTestId);
        requireAssignedPathologist(labTest, pathologistUserId);

        if (labTest.getStatus() != ReportStatus.SAMPLE_COLLECTED && labTest.getStatus() != ReportStatus.IN_PROGRESS) {
            throw new InvalidRequestException("Sample must be collected before a report can be uploaded");
        }
        if (resultSummary == null || resultSummary.isBlank()) {
            throw new InvalidRequestException("Result summary is required");
        }

        byte[] fileBytes = readPdfBytesOrThrow(reportFile);

        labTest.setResultSummary(resultSummary);
        labTest.setReportFileData(fileBytes);
        labTest.setReportFileName(reportFile.getOriginalFilename());
        labTest.setReportContentType(reportFile.getContentType());
        labTest.setStatus(ReportStatus.IN_PROGRESS);
        labTest.setProcessedByUserId(pathologistUserId);

        LabTestRequest saved = labTestRequestRepository.save(labTest);
        log.info("Report uploaded for lab test id={}", saved.getId());
        return labTestMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public LabTestResponse markReportReady(Long pathologistUserId, Long labTestId) {
        LabTestRequest labTest = findByIdOrThrow(labTestId);
        requireAssignedPathologist(labTest, pathologistUserId);

        if (labTest.getStatus() != ReportStatus.IN_PROGRESS) {
            throw new InvalidRequestException("A report must be uploaded before it can be marked ready");
        }

        labTest.setStatus(ReportStatus.READY);
        labTest.setProcessedByUserId(pathologistUserId);
        labTest.setReadyAt(LocalDateTime.now());

        LabTestRequest saved = labTestRequestRepository.save(labTest);

        notificationEventPublisher.publishLabReportReady(
                LabReportReadyEvent.builder()
                        .reportId(saved.getId())
                        .patientEmail(saved.getPatient().getEmail())
                        .patientName(saved.getPatient().getFullName())
                        .testName(saved.getTestName())
                        .build());

        log.info("Lab report marked READY: id={}", saved.getId());
        return labTestMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public LabTestResponse getLabTestById(Long labTestId) {
        return labTestMapper.toResponse(findByIdOrThrow(labTestId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabTestResponse> getRequestedLabTests(Long pathologistUserId) {
        return labTestRequestRepository.findByAssignedPathologistAndStatusIn(pathologistUserId, OPEN_STATUSES)
                .stream().map(labTestMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabTestResponse> getMyLabTests(Long patientUserId) {
        Patient patient = patientRepository.findByUserId(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient profile not found for the logged-in user"));
        return labTestRequestRepository.findByPatientIdOrderByCreatedAtDesc(patient.getId())
                .stream().map(labTestMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ReportFileDownload getReportFile(Long userId, String role, Long labTestId) {
        LabTestRequest labTest = findByIdOrThrow(labTestId);

        boolean allowed = switch (role) {
            case "PATHOLOGIST" -> userId.equals(labTest.getAssignedPathologistUserId());
            case "DOCTOR" -> userId.equals(labTest.getRequestingDoctor().getUserId());
            case "PATIENT" -> userId.equals(labTest.getPatient().getUserId());
            default -> false;
        };
        if (!allowed) {
            throw new UnauthorizedActionException("You do not have access to this report");
        }
        if (labTest.getReportFileData() == null) {
            throw new ResourceNotFoundException("No report has been uploaded for this lab test yet");
        }

        return new ReportFileDownload(labTest.getReportFileData(), labTest.getReportFileName(), labTest.getReportContentType());
    }

    private void requireAssignedPathologist(LabTestRequest labTest, Long pathologistUserId) {
        if (!pathologistUserId.equals(labTest.getAssignedPathologistUserId())) {
            throw new UnauthorizedActionException("You are not the pathologist assigned to this lab test");
        }
    }

    private byte[] readPdfBytesOrThrow(MultipartFile reportFile) {
        if (reportFile == null || reportFile.isEmpty()) {
            throw new InvalidRequestException("A report PDF file is required");
        }
        String contentType = reportFile.getContentType();
        if (contentType == null || !contentType.equalsIgnoreCase("application/pdf")) {
            throw new InvalidRequestException("Only PDF files are allowed for reports");
        }
        try {
            return reportFile.getBytes();
        } catch (IOException e) {
            throw new InvalidRequestException("Unable to read the uploaded report file");
        }
    }

    private LabTestRequest findByIdOrThrow(Long labTestId) {
        return labTestRequestRepository.findById(labTestId)
                .orElseThrow(() -> new ResourceNotFoundException("Lab test not found with id: " + labTestId));
    }
}
