package com.carepulse.hospital.dto.request;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/** Payload for rescheduling - points to a NEW availability block/slot; the old slot's booked-count is released back. */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RescheduleAppointmentRequest {

    @NotNull(message = "New availability id is required")
    private Long newAvailabilityId;

    @NotNull(message = "New appointment date is required")
    @FutureOrPresent(message = "Appointment date cannot be in the past")
    private LocalDate newAppointmentDate;

    @NotNull(message = "New slot start time is required")
    private LocalTime newSlotStartTime;
}
