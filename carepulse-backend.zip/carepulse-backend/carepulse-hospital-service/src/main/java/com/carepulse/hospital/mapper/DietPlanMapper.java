package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.DietPlanResponse;
import com.carepulse.hospital.entity.DietPlan;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DietPlanMapper {

    @Mapping(target = "consultationAppointmentId", expression = "java(dietPlan.getConsultationAppointment().getId())")
    @Mapping(target = "patientId", expression = "java(dietPlan.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(dietPlan.getPatient().getFullName())")
    DietPlanResponse toResponse(DietPlan dietPlan);
}
