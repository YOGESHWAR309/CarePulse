package com.carepulse.hospital.service;

import com.carepulse.hospital.dto.request.GenerateBillRequest;
import com.carepulse.hospital.dto.request.VerifyPaymentRequest;
import com.carepulse.hospital.dto.response.BillResponse;
import com.carepulse.hospital.dto.response.PaymentOrderResponse;

import java.util.List;

/**
 * Billing lifecycle: Bill generated (after consultation completion) ->
 * Razorpay order created -> patient pays via Checkout -> payment verified
 * server-side -> Bill marked PAID.
 */
public interface BillingService {

    /** [Receptionist/Doctor/Admin] Generates a bill for a COMPLETED appointment. */
    BillResponse generateBill(GenerateBillRequest request);

    /** [Patient] Creates a Razorpay order for an existing PENDING bill, returning what the frontend needs to open Checkout. */
    PaymentOrderResponse createPaymentOrder(Long billId);

    /** [Patient] Verifies the Razorpay signature after Checkout completes, and if valid, marks the Bill PAID. */
    BillResponse verifyPayment(Long billId, VerifyPaymentRequest request);

    /** Marks a bill as FAILED - called if the frontend reports a Checkout failure/cancellation. */
    BillResponse markPaymentFailed(Long billId);

    /** [Receptionist/Admin] Records an in-person cash payment for a bill, e.g. a walk-in patient paying at the front desk. */
    BillResponse markPaidByCash(Long billId);

    BillResponse getBillById(Long billId);

    /** [Patient] Own billing history. */
    List<BillResponse> getMyBills(Long patientUserId);

    /** [Admin] Every bill in the system - backs the revenue dashboard/billing reports. */
    List<BillResponse> getAllBills();
}
