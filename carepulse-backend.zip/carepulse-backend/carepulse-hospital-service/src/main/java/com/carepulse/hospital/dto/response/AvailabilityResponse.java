package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.AvailabilityStatus;
import com.carepulse.hospital.enums.ConsultationMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvailabilityResponse {
    private Long id;
    private Long doctorId;
    private String doctorName;
    private LocalDate availableDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer slotDurationMinutes;
    private Integer maximumPatients;
    private Integer bookedCount;
    private ConsultationMode consultationMode;
    private AvailabilityStatus status;
}
