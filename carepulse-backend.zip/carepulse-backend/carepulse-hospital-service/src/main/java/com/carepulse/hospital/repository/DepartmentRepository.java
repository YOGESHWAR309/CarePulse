package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    /** Enforces unique department names at the service layer before insert. */
    boolean existsByNameIgnoreCase(String name);

    Optional<Department> findByNameIgnoreCase(String name);

    /** Used by the patient-facing "View Departments" screen - only active departments should be selectable. */
    List<Department> findByActiveTrue();
}
