package com.carepulse.hospital.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Clinical/professional profile for a doctor. Deliberately does NOT store
 * name/email/password - that identity data lives in Auth Service's
 * {@code users} table and is linked here purely by {@code userId}. This
 * row is auto-created by {@link com.carepulse.hospital.messaging.listener.StaffCreatedEventListener}
 * the moment Admin creates a DOCTOR account in Auth Service.
 */
@Entity
@Table(name = "doctors", uniqueConstraints = {
        @UniqueConstraint(name = "uk_doctor_user_id", columnNames = "user_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Foreign key (by value, not JPA relation, since Auth Service owns its own database) to Auth Service's users.id. */
    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;

    /** Denormalized copy of the doctor's name/email at creation time - kept in sync via StaffCreatedEvent, used for fast reads without a Feign call on every list screen. */
    @Column(nullable = false, length = 200)
    private String fullName;

    @Column(nullable = false, length = 150)
    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @Column(length = 150)
    private String specialization;

    @Column(length = 200)
    private String qualification;

    private Integer experienceYears;

    @Column(precision = 10, scale = 2)
    private BigDecimal consultationFee;

    /** Mirrors Auth Service's accountLocked flag so Hospital Service doesn't need a Feign call to know if a doctor is bookable. */
    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
