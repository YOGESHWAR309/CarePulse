package com.carepulse.hospital.service.impl;

import com.carepulse.hospital.dto.request.UpdateDoctorRequest;
import com.carepulse.hospital.dto.response.DoctorResponse;
import com.carepulse.hospital.entity.Department;
import com.carepulse.hospital.entity.Doctor;
import com.carepulse.hospital.exception.ResourceNotFoundException;
import com.carepulse.hospital.mapper.DoctorMapper;
import com.carepulse.hospital.repository.DepartmentRepository;
import com.carepulse.hospital.repository.DoctorRepository;
import com.carepulse.hospital.service.DoctorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final DoctorMapper doctorMapper;

    @Override
    @Transactional
    public DoctorResponse updateDoctorProfile(Long doctorId, UpdateDoctorRequest request) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));

        Department department = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + request.getDepartmentId()));

        doctor.setDepartment(department);
        doctor.setSpecialization(request.getSpecialization());
        doctor.setQualification(request.getQualification());
        doctor.setExperienceYears(request.getExperienceYears());
        doctor.setConsultationFee(request.getConsultationFee());

        Doctor saved = doctorRepository.save(doctor);
        log.info("Doctor clinical profile updated: {} (department={})", saved.getFullName(), department.getName());
        return doctorMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public DoctorResponse getDoctorById(Long doctorId) {
        return doctorMapper.toResponse(findByIdOrThrow(doctorId));
    }

    @Override
    @Transactional(readOnly = true)
    public DoctorResponse getMyProfile(Long userId) {
        Doctor doctor = doctorRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor profile not found for the logged-in user"));
        return doctorMapper.toResponse(doctor);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorResponse> getAllDoctors() {
        return doctorRepository.findAllByOrderByFullNameAsc().stream().map(doctorMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorResponse> getDoctorsByDepartment(Long departmentId) {
        return doctorRepository.findByDepartmentIdAndActiveTrue(departmentId).stream().map(doctorMapper::toResponse).toList();
    }

    private Doctor findByIdOrThrow(Long doctorId) {
        return doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));
    }
}
