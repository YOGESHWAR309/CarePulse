package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateMedicalRecordRequest;
import com.carepulse.hospital.dto.request.UpdateMedicalRecordRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.MedicalRecordResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.MedicalRecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Medical Records", description = "Doctor-authored diagnosis/consultation notes per appointment")
@SecurityRequirement(name = "bearerAuth")
public class MedicalRecordController {

    private final MedicalRecordService medicalRecordService;

    @Operation(summary = "[Doctor] Create the medical record for a completed appointment")
    @PostMapping("/doctors/me/medical-records")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<MedicalRecordResponse>> createMedicalRecord(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateMedicalRecordRequest request) {
        MedicalRecordResponse response = medicalRecordService.createMedicalRecord(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Medical record created successfully", response));
    }

    @Operation(summary = "[Doctor] Update my own medical record")
    @PutMapping("/doctors/me/medical-records/{medicalRecordId}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<MedicalRecordResponse>> updateMedicalRecord(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long medicalRecordId,
            @Valid @RequestBody UpdateMedicalRecordRequest request) {
        MedicalRecordResponse response = medicalRecordService.updateMedicalRecord(user.userId(), medicalRecordId, request);
        return ResponseEntity.ok(ApiResponse.success("Medical record updated successfully", response));
    }

    @Operation(summary = "Get a single medical record by id")
    @GetMapping("/medical-records/{medicalRecordId}")
    public ResponseEntity<ApiResponse<MedicalRecordResponse>> getMedicalRecordById(@PathVariable Long medicalRecordId) {
        return ResponseEntity.ok(ApiResponse.success("Medical record fetched successfully", medicalRecordService.getMedicalRecordById(medicalRecordId)));
    }

    @Operation(summary = "Get the medical record already written for an appointment, if one exists yet")
    @GetMapping("/appointments/{appointmentId}/medical-record")
    public ResponseEntity<ApiResponse<MedicalRecordResponse>> getMedicalRecordByAppointmentId(@PathVariable Long appointmentId) {
        return ResponseEntity.ok(ApiResponse.success("Medical record fetched successfully", medicalRecordService.getMedicalRecordByAppointmentId(appointmentId)));
    }

    @Operation(summary = "[Patient] View my own medical records")
    @GetMapping("/patients/me/medical-records")
    @PreAuthorize("hasRole('PATIENT')")
    public ResponseEntity<ApiResponse<List<MedicalRecordResponse>>> getMyMedicalRecords(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Medical records fetched successfully", medicalRecordService.getMyMedicalRecords(user.userId())));
    }

    @Operation(summary = "[Doctor] View a patient's medical history before a consultation")
    @GetMapping("/patients/{patientId}/medical-records")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<MedicalRecordResponse>>> getPatientMedicalRecords(@PathVariable Long patientId) {
        return ResponseEntity.ok(ApiResponse.success("Medical records fetched successfully", medicalRecordService.getPatientMedicalRecords(patientId)));
    }
}
