package com.carepulse.hospital.dto.response;

import com.carepulse.hospital.enums.ReportStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabTestResponse {
    private Long id;
    private Long medicalRecordId;
    private Long patientId;
    private String patientName;
    private String requestingDoctorName;
    private String testName;
    private ReportStatus status;
    private Long assignedPathologistUserId;
    private String assignedPathologistName;
    private String resultSummary;
    private boolean reportAvailable;
    private String reportFileName;
    private LocalDateTime sampleCollectedAt;
    private LocalDateTime readyAt;
    private LocalDateTime createdAt;
}
