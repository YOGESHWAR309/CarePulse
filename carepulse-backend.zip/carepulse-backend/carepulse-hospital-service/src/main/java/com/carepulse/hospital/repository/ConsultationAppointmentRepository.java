package com.carepulse.hospital.repository;

import com.carepulse.hospital.entity.ConsultationAppointment;
import com.carepulse.hospital.enums.AppointmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface ConsultationAppointmentRepository extends JpaRepository<ConsultationAppointment, Long> {

    /** Mirrors {@link AppointmentRepository#findBookedStartTimesByAvailabilityId} for Dietician/Nutritionist consultations. */
    @Query("SELECT c.startTime FROM ConsultationAppointment c WHERE c.availability.id = :availabilityId AND c.status IN :statuses")
    List<LocalTime> findBookedStartTimesByAvailabilityId(
            @Param("availabilityId") Long availabilityId, @Param("statuses") List<AppointmentStatus> statuses);

    /** Patient's own consultation history. Fetch-joins patient/staffProfile - ConsultationAppointmentMapper reads both per row. */
    @Query("SELECT c FROM ConsultationAppointment c JOIN FETCH c.patient JOIN FETCH c.staffProfile " +
            "WHERE c.patient.id = :patientId ORDER BY c.appointmentDate DESC, c.startTime DESC")
    List<ConsultationAppointment> findByPatientIdOrderByAppointmentDateDescStartTimeDesc(@Param("patientId") Long patientId);

    /** Staff member's "today's consultations" screen. */
    @Query("SELECT c FROM ConsultationAppointment c JOIN FETCH c.patient JOIN FETCH c.staffProfile " +
            "WHERE c.staffProfile.id = :staffProfileId AND c.appointmentDate = :date ORDER BY c.startTime ASC")
    List<ConsultationAppointment> findByStaffProfileIdAndAppointmentDateOrderByStartTimeAsc(
            @Param("staffProfileId") Long staffProfileId, @Param("date") LocalDate date);

    /** Staff member's "upcoming consultations" screen. */
    @Query("SELECT c FROM ConsultationAppointment c JOIN FETCH c.patient JOIN FETCH c.staffProfile " +
            "WHERE c.staffProfile.id = :staffProfileId AND c.appointmentDate >= :fromDate AND c.status IN :statuses " +
            "ORDER BY c.appointmentDate ASC, c.startTime ASC")
    List<ConsultationAppointment> findByStaffProfileIdAndAppointmentDateGreaterThanEqualAndStatusInOrderByAppointmentDateAscStartTimeAsc(
            @Param("staffProfileId") Long staffProfileId, @Param("fromDate") LocalDate fromDate, @Param("statuses") List<AppointmentStatus> statuses);
}
