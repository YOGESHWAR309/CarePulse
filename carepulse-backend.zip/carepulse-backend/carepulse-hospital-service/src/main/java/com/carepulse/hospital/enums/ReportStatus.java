package com.carepulse.hospital.enums;

/** Shared lifecycle for both Pathology (lab) and Radiology reports/requests. */
public enum ReportStatus {
    REQUESTED,
    SAMPLE_COLLECTED,
    IN_PROGRESS,
    READY,
    CANCELLED
}
