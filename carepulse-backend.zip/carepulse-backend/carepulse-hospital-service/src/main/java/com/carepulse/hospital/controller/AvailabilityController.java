package com.carepulse.hospital.controller;

import com.carepulse.hospital.dto.request.CreateAvailabilityRequest;
import com.carepulse.hospital.dto.request.CreateBulkAvailabilityRequest;
import com.carepulse.hospital.dto.request.UpdateAvailabilityRequest;
import com.carepulse.hospital.dto.response.ApiResponse;
import com.carepulse.hospital.dto.response.AvailabilityResponse;
import com.carepulse.hospital.dto.response.AvailableSlotResponse;
import com.carepulse.hospital.dto.response.BulkAvailabilityResponse;
import com.carepulse.hospital.security.AuthenticatedUser;
import com.carepulse.hospital.service.AvailabilityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Doctor availability CRUD (doctor-only, own-resource-only) plus the
 * patient-facing read side used during appointment booking.
 */
@RestController
@RequestMapping("/api/hospital")
@RequiredArgsConstructor
@Tag(name = "Doctor Availability", description = "Doctor-managed bookable time blocks and patient-facing slot lookup")
@SecurityRequirement(name = "bearerAuth")
public class AvailabilityController {

    private final AvailabilityService availabilityService;

    @Operation(summary = "[Doctor] Publish a new availability block")
    @PostMapping("/doctors/me/availability")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<AvailabilityResponse>> createAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateAvailabilityRequest request) {
        AvailabilityResponse response = availabilityService.createAvailability(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Availability created successfully", response));
    }

    @Operation(summary = "[Doctor] Publish availability across a date range in one call (e.g. a week or 15 days at once)")
    @PostMapping("/doctors/me/availability/bulk")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<BulkAvailabilityResponse>> createBulkAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody CreateBulkAvailabilityRequest request) {
        BulkAvailabilityResponse response = availabilityService.createBulkAvailability(user.userId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success(
                response.getCreatedCount() + " availability block(s) created, " + response.getSkippedCount() + " skipped as duplicates",
                response));
    }

    @Operation(summary = "[Doctor] Update my own availability block")
    @PutMapping("/doctors/me/availability/{availabilityId}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<AvailabilityResponse>> updateAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId,
            @Valid @RequestBody UpdateAvailabilityRequest request) {
        AvailabilityResponse response = availabilityService.updateAvailability(user.userId(), availabilityId, request);
        return ResponseEntity.ok(ApiResponse.success("Availability updated successfully", response));
    }

    @Operation(summary = "[Doctor] Toggle ACTIVE/INACTIVE on my own availability block, without touching its date/time/capacity")
    @PatchMapping("/doctors/me/availability/{availabilityId}/status")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<AvailabilityResponse>> updateAvailabilityStatus(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId,
            @Valid @RequestBody com.carepulse.hospital.dto.request.UpdateAvailabilityStatusRequest request) {
        AvailabilityResponse response = availabilityService.updateAvailabilityStatus(user.userId(), availabilityId, request);
        return ResponseEntity.ok(ApiResponse.success("Availability status updated successfully", response));
    }

    @Operation(summary = "[Doctor] Delete my own availability block (only if it has no bookings)")
    @DeleteMapping("/doctors/me/availability/{availabilityId}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<Void>> deleteAvailability(
            @AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long availabilityId) {
        availabilityService.deleteAvailability(user.userId(), availabilityId);
        return ResponseEntity.ok(ApiResponse.success("Availability deleted successfully"));
    }

    @Operation(summary = "[Doctor] View my own availability (all blocks, any status)")
    @GetMapping("/doctors/me/availability")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<ApiResponse<List<AvailabilityResponse>>> getMyAvailability(@AuthenticationPrincipal AuthenticatedUser user) {
        return ResponseEntity.ok(ApiResponse.success("Availability fetched successfully", availabilityService.getMyAvailability(user.userId())));
    }

    @Operation(summary = "View a specific doctor's published availability (patient booking flow, step 3)")
    @GetMapping("/doctors/{doctorId}/availability")
    public ResponseEntity<ApiResponse<List<AvailabilityResponse>>> getDoctorAvailability(@PathVariable Long doctorId) {
        return ResponseEntity.ok(ApiResponse.success("Availability fetched successfully", availabilityService.getDoctorAvailability(doctorId)));
    }

    @Operation(summary = "View concrete bookable slots for a doctor on a specific date (patient booking flow, step 4)")
    @GetMapping("/doctors/{doctorId}/availability/slots")
    public ResponseEntity<ApiResponse<List<AvailableSlotResponse>>> getAvailableSlots(
            @PathVariable Long doctorId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(ApiResponse.success("Slots fetched successfully", availabilityService.getAvailableSlots(doctorId, date)));
    }
}
