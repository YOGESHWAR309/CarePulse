package com.carepulse.hospital.mapper;

import com.carepulse.hospital.dto.response.AppointmentResponse;
import com.carepulse.hospital.entity.Appointment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AppointmentMapper {

    @Mapping(target = "patientId", expression = "java(appointment.getPatient().getId())")
    @Mapping(target = "patientName", expression = "java(appointment.getPatient().getFullName())")
    @Mapping(target = "doctorId", expression = "java(appointment.getDoctor().getId())")
    @Mapping(target = "doctorName", expression = "java(appointment.getDoctor().getFullName())")
    @Mapping(target = "departmentName", expression = "java(appointment.getDoctor().getDepartment() != null ? appointment.getDoctor().getDepartment().getName() : null)")
    AppointmentResponse toResponse(Appointment appointment);
}
