import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev server proxies /api straight to the API Gateway so the browser
// never needs to know individual microservice ports - matches how the
// production build will sit behind the same Gateway origin.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
    },
  },
});
