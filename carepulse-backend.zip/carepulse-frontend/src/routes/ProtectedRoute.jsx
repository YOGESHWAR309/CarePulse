import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Loader } from '../components/common/CommonUI';

/** Blocks access entirely unless a user is logged in - wraps every non-public route. */
export function ProtectedRoute() {
  const { user, initializing } = useAuth();

  if (initializing) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;

  return <Outlet />;
}

/**
 * Layered on top of ProtectedRoute - restricts a route subtree to a
 * specific set of roles. Mirrors the backend's hasRole(...)/hasAnyRole(...)
 * checks so a Patient can never even render a Doctor-only page, let alone
 * successfully call its APIs.
 */
export function RoleBasedRoute({ allowedRoles }) {
  const { user, initializing } = useAuth();

  if (initializing) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;
  if (!allowedRoles.includes(user.role)) return <Navigate to="/unauthorized" replace />;

  return <Outlet />;
}
