import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ProtectedRoute, RoleBasedRoute } from './ProtectedRoute';
import { ROLES } from '../utils/constants';

import RegisterPage from '../pages/auth/RegisterPage';
import LoginPage from '../pages/auth/LoginPage';
import VerifyOtpPage from '../pages/auth/VerifyOtpPage';
import ForgotPasswordPage from '../pages/auth/ForgotPasswordPage';
import ResetPasswordPage from '../pages/auth/ResetPasswordPage';
import ChangePasswordPage from '../pages/auth/ChangePasswordPage';
import { UnauthorizedPage, NotFoundPage } from '../pages/shared/ErrorPages';

import PatientDashboard from '../pages/patient/PatientDashboard';
import BookAppointmentPage from '../pages/patient/BookAppointmentPage';
import MyAppointmentsPage from '../pages/patient/MyAppointmentsPage';
import PatientProfilePage from '../pages/patient/PatientProfilePage';
import MedicalRecordsPage from '../pages/patient/MedicalRecordsPage';
import PrescriptionsPage from '../pages/patient/PrescriptionsPage';
import LabReportsPage from '../pages/patient/LabReportsPage';
import RadiologyReportsPage from '../pages/patient/RadiologyReportsPage';
import DietPlansPage from '../pages/patient/DietPlansPage';
import NutritionPlansPage from '../pages/patient/NutritionPlansPage';
import BookConsultationPage from '../pages/patient/BookConsultationPage';
import BillsPage from '../pages/patient/BillsPage';

import DoctorDashboard from '../pages/doctor/DoctorDashboard';
import DoctorAvailabilityPage from '../pages/doctor/DoctorAvailabilityPage';
import DoctorAppointmentsPage from '../pages/doctor/DoctorAppointmentsPage';
import ConsultationWorkspacePage from '../pages/doctor/ConsultationWorkspacePage';
import DoctorProfilePage from '../pages/doctor/DoctorProfilePage';
import PatientHistoryLookupPage from '../pages/doctor/PatientHistoryLookupPage';

import AdminDashboard from '../pages/admin/AdminDashboard';
import DepartmentManagementPage from '../pages/admin/DepartmentManagementPage';
import CreateStaffPage from '../pages/admin/CreateStaffPage';
import StaffListPage from '../pages/admin/StaffListPage';
import DoctorManagementPage from '../pages/admin/DoctorManagementPage';
import StaffProfileManagementPage from '../pages/admin/StaffProfileManagementPage';
import PatientListPage from '../pages/admin/PatientListPage';
import BillingReportsPage from '../pages/admin/BillingReportsPage';

import ReceptionistDashboard from '../pages/receptionist/ReceptionistDashboard';
import RegisterWalkInPatientPage from '../pages/receptionist/RegisterWalkInPatientPage';
import ReceptionistBookAppointmentPage from '../pages/receptionist/ReceptionistBookAppointmentPage';
import AppointmentQueuePage from '../pages/receptionist/AppointmentQueuePage';
import ReceptionistBillsPage from '../pages/receptionist/ReceptionistBillsPage';

import PharmacistDashboard from '../pages/pharmacist/PharmacistDashboard';
import PathologistDashboard from '../pages/pathologist/PathologistDashboard';
import RadiologistDashboard from '../pages/radiologist/RadiologistDashboard';
import DieticianDashboard from '../pages/dietician/DieticianDashboard';
import NutritionistDashboard from '../pages/nutritionist/NutritionistDashboard';
import StaffAvailabilityPage from '../pages/shared/StaffAvailabilityPage';
import StaffConsultationsPage from '../pages/shared/StaffConsultationsPage';
import WritePlanPage from '../pages/shared/WritePlanPage';

/**
 * Every route in the app, in one place. Public auth routes are open;
 * everything else sits behind ProtectedRoute (must be logged in) and,
 * for role-specific sections, RoleBasedRoute (must be logged in AS that role) -
 * mirroring the backend's hasRole(...)/hasAnyRole(...) checks so the UI
 * never even offers a screen the user's JWT wouldn't be allowed to use.
 */
export default function AppRoutes() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/verify-otp" element={<VerifyOtpPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/unauthorized" element={<UnauthorizedPage />} />

      {/* Any authenticated user */}
      <Route element={<ProtectedRoute />}>
        <Route path="/change-password" element={<ChangePasswordPage />} />
      </Route>

      {/* Role-specific dashboards */}
      <Route element={<RoleBasedRoute allowedRoles={[ROLES.ADMIN]} />}>
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/departments" element={<DepartmentManagementPage />} />
        <Route path="/admin/create-staff" element={<CreateStaffPage />} />
        <Route path="/admin/staff" element={<StaffListPage />} />
        <Route path="/admin/staff-profiles" element={<StaffProfileManagementPage />} />
        <Route path="/admin/doctors" element={<DoctorManagementPage />} />
        <Route path="/admin/patients" element={<PatientListPage />} />
        <Route path="/admin/billing" element={<BillingReportsPage />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.PATIENT]} />}>
        <Route path="/patient/dashboard" element={<PatientDashboard />} />
        <Route path="/patient/book-appointment" element={<BookAppointmentPage />} />
        <Route path="/patient/appointments" element={<MyAppointmentsPage />} />
        <Route path="/patient/profile" element={<PatientProfilePage />} />
        <Route path="/patient/medical-records" element={<MedicalRecordsPage />} />
        <Route path="/patient/prescriptions" element={<PrescriptionsPage />} />
        <Route path="/patient/lab-reports" element={<LabReportsPage />} />
        <Route path="/patient/radiology-reports" element={<RadiologyReportsPage />} />
        <Route path="/patient/diet-plans" element={<DietPlansPage />} />
        <Route path="/patient/nutrition-plans" element={<NutritionPlansPage />} />
        <Route path="/patient/book-consultation/:role" element={<BookConsultationPage />} />
        <Route path="/patient/bills" element={<BillsPage />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.DOCTOR]} />}>
        <Route path="/doctor/dashboard" element={<DoctorDashboard />} />
        <Route path="/doctor/availability" element={<DoctorAvailabilityPage />} />
        <Route path="/doctor/appointments/today" element={<DoctorAppointmentsPage scope="today" />} />
        <Route path="/doctor/appointments/upcoming" element={<DoctorAppointmentsPage scope="upcoming" />} />
        <Route path="/doctor/consultation/:appointmentId" element={<ConsultationWorkspacePage />} />
        <Route path="/doctor/patient-history" element={<PatientHistoryLookupPage />} />
        <Route path="/doctor/profile" element={<DoctorProfilePage />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.RECEPTIONIST]} />}>
        <Route path="/receptionist/dashboard" element={<ReceptionistDashboard />} />
        <Route path="/receptionist/register-patient" element={<RegisterWalkInPatientPage />} />
        <Route path="/receptionist/book-appointment" element={<ReceptionistBookAppointmentPage />} />
        <Route path="/receptionist/queue" element={<AppointmentQueuePage />} />
        <Route path="/receptionist/bills" element={<ReceptionistBillsPage />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.PHARMACIST]} />}>
        <Route path="/pharmacist/dashboard" element={<PharmacistDashboard />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.PATHOLOGIST]} />}>
        <Route path="/pathologist/dashboard" element={<PathologistDashboard />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.RADIOLOGIST]} />}>
        <Route path="/radiologist/dashboard" element={<RadiologistDashboard />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.DIETICIAN]} />}>
        <Route path="/dietician/dashboard" element={<DieticianDashboard />} />
        <Route path="/dietician/availability" element={<StaffAvailabilityPage />} />
        <Route path="/dietician/consultations/today" element={<StaffConsultationsPage scope="today" />} />
        <Route path="/dietician/consultations/upcoming" element={<StaffConsultationsPage scope="upcoming" />} />
        <Route path="/dietician/write-plan/:appointmentId" element={<WritePlanPage />} />
      </Route>

      <Route element={<RoleBasedRoute allowedRoles={[ROLES.NUTRITIONIST]} />}>
        <Route path="/nutritionist/dashboard" element={<NutritionistDashboard />} />
        <Route path="/nutritionist/availability" element={<StaffAvailabilityPage />} />
        <Route path="/nutritionist/consultations/today" element={<StaffConsultationsPage scope="today" />} />
        <Route path="/nutritionist/consultations/upcoming" element={<StaffConsultationsPage scope="upcoming" />} />
        <Route path="/nutritionist/write-plan/:appointmentId" element={<WritePlanPage />} />
      </Route>

      {/* Root redirects to login; once logged in, LoginPage itself routes to the right dashboard */}
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
