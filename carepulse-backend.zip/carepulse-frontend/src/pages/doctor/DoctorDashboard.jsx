import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const QUICK_LINKS = [
  { to: '/doctor/appointments/today', label: "Today's Appointments", icon: '📅', desc: "See who's booked in today" },
  { to: '/doctor/appointments/upcoming', label: 'Upcoming Appointments', icon: '🗓️', desc: 'Plan ahead' },
  { to: '/doctor/availability', label: 'Manage Availability', icon: '⏰', desc: 'Publish bookable time slots' },
  { to: '/doctor/patient-history', label: 'Patient History', icon: '📋', desc: "Look up a patient's records" },
  { to: '/doctor/profile', label: 'My Profile', icon: '👤', desc: 'Department, specialization, fee' },
];

export default function DoctorDashboard() {
  const { user } = useAuth();
  return (
    <div className="container mt-4">
      <h2 className="mb-1">Welcome, Dr. {user?.lastName}!</h2>
      <p className="text-muted mb-4">Here's your day at a glance.</p>

      <div className="row g-3">
        {QUICK_LINKS.map((link) => (
          <div key={link.to} className="col-md-4 col-sm-6">
            <Link to={link.to} className="text-decoration-none">
              <div className="card h-100 shadow-sm">
                <div className="card-body">
                  <div style={{ fontSize: '2rem' }}>{link.icon}</div>
                  <h6 className="mt-2 mb-1 text-dark">{link.label}</h6>
                  <p className="small text-muted mb-0">{link.desc}</p>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
