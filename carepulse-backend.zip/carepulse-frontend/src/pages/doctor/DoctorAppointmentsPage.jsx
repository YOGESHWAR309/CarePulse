import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getDoctorTodayAppointments, getDoctorUpcomingAppointments, completeConsultation } from '../../api/hospitalApi';

const STATUS_BADGE = {
  BOOKED: 'primary', RESCHEDULED: 'info', CHECKED_IN: 'warning',
  IN_CONSULTATION: 'warning', COMPLETED: 'success', CANCELLED: 'secondary', NO_SHOW: 'dark',
};

const COMPLETABLE_STATUSES = ['BOOKED', 'RESCHEDULED', 'CHECKED_IN', 'IN_CONSULTATION'];

export default function DoctorAppointmentsPage({ scope = 'today' }) {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [completingId, setCompletingId] = useState(null);

  useEffect(() => {
    loadAppointments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope]);

  const loadAppointments = async () => {
    setLoading(true);
    setError('');
    try {
      const res = scope === 'today' ? await getDoctorTodayAppointments() : await getDoctorUpcomingAppointments();
      setAppointments(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load appointments');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async (appointmentId) => {
    setCompletingId(appointmentId);
    setError('');
    setSuccessMessage('');
    try {
      await completeConsultation(appointmentId);
      setSuccessMessage('Consultation marked as completed. You can now write up the medical record.');
      loadAppointments();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to complete this consultation');
    } finally {
      setCompletingId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">{scope === 'today' ? "Today's Appointments" : 'Upcoming Appointments'}</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : appointments.length === 0 ? (
        <div className="alert alert-light border">No appointments {scope === 'today' ? 'today' : 'upcoming'}.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead>
              <tr>
                <th>Patient</th><th>Date</th><th>Time</th><th>Mode</th><th>Reason</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appt) => (
                <tr key={appt.id}>
                  <td>{appt.patientName}</td>
                  <td>{appt.appointmentDate}</td>
                  <td>{appt.startTime}</td>
                  <td>{appt.consultationMode}</td>
                  <td className="small">{appt.reasonForVisit || '-'}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[appt.status] || 'secondary'}`}>{appt.status}</span></td>
                  <td className="d-flex gap-1">
                    {COMPLETABLE_STATUSES.includes(appt.status) && (
                      <button
                        className="btn btn-sm btn-primary"
                        onClick={() => navigate(`/doctor/consultation/${appt.id}`, { state: { appointment: appt } })}
                      >
                        Start Consultation
                      </button>
                    )}
                    {COMPLETABLE_STATUSES.includes(appt.status) && (
                      <button
                        className="btn btn-sm btn-outline-success"
                        disabled={completingId === appt.id}
                        onClick={() => handleComplete(appt.id)}
                      >
                        {completingId === appt.id ? '...' : 'Complete'}
                      </button>
                    )}
                    {appt.status === 'COMPLETED' && (
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => navigate(`/doctor/consultation/${appt.id}`, { state: { appointment: appt } })}
                      >
                        View / Add Record
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
