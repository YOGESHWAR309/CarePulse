import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyDoctorProfile } from '../../api/hospitalApi';

/** Read-only - department/specialization/fee are set by Admin, not editable by the doctor here. */
export default function DoctorProfilePage() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyDoctorProfile()
      .then((res) => setProfile(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load your profile'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="container mt-4" style={{ maxWidth: 600 }}>
      <h2 className="mb-4">My Clinical Profile</h2>
      <Alert message={error} onClose={() => setError('')} />

      {profile && (
        <div className="card shadow-sm">
          <div className="card-body">
            <p className="mb-2"><strong>Name:</strong> Dr. {profile.fullName}</p>
            <p className="mb-2"><strong>Email:</strong> {profile.email}</p>
            <p className="mb-2"><strong>Department:</strong> {profile.departmentName || 'Not yet assigned'}</p>
            <p className="mb-2"><strong>Specialization:</strong> {profile.specialization || '-'}</p>
            <p className="mb-2"><strong>Qualification:</strong> {profile.qualification || '-'}</p>
            <p className="mb-2"><strong>Experience:</strong> {profile.experienceYears != null ? `${profile.experienceYears} years` : '-'}</p>
            <p className="mb-0"><strong>Consultation Fee:</strong> {profile.consultationFee != null ? `₹${profile.consultationFee}` : '-'}</p>
            <div className="form-text mt-2">Department, fee, and experience are managed by your hospital Admin.</div>
          </div>
        </div>
      )}
    </div>
  );
}
