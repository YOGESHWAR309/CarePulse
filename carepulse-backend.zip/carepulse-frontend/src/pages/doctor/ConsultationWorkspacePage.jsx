import React, { useEffect, useState } from 'react';
import { useLocation, useParams, useNavigate } from 'react-router-dom';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import StaffSearchPicker from '../../components/common/StaffSearchPicker';
import {
  createMedicalRecord,
  createPrescription,
  createLabTestRequest,
  createRadiologyRequest,
  completeConsultation,
  getMedicalRecordByAppointmentId,
} from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, validateMinNumber, runValidators, hasErrors } from '../../utils/validators';

const recordInitial = { symptoms: '', diagnosis: '', consultationNotes: '' };
const emptyMedicine = { medicineName: '', dosage: '', frequency: '', durationDays: '', instructions: '' };

/**
 * A single page covering the full post-consultation workflow: write the
 * MedicalRecord first (required before anything else can be attached to
 * it, mirroring the backend's foreign-key requirement), then optionally
 * add a Prescription, order a Lab Test, and/or order a Radiology scan -
 * each of those three becomes available only once medicalRecordId exists.
 */
export default function ConsultationWorkspacePage() {
  const { appointmentId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const appointment = location.state?.appointment;

  const [medicalRecordId, setMedicalRecordId] = useState(null);
  const [recordValues, setRecordValues] = useState(recordInitial);
  const [recordErrors, setRecordErrors] = useState({});
  const [recordSubmitting, setRecordSubmitting] = useState(false);

  const [medicines, setMedicines] = useState([{ ...emptyMedicine }]);
  const [medicineErrors, setMedicineErrors] = useState([{}]);
  const [prescriptionSubmitting, setPrescriptionSubmitting] = useState(false);
  const [prescriptionDone, setPrescriptionDone] = useState(false);

  const [testName, setTestName] = useState('');
  const [testNameError, setTestNameError] = useState('');
  const [selectedPathologist, setSelectedPathologist] = useState(null);
  const [labSubmitting, setLabSubmitting] = useState(false);
  const [labOrders, setLabOrders] = useState([]);

  const [scanType, setScanType] = useState('');
  const [scanTypeError, setScanTypeError] = useState('');
  const [selectedRadiologist, setSelectedRadiologist] = useState(null);
  const [radiologySubmitting, setRadiologySubmitting] = useState(false);
  const [radiologyOrders, setRadiologyOrders] = useState([]);

  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [finishing, setFinishing] = useState(false);

  // On mount (and especially after a page refresh, where React state like
  // medicalRecordId is lost), check whether this appointment already has a
  // medical record so we don't dead-end into "already exists" on re-submit.
  useEffect(() => {
    let cancelled = false;
    getMedicalRecordByAppointmentId(appointmentId)
      .then((res) => {
        if (cancelled) return;
        setMedicalRecordId(res.data.id);
        setRecordValues({
          symptoms: res.data.symptoms || '',
          diagnosis: res.data.diagnosis || '',
          consultationNotes: res.data.consultationNotes || '',
        });
      })
      .catch(() => {
        // 404 just means no record has been written yet for this appointment - that's fine.
      });
    return () => {
      cancelled = true;
    };
  }, [appointmentId]);

  // ---------- Medical Record ----------

  const recordValidatorMap = {
    diagnosis: (v) => validateRequired(v, 'Diagnosis') || validateMaxLength(v, 'Diagnosis', 1000),
    symptoms: (v) => validateMaxLength(v, 'Symptoms', 1000),
    consultationNotes: (v) => validateMaxLength(v, 'Consultation notes', 2000),
  };

  const handleRecordChange = (event) => {
    const { name, value } = event.target;
    setRecordValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleCreateRecord = async (event) => {
    event.preventDefault();
    setError('');

    const validationErrors = runValidators(recordValues, recordValidatorMap);
    setRecordErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setRecordSubmitting(true);
    try {
      const res = await createMedicalRecord({ appointmentId: Number(appointmentId), ...recordValues });
      setMedicalRecordId(res.data.id);
      setSuccessMessage('Medical record saved. You can now add a prescription, lab test, or scan order.');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to save the medical record');
    } finally {
      setRecordSubmitting(false);
    }
  };

  // ---------- Prescription ----------

  const medicineValidatorMap = {
    medicineName: (v) => validateRequired(v, 'Medicine name') || validateMaxLength(v, 'Medicine name', 200),
    dosage: (v) => validateRequired(v, 'Dosage') || validateMaxLength(v, 'Dosage', 100),
    frequency: (v) => validateRequired(v, 'Frequency') || validateMaxLength(v, 'Frequency', 100),
    durationDays: (v) => validateMinNumber(v, 'Duration (days)', 1),
    instructions: (v) => validateMaxLength(v, 'Instructions', 500),
  };

  const handleMedicineChange = (index, field, value) => {
    setMedicines((prev) => prev.map((m, i) => (i === index ? { ...m, [field]: value } : m)));
  };

  const addMedicineRow = () => {
    setMedicines((prev) => [...prev, { ...emptyMedicine }]);
    setMedicineErrors((prev) => [...prev, {}]);
  };

  const removeMedicineRow = (index) => {
    setMedicines((prev) => prev.filter((_, i) => i !== index));
    setMedicineErrors((prev) => prev.filter((_, i) => i !== index));
  };

  const handleCreatePrescription = async (event) => {
    event.preventDefault();
    setError('');

    const allErrors = medicines.map((med) => runValidators(med, medicineValidatorMap));
    setMedicineErrors(allErrors);
    if (allErrors.some((e) => hasErrors(e))) return;

    setPrescriptionSubmitting(true);
    try {
      await createPrescription({
        medicalRecordId,
        items: medicines.map((m) => ({ ...m, durationDays: Number(m.durationDays) })),
      });
      setPrescriptionDone(true);
      setSuccessMessage('Prescription created successfully.');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to create prescription');
    } finally {
      setPrescriptionSubmitting(false);
    }
  };

  // ---------- Lab Test ----------

  const handleOrderLabTest = async (event) => {
    event.preventDefault();
    setError('');

    const validationErrors = runValidators(
      { testName },
      { testName: (v) => validateRequired(v, 'Test name') || validateMaxLength(v, 'Test name', 200) }
    );
    setTestNameError(validationErrors.testName || '');
    if (hasErrors(validationErrors)) return;
    if (!selectedPathologist) {
      setError('Please search for and select a pathologist to assign this test to');
      return;
    }

    setLabSubmitting(true);
    try {
      const res = await createLabTestRequest({ medicalRecordId, testName, pathologistId: selectedPathologist.userId });
      setLabOrders((prev) => [...prev, res.data]);
      setTestName('');
      setSelectedPathologist(null);
      setSuccessMessage(`Lab test "${res.data.testName}" ordered - assigned to ${res.data.assignedPathologistName}.`);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to order this lab test');
    } finally {
      setLabSubmitting(false);
    }
  };

  // ---------- Finish ----------

  const handleFinish = async () => {
    setError('');
    // Appointment may already be COMPLETED (e.g. reopened to add another
    // order); only call complete when it's still in a pre-completion status.
    if (appointment?.status && appointment.status !== 'COMPLETED') {
      setFinishing(true);
      try {
        await completeConsultation(Number(appointmentId));
      } catch (err) {
        setError(err.response?.data?.message || 'Unable to mark the consultation as completed');
        setFinishing(false);
        return;
      }
      setFinishing(false);
    }
    navigate('/doctor/appointments/today');
  };

  // ---------- Radiology ----------

  const handleOrderRadiology = async (event) => {
    event.preventDefault();
    setError('');

    const validationErrors = runValidators(
      { scanType },
      { scanType: (v) => validateRequired(v, 'Scan type') || validateMaxLength(v, 'Scan type', 100) }
    );
    setScanTypeError(validationErrors.scanType || '');
    if (hasErrors(validationErrors)) return;
    if (!selectedRadiologist) {
      setError('Please search for and select a radiologist to assign this scan to');
      return;
    }

    setRadiologySubmitting(true);
    try {
      const res = await createRadiologyRequest({ medicalRecordId, scanType, radiologistId: selectedRadiologist.userId });
      setRadiologyOrders((prev) => [...prev, res.data]);
      setScanType('');
      setSelectedRadiologist(null);
      setSuccessMessage(`Scan "${res.data.scanType}" ordered - assigned to ${res.data.assignedRadiologistName}.`);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to order this scan');
    } finally {
      setRadiologySubmitting(false);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 800 }}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">Consultation - {appointment?.patientName || `Appointment #${appointmentId}`}</h2>
        <button className="btn btn-outline-secondary btn-sm" onClick={() => navigate(-1)}>Back</button>
      </div>

      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {/* Step 1: Medical Record */}
      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h5 className="mb-3">1. Medical Record {medicalRecordId && <span className="badge bg-success ms-2">Saved</span>}</h5>
          <form onSubmit={handleCreateRecord} noValidate>
            <InputField
              label="Symptoms" name="symptoms" as="textarea"
              value={recordValues.symptoms} onChange={handleRecordChange}
              error={recordErrors.symptoms} disabled={!!medicalRecordId}
            />
            <InputField
              label="Diagnosis" name="diagnosis" as="textarea" required
              value={recordValues.diagnosis} onChange={handleRecordChange}
              error={recordErrors.diagnosis} disabled={!!medicalRecordId}
            />
            <InputField
              label="Consultation Notes" name="consultationNotes" as="textarea"
              value={recordValues.consultationNotes} onChange={handleRecordChange}
              error={recordErrors.consultationNotes} disabled={!!medicalRecordId}
            />
            {!medicalRecordId && <SubmitButton loading={recordSubmitting}>Save Medical Record</SubmitButton>}
          </form>
        </div>
      </div>

      {medicalRecordId && (
        <>
          {/* Step 2: Prescription */}
          <div className="card shadow-sm mb-4">
            <div className="card-body">
              <h5 className="mb-3">2. Prescription (optional) {prescriptionDone && <span className="badge bg-success ms-2">Saved</span>}</h5>
              {!prescriptionDone && (
                <form onSubmit={handleCreatePrescription} noValidate>
                  {medicines.map((med, index) => (
                    <div key={index} className="border rounded p-3 mb-3">
                      <div className="row">
                        <div className="col-md-4">
                          <InputField label="Medicine Name" name="medicineName" required
                            value={med.medicineName} onChange={(e) => handleMedicineChange(index, 'medicineName', e.target.value)}
                            error={medicineErrors[index]?.medicineName} />
                        </div>
                        <div className="col-md-2">
                          <InputField label="Dosage" name="dosage" required placeholder="500mg"
                            value={med.dosage} onChange={(e) => handleMedicineChange(index, 'dosage', e.target.value)}
                            error={medicineErrors[index]?.dosage} />
                        </div>
                        <div className="col-md-3">
                          <InputField label="Frequency" name="frequency" required placeholder="Twice daily"
                            value={med.frequency} onChange={(e) => handleMedicineChange(index, 'frequency', e.target.value)}
                            error={medicineErrors[index]?.frequency} />
                        </div>
                        <div className="col-md-3">
                          <InputField label="Duration (days)" name="durationDays" type="number" required
                            value={med.durationDays} onChange={(e) => handleMedicineChange(index, 'durationDays', e.target.value)}
                            error={medicineErrors[index]?.durationDays} />
                        </div>
                      </div>
                      <InputField label="Instructions" name="instructions"
                        value={med.instructions} onChange={(e) => handleMedicineChange(index, 'instructions', e.target.value)}
                        error={medicineErrors[index]?.instructions} />
                      {medicines.length > 1 && (
                        <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => removeMedicineRow(index)}>
                          Remove
                        </button>
                      )}
                    </div>
                  ))}
                  <button type="button" className="btn btn-sm btn-outline-primary mb-3" onClick={addMedicineRow}>
                    + Add Another Medicine
                  </button>
                  <SubmitButton loading={prescriptionSubmitting}>Save Prescription</SubmitButton>
                </form>
              )}
            </div>
          </div>

          {/* Step 3: Lab Test */}
          <div className="card shadow-sm mb-4">
            <div className="card-body">
              <h5 className="mb-3">3. Order a Lab Test (optional)</h5>
              <form onSubmit={handleOrderLabTest} noValidate className="row g-2 align-items-start">
                <div className="col-8">
                  <InputField label="Test Name" name="testName" placeholder="e.g. Complete Blood Count"
                    value={testName} onChange={(e) => setTestName(e.target.value)} error={testNameError} />
                </div>
                <div className="col-4 pt-4">
                  <SubmitButton loading={labSubmitting}>Order Test</SubmitButton>
                </div>
                <div className="col-12">
                  <StaffSearchPicker
                    role="PATHOLOGIST"
                    label="Pathologist"
                    selected={selectedPathologist}
                    onSelect={setSelectedPathologist}
                    onClear={() => setSelectedPathologist(null)}
                  />
                </div>
              </form>
              {labOrders.length > 0 && (
                <ul className="list-group mt-2">
                  {labOrders.map((order) => (
                    <li key={order.id} className="list-group-item small">
                      {order.testName} - {order.status} <span className="text-muted">(assigned to {order.assignedPathologistName})</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Step 4: Radiology */}
          <div className="card shadow-sm mb-4">
            <div className="card-body">
              <h5 className="mb-3">4. Order a Scan (optional)</h5>
              <form onSubmit={handleOrderRadiology} noValidate className="row g-2 align-items-start">
                <div className="col-8">
                  <InputField label="Scan Type" name="scanType" placeholder="e.g. Chest X-Ray"
                    value={scanType} onChange={(e) => setScanType(e.target.value)} error={scanTypeError} />
                </div>
                <div className="col-4 pt-4">
                  <SubmitButton loading={radiologySubmitting}>Order Scan</SubmitButton>
                </div>
                <div className="col-12">
                  <StaffSearchPicker
                    role="RADIOLOGIST"
                    label="Radiologist"
                    selected={selectedRadiologist}
                    onSelect={setSelectedRadiologist}
                    onClear={() => setSelectedRadiologist(null)}
                  />
                </div>
              </form>
              {radiologyOrders.length > 0 && (
                <ul className="list-group mt-2">
                  {radiologyOrders.map((order) => (
                    <li key={order.id} className="list-group-item small">
                      {order.scanType} - {order.status} <span className="text-muted">(assigned to {order.assignedRadiologistName})</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          <button className="btn btn-success" disabled={finishing} onClick={handleFinish}>
            {finishing ? 'Finishing...' : appointment?.status === 'COMPLETED' ? 'Done - Back to Appointments' : 'Complete Consultation'}
          </button>
        </>
      )}
    </div>
  );
}
