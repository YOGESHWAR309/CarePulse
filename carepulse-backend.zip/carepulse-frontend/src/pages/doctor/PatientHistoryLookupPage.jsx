import React, { useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { searchPatientsByNameForDoctor, getPatientMedicalRecords } from '../../api/hospitalApi';
import { validateRequired } from '../../utils/validators';

/** [Doctor] "View Patient Medical History" - search a patient by name, pick from matches, then list their past records. */
export default function PatientHistoryLookupPage() {
  const [searchName, setSearchName] = useState('');
  const [searchNameError, setSearchNameError] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searched, setSearched] = useState(false);
  const [searching, setSearching] = useState(false);

  const [selectedPatient, setSelectedPatient] = useState(null);
  const [records, setRecords] = useState([]);
  const [loadingRecords, setLoadingRecords] = useState(false);

  const [error, setError] = useState('');

  const handleSearch = async (event) => {
    event.preventDefault();
    setError('');

    const requiredError = validateRequired(searchName, 'Patient name');
    setSearchNameError(requiredError);
    if (requiredError) return;

    setSearching(true);
    setSelectedPatient(null);
    setRecords([]);
    try {
      const res = await searchPatientsByNameForDoctor(searchName);
      setSearchResults(res.data);
      setSearched(true);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to search patients');
    } finally {
      setSearching(false);
    }
  };

  const handleSelectPatient = async (patient) => {
    setSelectedPatient(patient);
    setError('');
    setLoadingRecords(true);
    try {
      const res = await getPatientMedicalRecords(patient.id);
      setRecords(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load this patient\'s medical records');
      setRecords([]);
    } finally {
      setLoadingRecords(false);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 700 }}>
      <h2 className="mb-4">Patient Medical History</h2>
      <Alert message={error} onClose={() => setError('')} />

      <form onSubmit={handleSearch} className="row g-2 align-items-start mb-3" noValidate>
        <div className="col-8">
          <InputField
            label="Patient Name" name="searchName" placeholder="Search by patient name..."
            value={searchName} onChange={(e) => { setSearchName(e.target.value); setSearchNameError(''); }}
            error={searchNameError}
          />
        </div>
        <div className="col-4 pt-4">
          <button className="btn btn-primary w-100" disabled={searching}>{searching ? 'Searching...' : 'Search'}</button>
        </div>
      </form>

      {searching && <Loader />}

      {!searching && searched && !selectedPatient && (
        searchResults.length === 0 ? (
          <div className="alert alert-light border">No patients found matching "{searchName}".</div>
        ) : (
          <div className="mb-4">
            {searchResults.map((patient) => (
              <button
                key={patient.id}
                type="button"
                className="btn btn-outline-secondary w-100 text-start mb-2"
                onClick={() => handleSelectPatient(patient)}
              >
                <strong>{patient.fullName}</strong>
                <div className="small text-muted">{patient.phoneNumber} {patient.email ? `· ${patient.email}` : ''}</div>
              </button>
            ))}
          </div>
        )
      )}

      {selectedPatient && (
        <>
          <div className="card shadow-sm mb-3">
            <div className="card-body d-flex justify-content-between align-items-start">
              <div>
                <h6 className="mb-1">{selectedPatient.fullName}</h6>
                <p className="mb-0 small text-muted">{selectedPatient.email} · {selectedPatient.phoneNumber}</p>
                {selectedPatient.bloodGroup && <p className="mb-0 small">Blood Group: {selectedPatient.bloodGroup}</p>}
              </div>
              <button className="btn btn-sm btn-outline-secondary" onClick={() => { setSelectedPatient(null); setRecords([]); }}>
                Change patient
              </button>
            </div>
          </div>

          {loadingRecords ? (
            <Loader />
          ) : records.length === 0 ? (
            <div className="alert alert-light border">No medical records on file for this patient.</div>
          ) : (
            records.map((record) => (
              <div key={record.id} className="card shadow-sm mb-2">
                <div className="card-body py-2">
                  <div className="d-flex justify-content-between">
                    <small className="text-muted">{new Date(record.createdAt).toLocaleDateString()} - Dr. {record.doctorName}</small>
                  </div>
                  <p className="mb-0"><strong>Diagnosis:</strong> {record.diagnosis}</p>
                </div>
              </div>
            ))
          )}
        </>
      )}
    </div>
  );
}
