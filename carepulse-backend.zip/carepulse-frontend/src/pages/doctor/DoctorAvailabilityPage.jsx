import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  getMyAvailability,
  createAvailability,
  createBulkAvailability,
  updateAvailabilityStatus,
  deleteAvailability,
} from '../../api/hospitalApi';
import {
  validateRequired,
  validateFutureOrPresentDate,
  validateMinNumber,
  runValidators,
  hasErrors,
} from '../../utils/validators';
import { CONSULTATION_MODES } from '../../utils/constants';

const DAYS_OF_WEEK = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];

const STATUS_BADGE = { ACTIVE: 'success', INACTIVE: 'secondary', FULLY_BOOKED: 'warning' };

const singleInitial = {
  availableDate: '', startTime: '', endTime: '',
  slotDurationMinutes: '15', maximumPatients: '10', consultationMode: 'IN_PERSON',
};

const bulkInitial = {
  startDate: '', endDate: '', daysOfWeek: [],
  startTime: '', endTime: '', slotDurationMinutes: '15', maximumPatients: '10', consultationMode: 'IN_PERSON',
};

export default function DoctorAvailabilityPage() {
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [mode, setMode] = useState('single'); // 'single' | 'bulk'

  const [singleValues, setSingleValues] = useState(singleInitial);
  const [singleErrors, setSingleErrors] = useState({});
  const [singleSubmitting, setSingleSubmitting] = useState(false);

  const [bulkValues, setBulkValues] = useState(bulkInitial);
  const [bulkErrors, setBulkErrors] = useState({});
  const [bulkSubmitting, setBulkSubmitting] = useState(false);

  useEffect(() => {
    loadAvailability();
  }, []);

  const loadAvailability = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getMyAvailability();
      // Once a block's date has passed it can no longer be booked or toggled
      // (see the /status endpoint's date-independence, which only fixed
      // toggling - the block itself is just historical noise past that point),
      // so drop it from the list automatically rather than showing it forever.
      const today = new Date().toISOString().slice(0, 10);
      setAvailability(res.data.filter((block) => block.availableDate >= today));
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load your availability');
    } finally {
      setLoading(false);
    }
  };

  // ---------- Single-day form ----------

  const singleValidatorMap = {
    availableDate: (v) => validateFutureOrPresentDate(v, 'Available date'),
    startTime: (v) => validateRequired(v, 'Start time'),
    endTime: (v) => validateRequired(v, 'End time'),
    slotDurationMinutes: (v) => validateMinNumber(v, 'Slot duration (minutes)', 5),
    maximumPatients: (v) => validateMinNumber(v, 'Maximum patients', 1),
  };

  const handleSingleChange = (event) => {
    const { name, value } = event.target;
    setSingleValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleCreateSingle = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    if (singleValues.startTime && singleValues.endTime && singleValues.startTime >= singleValues.endTime) {
      setSingleErrors((prev) => ({ ...prev, endTime: 'End time must be after start time' }));
      return;
    }

    const validationErrors = runValidators(singleValues, singleValidatorMap);
    setSingleErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setSingleSubmitting(true);
    try {
      await createAvailability({
        ...singleValues,
        slotDurationMinutes: Number(singleValues.slotDurationMinutes),
        maximumPatients: Number(singleValues.maximumPatients),
      });
      setSuccessMessage('Availability published successfully');
      setSingleValues(singleInitial);
      setSingleErrors({});
      loadAvailability();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to publish availability');
    } finally {
      setSingleSubmitting(false);
    }
  };

  // ---------- Bulk form ----------

  const bulkValidatorMap = {
    startDate: (v) => validateFutureOrPresentDate(v, 'Start date'),
    endDate: (v) => validateFutureOrPresentDate(v, 'End date'),
    startTime: (v) => validateRequired(v, 'Start time'),
    endTime: (v) => validateRequired(v, 'End time'),
    slotDurationMinutes: (v) => validateMinNumber(v, 'Slot duration (minutes)', 5),
    maximumPatients: (v) => validateMinNumber(v, 'Maximum patients', 1),
    daysOfWeek: (v) => (v.length === 0 ? 'Select at least one day of week' : ''),
  };

  const handleBulkChange = (event) => {
    const { name, value } = event.target;
    setBulkValues((prev) => ({ ...prev, [name]: value }));
  };

  const toggleBulkDay = (day) => {
    setBulkValues((prev) => ({
      ...prev,
      daysOfWeek: prev.daysOfWeek.includes(day)
        ? prev.daysOfWeek.filter((d) => d !== day)
        : [...prev.daysOfWeek, day],
    }));
  };

  const handleCreateBulk = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    if (bulkValues.startTime && bulkValues.endTime && bulkValues.startTime >= bulkValues.endTime) {
      setBulkErrors((prev) => ({ ...prev, endTime: 'End time must be after start time' }));
      return;
    }
    if (bulkValues.startDate && bulkValues.endDate && bulkValues.endDate < bulkValues.startDate) {
      setBulkErrors((prev) => ({ ...prev, endDate: 'End date cannot be before start date' }));
      return;
    }

    const validationErrors = runValidators(bulkValues, bulkValidatorMap);
    setBulkErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setBulkSubmitting(true);
    try {
      const res = await createBulkAvailability({
        ...bulkValues,
        slotDurationMinutes: Number(bulkValues.slotDurationMinutes),
        maximumPatients: Number(bulkValues.maximumPatients),
      });
      setSuccessMessage(
        `${res.data.createdCount} availability block(s) published, ${res.data.skippedCount} skipped as duplicates`
      );
      setBulkValues(bulkInitial);
      setBulkErrors({});
      loadAvailability();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to publish bulk availability');
    } finally {
      setBulkSubmitting(false);
    }
  };

  // ---------- Existing blocks: deactivate / delete ----------

  const handleDeactivate = async (block) => {
    setError('');
    try {
      await updateAvailabilityStatus(block.id, block.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE');
      loadAvailability();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update this block');
    }
  };

  const handleDelete = async (availabilityId) => {
    setError('');
    try {
      await deleteAvailability(availabilityId);
      loadAvailability();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to delete this block (it may already have bookings)');
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Availability</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <ul className="nav nav-tabs mb-3">
            <li className="nav-item">
              <button className={`nav-link ${mode === 'single' ? 'active' : ''}`} onClick={() => setMode('single')}>
                Publish a Single Day
              </button>
            </li>
            <li className="nav-item">
              <button className={`nav-link ${mode === 'bulk' ? 'active' : ''}`} onClick={() => setMode('bulk')}>
                Publish a Week / 15 Days at Once
              </button>
            </li>
          </ul>

          {mode === 'single' && (
            <form onSubmit={handleCreateSingle} noValidate>
              <div className="row">
                <div className="col-md-4">
                  <InputField label="Date" name="availableDate" type="date" required
                    value={singleValues.availableDate} onChange={handleSingleChange}
                    error={singleErrors.availableDate} />
                </div>
                <div className="col-md-4">
                  <InputField label="Start Time" name="startTime" type="time" required
                    value={singleValues.startTime} onChange={handleSingleChange}
                    error={singleErrors.startTime} />
                </div>
                <div className="col-md-4">
                  <InputField label="End Time" name="endTime" type="time" required
                    value={singleValues.endTime} onChange={handleSingleChange}
                    error={singleErrors.endTime} />
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <InputField label="Slot Duration (minutes)" name="slotDurationMinutes" type="number" required
                    value={singleValues.slotDurationMinutes} onChange={handleSingleChange}
                    error={singleErrors.slotDurationMinutes} />
                </div>
                <div className="col-md-4">
                  <InputField label="Maximum Patients" name="maximumPatients" type="number" required
                    value={singleValues.maximumPatients} onChange={handleSingleChange}
                    error={singleErrors.maximumPatients} />
                </div>
                <div className="col-md-4">
                  <InputField label="Consultation Mode" name="consultationMode" as="select" required
                    value={singleValues.consultationMode} onChange={handleSingleChange}>
                    {CONSULTATION_MODES.map((m) => <option key={m} value={m}>{m}</option>)}
                  </InputField>
                </div>
              </div>
              <SubmitButton loading={singleSubmitting}>Publish Availability</SubmitButton>
            </form>
          )}

          {mode === 'bulk' && (
            <form onSubmit={handleCreateBulk} noValidate>
              <div className="row">
                <div className="col-md-6">
                  <InputField label="Start Date" name="startDate" type="date" required
                    value={bulkValues.startDate} onChange={handleBulkChange}
                    error={bulkErrors.startDate} />
                </div>
                <div className="col-md-6">
                  <InputField label="End Date" name="endDate" type="date" required
                    value={bulkValues.endDate} onChange={handleBulkChange}
                    error={bulkErrors.endDate} />
                </div>
              </div>

              <label className="form-label">Days of Week <span className="text-danger">*</span></label>
              <div className="d-flex flex-wrap gap-2 mb-2">
                {DAYS_OF_WEEK.map((day) => (
                  <button
                    key={day} type="button"
                    className={`btn btn-sm ${bulkValues.daysOfWeek.includes(day) ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => toggleBulkDay(day)}
                  >
                    {day.slice(0, 3)}
                  </button>
                ))}
              </div>
              {bulkErrors.daysOfWeek && <div className="text-danger small mb-3">{bulkErrors.daysOfWeek}</div>}

              <div className="row">
                <div className="col-md-6">
                  <InputField label="Start Time" name="startTime" type="time" required
                    value={bulkValues.startTime} onChange={handleBulkChange}
                    error={bulkErrors.startTime} />
                </div>
                <div className="col-md-6">
                  <InputField label="End Time" name="endTime" type="time" required
                    value={bulkValues.endTime} onChange={handleBulkChange}
                    error={bulkErrors.endTime} />
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <InputField label="Slot Duration (minutes)" name="slotDurationMinutes" type="number" required
                    value={bulkValues.slotDurationMinutes} onChange={handleBulkChange}
                    error={bulkErrors.slotDurationMinutes} />
                </div>
                <div className="col-md-4">
                  <InputField label="Maximum Patients" name="maximumPatients" type="number" required
                    value={bulkValues.maximumPatients} onChange={handleBulkChange}
                    error={bulkErrors.maximumPatients} />
                </div>
                <div className="col-md-4">
                  <InputField label="Consultation Mode" name="consultationMode" as="select" required
                    value={bulkValues.consultationMode} onChange={handleBulkChange}>
                    {CONSULTATION_MODES.map((m) => <option key={m} value={m}>{m}</option>)}
                  </InputField>
                </div>
              </div>
              <SubmitButton loading={bulkSubmitting}>Publish Availability for Range</SubmitButton>
            </form>
          )}
        </div>
      </div>

      <h5 className="mb-3">Published Blocks</h5>
      {loading ? (
        <Loader />
      ) : availability.length === 0 ? (
        <div className="alert alert-light border">No availability published yet.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover bg-white align-middle">
            <thead>
              <tr>
                <th>Date</th><th>Time</th><th>Duration</th><th>Capacity</th><th>Mode</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {availability.map((block) => (
                <tr key={block.id}>
                  <td>{block.availableDate}</td>
                  <td>{block.startTime} - {block.endTime}</td>
                  <td>{block.slotDurationMinutes} min</td>
                  <td>{block.bookedCount} / {block.maximumPatients}</td>
                  <td>{block.consultationMode}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[block.status] || 'secondary'}`}>{block.status}</span></td>
                  <td className="d-flex gap-1">
                    {block.status !== 'FULLY_BOOKED' && (
                      <button className="btn btn-sm btn-outline-secondary" onClick={() => handleDeactivate(block)}>
                        {block.status === 'INACTIVE' ? 'Activate' : 'Deactivate'}
                      </button>
                    )}
                    {block.bookedCount === 0 && (
                      <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(block.id)}>
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
