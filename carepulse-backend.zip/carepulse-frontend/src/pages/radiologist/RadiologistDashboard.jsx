import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  getRequestedScans, uploadScanImages, uploadRadiologyReport, markRadiologyReportReady,
} from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const STATUS_BADGE = { REQUESTED: 'secondary', IN_PROGRESS: 'warning', READY: 'success' };

export default function RadiologistDashboard() {
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [actioningId, setActioningId] = useState(null);

  const [imagingId, setImagingId] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [imageUrlError, setImageUrlError] = useState('');

  const [reportingId, setReportingId] = useState(null);
  const [resultSummary, setResultSummary] = useState('');
  const [reportFile, setReportFile] = useState(null);
  const [reportErrors, setReportErrors] = useState({});

  useEffect(() => {
    loadQueue();
  }, []);

  const loadQueue = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getRequestedScans();
      setScans(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load scan requests');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadImages = async (event, scanId) => {
    event.preventDefault();
    const validationErrors = runValidators(
      { imageUrl },
      { imageUrl: (v) => validateRequired(v, 'Image URL') || validateMaxLength(v, 'Image URL', 500) }
    );
    setImageUrlError(validationErrors.imageUrl || '');
    if (hasErrors(validationErrors)) return;

    setActioningId(scanId);
    setError('');
    try {
      await uploadScanImages(scanId, { imageUrl });
      setSuccessMessage('Scan images uploaded');
      setImagingId(null);
      setImageUrl('');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to upload scan images');
    } finally {
      setActioningId(null);
    }
  };

  const handleReportFileChange = (event) => {
    const file = event.target.files[0] || null;
    setReportFile(file);
    if (file && file.type !== 'application/pdf') {
      setReportErrors((p) => ({ ...p, reportFile: 'Only PDF files are allowed' }));
    } else {
      setReportErrors((p) => ({ ...p, reportFile: '' }));
    }
  };

  const handleUploadReport = async (event, scanId) => {
    event.preventDefault();
    const validationErrors = runValidators(
      { resultSummary },
      { resultSummary: (v) => validateRequired(v, 'Result summary') || validateMaxLength(v, 'Result summary', 2000) }
    );
    if (!reportFile) {
      validationErrors.reportFile = 'A report PDF file is required';
    } else if (reportFile.type !== 'application/pdf') {
      validationErrors.reportFile = 'Only PDF files are allowed';
    }
    setReportErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setActioningId(scanId);
    setError('');
    try {
      await uploadRadiologyReport(scanId, { resultSummary, file: reportFile });
      setSuccessMessage('Radiology report uploaded');
      setReportingId(null);
      setResultSummary('');
      setReportFile(null);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to upload report');
    } finally {
      setActioningId(null);
    }
  };

  const handleMarkReady = async (scanId) => {
    setActioningId(scanId);
    setError('');
    try {
      await markRadiologyReportReady(scanId);
      setSuccessMessage('Report marked as READY - the patient has been notified');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to mark this report ready');
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Scan Requests</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : scans.length === 0 ? (
        <div className="alert alert-light border">No scan requests awaiting pickup.</div>
      ) : (
        scans.map((scan) => (
          <div key={scan.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <h6 className="mb-0">{scan.scanType}</h6>
                  <small className="text-muted">Patient: {scan.patientName} · Ordered by Dr. {scan.requestingDoctorName}</small>
                </div>
                <span className={`badge bg-${STATUS_BADGE[scan.status] || 'secondary'}`}>{scan.status}</span>
              </div>

              <div className="d-flex gap-2 mb-2">
                {!scan.imageUrl && imagingId !== scan.id && (
                  <button className="btn btn-sm btn-primary" onClick={() => { setImagingId(scan.id); setImageUrl(''); setImageUrlError(''); }}>
                    Upload Scan Images
                  </button>
                )}
                {scan.imageUrl && !scan.reportAvailable && reportingId !== scan.id && (
                  <button className="btn btn-sm btn-primary" onClick={() => { setReportingId(scan.id); setResultSummary(''); setReportFile(null); setReportErrors({}); }}>
                    Upload Report
                  </button>
                )}
                {scan.status === 'IN_PROGRESS' && scan.reportAvailable && (
                  <button className="btn btn-sm btn-success" disabled={actioningId === scan.id} onClick={() => handleMarkReady(scan.id)}>
                    Mark Report Ready
                  </button>
                )}
              </div>

              {imagingId === scan.id && (
                <form onSubmit={(e) => handleUploadImages(e, scan.id)} noValidate className="border-top pt-2">
                  <InputField
                    label="Scan Image URL" name="imageUrl" required placeholder="https://..."
                    value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} error={imageUrlError}
                  />
                  <div className="d-flex gap-2">
                    <div className="flex-fill"><SubmitButton loading={actioningId === scan.id}>Save Images</SubmitButton></div>
                    <button type="button" className="btn btn-outline-secondary" onClick={() => setImagingId(null)}>Cancel</button>
                  </div>
                </form>
              )}

              {reportingId === scan.id && (
                <form onSubmit={(e) => handleUploadReport(e, scan.id)} noValidate className="border-top pt-2">
                  <InputField
                    label="Result Summary" name="resultSummary" as="textarea" required
                    value={resultSummary} onChange={(e) => setResultSummary(e.target.value)}
                    error={reportErrors.resultSummary}
                  />
                  <div className="mb-2">
                    <label className="form-label">Report PDF File <span className="text-danger">*</span></label>
                    <input
                      type="file" accept="application/pdf"
                      className={`form-control ${reportErrors.reportFile ? 'is-invalid' : ''}`}
                      onChange={handleReportFileChange}
                    />
                    {reportErrors.reportFile && <div className="invalid-feedback">{reportErrors.reportFile}</div>}
                  </div>
                  <div className="d-flex gap-2">
                    <div className="flex-fill"><SubmitButton loading={actioningId === scan.id}>Save Report</SubmitButton></div>
                    <button type="button" className="btn btn-outline-secondary" onClick={() => setReportingId(null)}>Cancel</button>
                  </div>
                </form>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
