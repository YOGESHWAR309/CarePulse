import React from 'react';
import { useAuth } from '../../context/AuthContext';

/**
 * Minimal placeholder shown right after login for every role. Each of
 * these becomes a full dashboard (appointments today, quick actions, etc.)
 * in the next build pass - this establishes the route/page shell first so
 * navigation and role-based access are provably correct end-to-end before
 * layering in feature-specific screens.
 */
export default function RoleDashboard({ title }) {
  const { user } = useAuth();
  return (
    <div className="container mt-4">
      <h2>{title}</h2>
      <p className="text-muted">Welcome, {user?.firstName} {user?.lastName}.</p>
      <div className="alert alert-info">
        This dashboard's detailed widgets are being built out next - navigation and role-based access control are fully wired for this role already.
      </div>
    </div>
  );
}
