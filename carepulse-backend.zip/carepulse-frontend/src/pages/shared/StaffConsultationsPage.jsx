import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getStaffTodayConsultations, getStaffUpcomingConsultations, completeStaffConsultation } from '../../api/hospitalApi';
import { useAuth } from '../../context/AuthContext';

const STATUS_BADGE = { BOOKED: 'primary', RESCHEDULED: 'info', COMPLETED: 'success', CANCELLED: 'secondary' };
const COMPLETABLE_STATUSES = ['BOOKED', 'RESCHEDULED'];

/** Shared by Dietician and Nutritionist - identical endpoints, only the "Write Plan" destination differs by role. */
export default function StaffConsultationsPage({ scope = 'today' }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const planRoute = user?.role === 'DIETICIAN' ? '/dietician/write-plan' : '/nutritionist/write-plan';

  const [consultations, setConsultations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [completingId, setCompletingId] = useState(null);

  useEffect(() => {
    loadConsultations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope]);

  const loadConsultations = async () => {
    setLoading(true);
    setError('');
    try {
      const res = scope === 'today' ? await getStaffTodayConsultations() : await getStaffUpcomingConsultations();
      setConsultations(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load consultations');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async (id) => {
    setCompletingId(id);
    setError('');
    setSuccessMessage('');
    try {
      await completeStaffConsultation(id);
      setSuccessMessage('Consultation marked as completed. You can now write up the plan.');
      loadConsultations();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to complete this consultation');
    } finally {
      setCompletingId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">{scope === 'today' ? "Today's Consultations" : 'Upcoming Consultations'}</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : consultations.length === 0 ? (
        <div className="alert alert-light border">No consultations {scope === 'today' ? 'today' : 'upcoming'}.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead><tr><th>Patient</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {consultations.map((c) => (
                <tr key={c.id}>
                  <td>{c.patientName}</td>
                  <td>{c.appointmentDate}</td>
                  <td>{c.startTime}</td>
                  <td className="small">{c.reasonForVisit || '-'}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[c.status] || 'secondary'}`}>{c.status}</span></td>
                  <td className="d-flex gap-1">
                    {COMPLETABLE_STATUSES.includes(c.status) && (
                      <button className="btn btn-sm btn-outline-success" disabled={completingId === c.id} onClick={() => handleComplete(c.id)}>
                        {completingId === c.id ? '...' : 'Complete'}
                      </button>
                    )}
                    {c.status === 'COMPLETED' && (
                      <button className="btn btn-sm btn-primary" onClick={() => navigate(`${planRoute}/${c.id}`, { state: { consultation: c } })}>
                        Write Plan
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
