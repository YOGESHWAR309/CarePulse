import React, { useState } from 'react';
import { useLocation, useParams, useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { createDietPlan, createNutritionPlan } from '../../api/hospitalApi';
import { useAuth } from '../../context/AuthContext';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

/**
 * Shared by Dietician (writes a DietPlan) and Nutritionist (writes a
 * NutritionPlan) - which create function fires is decided by the logged-in
 * user's role, since both entities require the exact same
 * {consultationAppointmentId, planDetails} shape and the same "consultation
 * must be COMPLETED, one plan per consultation" backend rule.
 */
export default function WritePlanPage() {
  const { appointmentId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const consultation = location.state?.consultation;

  const isDietician = user?.role === 'DIETICIAN';
  const planLabel = isDietician ? 'Diet Plan' : 'Nutrition Plan';
  const backRoute = isDietician ? '/dietician/consultations/today' : '/nutritionist/consultations/today';

  const [planDetails, setPlanDetails] = useState('');
  const [error, setError] = useState('');
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (event) => {
    setPlanDetails(event.target.value);
    if (error) setError('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators(
      { planDetails },
      { planDetails: (v) => validateRequired(v, 'Plan details') || validateMaxLength(v, 'Plan details', 3000) }
    );
    setError(validationErrors.planDetails || '');
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    try {
      const payload = { consultationAppointmentId: Number(appointmentId), planDetails };
      if (isDietician) {
        await createDietPlan(payload);
      } else {
        await createNutritionPlan(payload);
      }
      navigate(backRoute, { state: { message: `${planLabel} saved successfully.` } });
    } catch (err) {
      setServerError(err.response?.data?.message || `Unable to save ${planLabel.toLowerCase()}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 700 }}>
      <h2 className="mb-4">Write {planLabel} - {consultation?.patientName || `Consultation #${appointmentId}`}</h2>
      <Alert message={serverError} onClose={() => setServerError('')} />

      <div className="card shadow-sm">
        <div className="card-body">
          <form onSubmit={handleSubmit} noValidate>
            <InputField
              label={`${planLabel} Details`} name="planDetails" as="textarea" required
              placeholder={isDietician
                ? 'e.g. Breakfast: oatmeal with fruit. Lunch: grilled chicken with vegetables...'
                : 'e.g. Daily calorie target: 1800 kcal. Protein: 90g, Carbs: 200g, Fat: 60g...'}
              value={planDetails} onChange={handleChange} error={error}
            />
            <SubmitButton loading={submitting}>Save {planLabel}</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
