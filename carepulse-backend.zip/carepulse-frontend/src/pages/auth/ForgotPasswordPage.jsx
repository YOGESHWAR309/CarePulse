import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { forgotPassword } from '../../api/authApi';
import { validateEmail, runValidators, hasErrors } from '../../utils/validators';

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    setEmail(event.target.value);
    if (error) setError('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators({ email }, { email: validateEmail });
    setError(validationErrors.email || '');
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      await forgotPassword({ email });
      // Backend intentionally responds the same way whether or not the email
      // exists (avoids leaking which emails are registered) - the frontend
      // always proceeds to the OTP screen regardless.
      navigate('/verify-otp', { state: { email, purpose: 'PASSWORD_RESET' } });
    } catch (err) {
      setServerError(err.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-2">Forgot Password</h3>
              <p className="text-center text-muted small mb-4">
                Enter your account email and we'll send you a one-time code to reset your password.
              </p>

              <Alert message={serverError} onClose={() => setServerError('')} />

              <form onSubmit={handleSubmit} noValidate>
                <InputField
                  label="Email" name="email" type="email" required
                  value={email} onChange={handleChange}
                  error={error}
                />
                <SubmitButton loading={loading}>Send OTP</SubmitButton>
              </form>

              <p className="text-center mt-3 mb-0">
                <Link to="/login">Back to login</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
