import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { registerPatient } from '../../api/authApi';
import {
  validateName,
  validateEmail,
  validatePassword,
  validateConfirmPassword,
  validatePhone,
  runValidators,
  hasErrors,
} from '../../utils/validators';

const initialValues = {
  firstName: '',
  lastName: '',
  email: '',
  password: '',
  confirmPassword: '',
  phoneNumber: '',
};

/** Patient self-registration - POST /api/auth/register. Every field is validated on blur AND again on submit, mirroring PatientRegisterRequest's bean-validation rules exactly. */
export default function RegisterPage() {
  const navigate = useNavigate();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    firstName: (v) => validateName(v, 'First name', 100),
    lastName: (v) => validateName(v, 'Last name', 100),
    email: validateEmail,
    password: validatePassword,
    confirmPassword: (v) => validateConfirmPassword(values.password, v),
    phoneNumber: validatePhone,
  };

  const validateField = (name, value) => {
    const validatorFn = validatorMap[name];
    return validatorFn ? validatorFn(value) : '';
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) {
      setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
    }
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({
      firstName: true, lastName: true, email: true,
      password: true, confirmPassword: true, phoneNumber: true,
    });

    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      await registerPatient({
        firstName: values.firstName,
        lastName: values.lastName,
        email: values.email,
        password: values.password,
        phoneNumber: values.phoneNumber,
      });
      navigate('/verify-otp', { state: { email: values.email, purpose: 'REGISTRATION' } });
    } catch (err) {
      setServerError(err.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-5">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-4">Create your CarePulse account</h3>
              <Alert message={serverError} onClose={() => setServerError('')} />

              <form onSubmit={handleSubmit} noValidate>
                <div className="row">
                  <div className="col-6">
                    <InputField
                      label="First Name" name="firstName" required
                      value={values.firstName} onChange={handleChange} onBlur={handleBlur}
                      error={touched.firstName && errors.firstName}
                    />
                  </div>
                  <div className="col-6">
                    <InputField
                      label="Last Name" name="lastName" required
                      value={values.lastName} onChange={handleChange} onBlur={handleBlur}
                      error={touched.lastName && errors.lastName}
                    />
                  </div>
                </div>

                <InputField
                  label="Email" name="email" type="email" required
                  value={values.email} onChange={handleChange} onBlur={handleBlur}
                  error={touched.email && errors.email}
                />

                <InputField
                  label="Phone Number" name="phoneNumber" type="tel" required
                  placeholder="e.g. 9876543210"
                  value={values.phoneNumber} onChange={handleChange} onBlur={handleBlur}
                  error={touched.phoneNumber && errors.phoneNumber}
                />

                <InputField
                  label="Password" name="password" type="password" required
                  value={values.password} onChange={handleChange} onBlur={handleBlur}
                  error={touched.password && errors.password}
                />
                <div className="form-text mb-3">
                  At least 8 characters, with uppercase, lowercase, a digit, and a special character.
                </div>

                <InputField
                  label="Confirm Password" name="confirmPassword" type="password" required
                  value={values.confirmPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.confirmPassword && errors.confirmPassword}
                />

                <SubmitButton loading={loading}>Register</SubmitButton>
              </form>

              <p className="text-center mt-3 mb-0">
                Already have an account? <Link to="/login">Log in</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
