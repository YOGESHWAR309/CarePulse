import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { changePassword } from '../../api/authApi';
import { useAuth } from '../../context/AuthContext';
import { validateRequired, validatePassword, validateConfirmPassword, runValidators, hasErrors } from '../../utils/validators';
import { ROLE_HOME_ROUTE } from '../../utils/constants';

const initialValues = { currentPassword: '', newPassword: '', confirmPassword: '' };

/**
 * Used both for a normal voluntary password change AND the mandatory
 * first-login flow for staff/doctors created by Admin (their temp
 * password must be changed before they can do anything else -
 * distinguished by location.state.firstLogin, passed from LoginPage).
 */
export default function ChangePasswordPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isFirstLogin = Boolean(location.state?.firstLogin);

  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    currentPassword: (v) => validateRequired(v, 'Current password'),
    newPassword: validatePassword,
    confirmPassword: (v) => validateConfirmPassword(values.newPassword, v),
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');
    setSuccessMessage('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({ currentPassword: true, newPassword: true, confirmPassword: true });
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      await changePassword({
        currentPassword: values.currentPassword,
        newPassword: values.newPassword,
      });

      if (isFirstLogin && user) {
        navigate(ROLE_HOME_ROUTE[user.role] || '/', {
          state: { message: 'Password changed successfully. Welcome to CarePulse!' },
        });
        return;
      }

      setSuccessMessage('Password changed successfully.');
      setValues(initialValues);
      setTouched({});
    } catch (err) {
      setServerError(err.response?.data?.message || 'Unable to change password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-2">Change Password</h3>
              {isFirstLogin && (
                <p className="text-center text-muted small mb-4">
                  For security, please set a new password before continuing.
                </p>
              )}

              <Alert message={serverError} onClose={() => setServerError('')} />
              <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

              <form onSubmit={handleSubmit} noValidate>
                <InputField
                  label="Current Password" name="currentPassword" type="password" required
                  value={values.currentPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.currentPassword && errors.currentPassword}
                />
                <InputField
                  label="New Password" name="newPassword" type="password" required
                  value={values.newPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.newPassword && errors.newPassword}
                />
                <div className="form-text mb-3">
                  At least 8 characters, with uppercase, lowercase, a digit, and a special character.
                </div>
                <InputField
                  label="Confirm New Password" name="confirmPassword" type="password" required
                  value={values.confirmPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.confirmPassword && errors.confirmPassword}
                />

                <SubmitButton loading={loading}>Change Password</SubmitButton>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
