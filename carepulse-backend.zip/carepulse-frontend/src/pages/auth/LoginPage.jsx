import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { login } from '../../api/authApi';
import { useAuth } from '../../context/AuthContext';
import { validateEmail, validateRequired, runValidators, hasErrors } from '../../utils/validators';
import { ROLE_HOME_ROUTE } from '../../utils/constants';

const initialValues = { email: '', password: '' };

/** Login for EVERY role (Admin, Patient, Doctor, all staff) - POST /api/auth/login. */
export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { loginSession } = useAuth();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState(
    location.state?.sessionExpired ? "You've been logged out due to inactivity. Please log in again." : ''
  );
  const [isSessionExpiredNotice, setIsSessionExpiredNotice] = useState(Boolean(location.state?.sessionExpired));
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    email: validateEmail,
    password: (v) => validateRequired(v, 'Password'),
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({ email: true, password: true });
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      const response = await login(values);
      loginSession(response.data);

      // Staff/doctors created by Admin must change their temp password before doing anything else.
      if (response.data.firstLogin) {
        navigate('/change-password', { state: { firstLogin: true } });
        return;
      }

      navigate(ROLE_HOME_ROUTE[response.data.role] || '/');
    } catch (err) {
      setIsSessionExpiredNotice(false);
      setServerError(err.response?.data?.message || 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-4">Log in to CarePulse</h3>
              <Alert
                type={isSessionExpiredNotice ? 'warning' : 'danger'}
                message={serverError}
                onClose={() => setServerError('')}
              />

              <form onSubmit={handleSubmit} noValidate>
                <InputField
                  label="Email" name="email" type="email" required
                  value={values.email} onChange={handleChange} onBlur={handleBlur}
                  error={touched.email && errors.email}
                />
                <InputField
                  label="Password" name="password" type="password" required
                  value={values.password} onChange={handleChange} onBlur={handleBlur}
                  error={touched.password && errors.password}
                />

                <div className="d-flex justify-content-end mb-3">
                  <Link to="/forgot-password" className="small">Forgot password?</Link>
                </div>

                <SubmitButton loading={loading}>Log In</SubmitButton>
              </form>

              <p className="text-center mt-3 mb-0">
                New patient? <Link to="/register">Register here</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
