import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { resetPassword } from '../../api/authApi';
import { validatePassword, validateConfirmPassword, runValidators, hasErrors } from '../../utils/validators';

const initialValues = { newPassword: '', confirmPassword: '' };

/** Final step of forgot-password - only reachable after OTP verification succeeded (email carried via navigation state). */
export default function ResetPasswordPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email || '';

  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    newPassword: validatePassword,
    confirmPassword: (v) => validateConfirmPassword(values.newPassword, v),
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({ newPassword: true, confirmPassword: true });
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      await resetPassword({ email, newPassword: values.newPassword });
      navigate('/login', { state: { message: 'Password reset successfully. Please log in.' } });
    } catch (err) {
      setServerError(err.response?.data?.message || 'Unable to reset password. Please verify your OTP again.');
    } finally {
      setLoading(false);
    }
  };

  if (!email) {
    return (
      <div className="container mt-5 text-center">
        <Alert message="Please complete OTP verification before resetting your password." />
        <Link to="/forgot-password">Start over</Link>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-4">Reset Password</h3>
              <Alert message={serverError} onClose={() => setServerError('')} />

              <form onSubmit={handleSubmit} noValidate>
                <InputField
                  label="New Password" name="newPassword" type="password" required
                  value={values.newPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.newPassword && errors.newPassword}
                />
                <div className="form-text mb-3">
                  At least 8 characters, with uppercase, lowercase, a digit, and a special character.
                </div>

                <InputField
                  label="Confirm New Password" name="confirmPassword" type="password" required
                  value={values.confirmPassword} onChange={handleChange} onBlur={handleBlur}
                  error={touched.confirmPassword && errors.confirmPassword}
                />

                <SubmitButton loading={loading}>Reset Password</SubmitButton>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
