import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { verifyOtp, resendOtp } from '../../api/authApi';
import { validateOtp, runValidators, hasErrors } from '../../utils/validators';

/**
 * Shared by both flows that need OTP confirmation: registration
 * (purpose=REGISTRATION, activates the account) and forgot-password
 * (purpose=PASSWORD_RESET, unlocks the reset-password step) - the
 * `purpose` and `email` are passed in via navigation state from
 * RegisterPage/ForgotPasswordPage.
 */
export default function VerifyOtpPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || '';
  const purpose = location.state?.purpose || 'REGISTRATION';

  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState('');
  const [serverError, setServerError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);

  const handleChange = (event) => {
    setOtpCode(event.target.value.replace(/\D/g, '').slice(0, 6));
    if (error) setError('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');
    setSuccessMessage('');

    const { otpCode: otpError } = runValidators({ otpCode }, { otpCode: validateOtp });
    setError(otpError || '');
    if (hasErrors({ ...(otpError ? { otpCode: otpError } : {}) })) return;

    setLoading(true);
    try {
      await verifyOtp({ email, otpCode, purpose });

      if (purpose === 'REGISTRATION') {
        navigate('/login', { state: { message: 'Account verified! You can now log in.' } });
      } else {
        navigate('/reset-password', { state: { email } });
      }
    } catch (err) {
      setServerError(err.response?.data?.message || 'Invalid or expired OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setServerError('');
    setSuccessMessage('');
    setResending(true);
    try {
      await resendOtp({ email });
      setSuccessMessage('A new OTP has been sent to your email.');
    } catch (err) {
      setServerError(err.response?.data?.message || 'Unable to resend OTP');
    } finally {
      setResending(false);
    }
  };

  if (!email) {
    return (
      <div className="container mt-5 text-center">
        <Alert message="No email found for OTP verification. Please register or request a password reset again." />
        <Link to="/login">Back to login</Link>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm mt-5">
            <div className="card-body p-4">
              <h3 className="text-center mb-2">Verify OTP</h3>
              <p className="text-center text-muted small mb-4">
                Enter the 6-digit code sent to <strong>{email}</strong>
              </p>

              <Alert message={serverError} onClose={() => setServerError('')} />
              <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

              <form onSubmit={handleSubmit} noValidate>
                <InputField
                  label="OTP Code" name="otpCode" required
                  placeholder="123456"
                  value={otpCode} onChange={handleChange}
                  error={error}
                />
                <SubmitButton loading={loading}>Verify</SubmitButton>
              </form>

              <div className="text-center mt-3">
                <button type="button" className="btn btn-link p-0" onClick={handleResend} disabled={resending}>
                  {resending ? 'Resending...' : "Didn't get a code? Resend OTP"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
