import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import StepIndicator from '../../components/common/StepIndicator';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  getBookableStaff,
  getStaffAvailability,
  getStaffAvailableSlots,
  bookConsultation,
} from '../../api/hospitalApi';
import { validateMaxLength, runValidators, hasErrors } from '../../utils/validators';
import { formatTime12h } from '../../utils/formatters';

const STEPS = ['Select Staff', 'Date & Slot', 'Confirm'];

/**
 * Mirrors BookAppointmentPage's exact wizard shape, but starts from the
 * staff directory (Dietician or Nutritionist, chosen via the :role route
 * param) instead of Department -> Doctor, since Dietician/Nutritionist
 * consultations skip the department-filtering step entirely.
 */
export default function BookConsultationPage() {
  const { role } = useParams(); // 'DIETICIAN' or 'NUTRITIONIST'
  const navigate = useNavigate();
  const [step, setStep] = useState(1);

  const [staffList, setStaffList] = useState([]);
  const [availabilityBlocks, setAvailabilityBlocks] = useState([]);
  const [slots, setSlots] = useState([]);

  const [selectedStaff, setSelectedStaff] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [reasonError, setReasonError] = useState('');

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadStaff();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  const loadStaff = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getBookableStaff(role);
      setStaffList(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load staff directory');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectStaff = async (staff) => {
    setSelectedStaff(staff);
    setSelectedDate('');
    setSlots([]);
    setLoading(true);
    setError('');
    try {
      const res = await getStaffAvailability(staff.staffProfileId);
      setAvailabilityBlocks(res.data);
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load availability');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectDate = async (date) => {
    setSelectedDate(date);
    setSelectedSlot(null);
    setLoading(true);
    setError('');
    try {
      const res = await getStaffAvailableSlots(selectedStaff.staffProfileId, date);
      setSlots(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load slots for this date');
    } finally {
      setLoading(false);
    }
  };

  const handleProceedToConfirm = () => {
    if (!selectedSlot) {
      setError('Please select a time slot before continuing');
      return;
    }
    setError('');
    setStep(3);
  };

  const handleReasonChange = (event) => {
    setReasonForVisit(event.target.value);
    if (reasonError) setReasonError('');
  };

  const handleConfirmBooking = async () => {
    const validationErrors = runValidators(
      { reasonForVisit },
      { reasonForVisit: (v) => validateMaxLength(v, 'Reason for visit', 500) }
    );
    setReasonError(validationErrors.reasonForVisit || '');
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    setError('');
    try {
      await bookConsultation({
        staffProfileId: selectedStaff.staffProfileId,
        availabilityId: selectedSlot.availabilityId,
        appointmentDate: selectedDate,
        slotStartTime: selectedSlot.slotStartTime,
        reasonForVisit: reasonForVisit || undefined,
      });
      const destination = role === 'DIETICIAN' ? '/patient/diet-plans' : '/patient/nutrition-plans';
      navigate(destination, { state: { message: 'Consultation booked successfully!' } });
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to book this consultation. It may have just been taken - please pick another slot.');
    } finally {
      setSubmitting(false);
    }
  };

  const availableDates = [...new Set(availabilityBlocks.map((b) => b.availableDate))];
  const roleLabel = role === 'DIETICIAN' ? 'Dietician' : 'Nutritionist';

  return (
    <div className="container mt-4" style={{ maxWidth: 800 }}>
      <h2 className="mb-4">Book a {roleLabel} Consultation</h2>
      <StepIndicator steps={STEPS} currentStep={step} />
      <Alert message={error} onClose={() => setError('')} />

      <div className="card shadow-sm">
        <div className="card-body p-4">
          {loading && <Loader />}

          {!loading && step === 1 && (
            <>
              <h5 className="mb-3">Select a {roleLabel}</h5>
              <div className="row g-3">
                {staffList.map((staff) => (
                  <div key={staff.staffProfileId} className="col-md-6">
                    <button
                      type="button"
                      className="btn btn-outline-primary w-100 text-start p-3"
                      onClick={() => handleSelectStaff(staff)}
                    >
                      <strong>{staff.fullName}</strong>
                      {staff.departmentName && <div className="small text-muted">{staff.departmentName}</div>}
                    </button>
                  </div>
                ))}
                {staffList.length === 0 && <p className="text-muted">No {roleLabel.toLowerCase()}s currently available.</p>}
              </div>
            </>
          )}

          {!loading && step === 2 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Choose Date & Time with {selectedStaff?.fullName}</h5>
                <button className="btn btn-link btn-sm" onClick={() => setStep(1)}>Change {roleLabel.toLowerCase()}</button>
              </div>

              <label className="form-label">Available Dates</label>
              <div className="d-flex flex-wrap gap-2 mb-4">
                {availableDates.map((date) => (
                  <button
                    key={date}
                    type="button"
                    className={`btn btn-sm ${selectedDate === date ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => handleSelectDate(date)}
                  >
                    {date}
                  </button>
                ))}
                {availableDates.length === 0 && <p className="text-muted">No upcoming availability published.</p>}
              </div>

              {selectedDate && (
                <>
                  <label className="form-label">Available Slots on {selectedDate}</label>
                  <div className="d-flex flex-wrap gap-2 mb-4">
                    {slots.map((slot) => (
                      <button
                        key={`${slot.availabilityId}-${slot.slotStartTime}`}
                        type="button"
                        disabled={!slot.bookable}
                        className={`btn btn-sm ${
                          selectedSlot?.slotStartTime === slot.slotStartTime ? 'btn-success' : 'btn-outline-secondary'
                        }`}
                        onClick={() => setSelectedSlot(slot)}
                      >
                        {formatTime12h(slot.slotStartTime)}
                      </button>
                    ))}
                  </div>
                  <button className="btn btn-primary" onClick={handleProceedToConfirm}>Continue</button>
                </>
              )}
            </>
          )}

          {!loading && step === 3 && (
            <form onSubmit={(e) => { e.preventDefault(); handleConfirmBooking(); }} noValidate>
              <h5 className="mb-3">Confirm Your Consultation</h5>
              <ul className="list-group mb-3">
                <li className="list-group-item d-flex justify-content-between"><span>{roleLabel}</span><strong>{selectedStaff?.fullName}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Date</span><strong>{selectedDate}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Time</span><strong>{formatTime12h(selectedSlot?.slotStartTime)}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Mode</span><strong>{selectedSlot?.consultationMode}</strong></li>
              </ul>

              <InputField
                label="Reason for Visit (optional)" name="reasonForVisit" as="textarea"
                value={reasonForVisit} onChange={handleReasonChange} error={reasonError}
              />

              <div className="d-flex gap-2">
                <button type="button" className="btn btn-outline-secondary" onClick={() => setStep(2)} disabled={submitting}>Back</button>
                <div className="flex-fill">
                  <SubmitButton loading={submitting} className="btn-success">Confirm & Book</SubmitButton>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
