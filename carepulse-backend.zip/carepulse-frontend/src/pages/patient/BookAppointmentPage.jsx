import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import StepIndicator from '../../components/common/StepIndicator';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  getActiveDepartments,
  getDoctorsByDepartment,
  getDoctorAvailability,
  getAvailableSlots,
  bookAppointment,
  getBookableStaff,
  getStaffAvailability,
  getStaffAvailableSlots,
  bookConsultation,
} from '../../api/hospitalApi';
import { validateMaxLength, runValidators, hasErrors } from '../../utils/validators';
import { formatTime12h } from '../../utils/formatters';

const STEPS = ['Department', 'Provider', 'Date & Slot', 'Confirm'];

// Synthetic "departments" that route into the Staff Directory (Dietician/
// Nutritionist) instead of the real Department -> Doctor directory. They're
// rendered as ordinary cards in step 1 alongside real departments so a
// patient books everything - doctors, dieticians, nutritionists - through
// a single funnel instead of two separate pages.
const STAFF_ROLE_CARDS = [
  { id: 'DIETICIAN', name: 'Dietician', description: 'Personalized diet plans and consultations', isStaffRole: true },
  { id: 'NUTRITIONIST', name: 'Nutritionist', description: 'Nutrition guidance and meal planning', isStaffRole: true },
];

/**
 * Unified booking wizard: step 1 lets the patient pick either a clinical
 * Department (-> Doctor directory) or a Dietician/Nutritionist "department"
 * (-> Staff directory). Which API family gets called for every subsequent
 * step (provider list, availability, slots, final booking) is decided by
 * `bookingType`, set the moment step 1 is chosen - APPOINTMENT drives the
 * DepartmentController -> DoctorController -> AvailabilityController chain
 * exactly as before; CONSULTATION drives StaffDirectoryController's
 * counterpart chain. Everything downstream (steps 2-4) is written against
 * a common "provider" shape so the UI doesn't need to branch per screen.
 */
export default function BookAppointmentPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);

  // 'APPOINTMENT' -> doctor endpoints, doctorId payload field
  // 'CONSULTATION' -> staff endpoints, staffProfileId payload field
  const [bookingType, setBookingType] = useState('APPOINTMENT');

  const [departments, setDepartments] = useState([]);
  const [providers, setProviders] = useState([]);
  const [availabilityBlocks, setAvailabilityBlocks] = useState([]);
  const [slots, setSlots] = useState([]);

  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [reasonError, setReasonError] = useState('');

  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadDepartments();
  }, []);

  const loadDepartments = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getActiveDepartments();
      setDepartments(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load departments');
    } finally {
      setLoading(false);
    }
  };

  // Step 1: department (doctor) card selected
  const handleSelectDepartment = async (department) => {
    setBookingType('APPOINTMENT');
    setSelectedDepartment(department);
    setSelectedProvider(null);
    setLoading(true);
    setError('');
    try {
      const res = await getDoctorsByDepartment(department.id);
      setProviders(
        res.data.map((doctor) => ({
          id: doctor.id,
          fullName: doctor.fullName,
          subtitle: doctor.specialization || 'General',
          fee: doctor.consultationFee,
        }))
      );
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load doctors for this department');
    } finally {
      setLoading(false);
    }
  };

  // Step 1: Dietician/Nutritionist card selected - same step, different API family
  const handleSelectStaffRole = async (staffRole) => {
    setBookingType('CONSULTATION');
    setSelectedDepartment(staffRole);
    setSelectedProvider(null);
    setLoading(true);
    setError('');
    try {
      const res = await getBookableStaff(staffRole.id);
      setProviders(
        res.data.map((staff) => ({
          id: staff.staffProfileId,
          fullName: staff.fullName,
          subtitle: staff.departmentName || staffRole.name,
          fee: null,
        }))
      );
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.message || `Unable to load ${staffRole.name.toLowerCase()}s`);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectProvider = async (provider) => {
    setSelectedProvider(provider);
    setSelectedDate('');
    setSlots([]);
    setLoading(true);
    setError('');
    try {
      const res =
        bookingType === 'CONSULTATION'
          ? await getStaffAvailability(provider.id)
          : await getDoctorAvailability(provider.id);
      setAvailabilityBlocks(res.data);
      setStep(3);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load this provider\'s availability');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectDate = async (date) => {
    setSelectedDate(date);
    setSelectedSlot(null);
    setLoading(true);
    setError('');
    try {
      const res =
        bookingType === 'CONSULTATION'
          ? await getStaffAvailableSlots(selectedProvider.id, date)
          : await getAvailableSlots(selectedProvider.id, date);
      setSlots(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load slots for this date');
    } finally {
      setLoading(false);
    }
  };

  const handleProceedToConfirm = () => {
    if (!selectedSlot) {
      setError('Please select a time slot before continuing');
      return;
    }
    setError('');
    setStep(4);
  };

  const handleReasonChange = (event) => {
    setReasonForVisit(event.target.value);
    if (reasonError) setReasonError('');
  };

  const handleConfirmBooking = async () => {
    const validationErrors = runValidators(
      { reasonForVisit },
      { reasonForVisit: (v) => validateMaxLength(v, 'Reason for visit', 500) }
    );
    setReasonError(validationErrors.reasonForVisit || '');
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    setError('');
    try {
      if (bookingType === 'CONSULTATION') {
        await bookConsultation({
          staffProfileId: selectedProvider.id,
          availabilityId: selectedSlot.availabilityId,
          appointmentDate: selectedDate,
          slotStartTime: selectedSlot.slotStartTime,
          reasonForVisit: reasonForVisit || undefined,
        });
        const destination = selectedDepartment.id === 'DIETICIAN' ? '/patient/diet-plans' : '/patient/nutrition-plans';
        navigate(destination, { state: { message: 'Consultation booked successfully!' } });
      } else {
        await bookAppointment({
          doctorId: selectedProvider.id,
          availabilityId: selectedSlot.availabilityId,
          appointmentDate: selectedDate,
          slotStartTime: selectedSlot.slotStartTime,
          reasonForVisit: reasonForVisit || undefined,
        });
        navigate('/patient/appointments', { state: { message: 'Appointment booked successfully!' } });
      }
    } catch (err) {
      setError(
        err.response?.data?.message ||
          'Unable to book this appointment. It may have just been taken - please pick another slot.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  // Distinct available dates, derived from the provider's published availability blocks (step 3's data source).
  const availableDates = [...new Set(availabilityBlocks.map((b) => b.availableDate))];
  const providerLabel = bookingType === 'CONSULTATION' ? selectedDepartment?.name : 'Doctor';

  return (
    <div className="container mt-4" style={{ maxWidth: 800 }}>
      <h2 className="mb-4">Book an Appointment</h2>
      <StepIndicator steps={STEPS} currentStep={step} />
      <Alert message={error} onClose={() => setError('')} />

      <div className="card shadow-sm">
        <div className="card-body p-4">
          {loading && <Loader />}

          {!loading && step === 1 && (
            <>
              <h5 className="mb-3">Select a Department</h5>
              <div className="row g-3">
                {departments.map((dept) => (
                  <div key={dept.id} className="col-md-6">
                    <button
                      type="button"
                      className="btn btn-outline-primary w-100 text-start p-3"
                      onClick={() => handleSelectDepartment(dept)}
                    >
                      <strong>{dept.name}</strong>
                      {dept.description && <div className="small text-muted">{dept.description}</div>}
                    </button>
                  </div>
                ))}
                {STAFF_ROLE_CARDS.map((staffRole) => (
                  <div key={staffRole.id} className="col-md-6">
                    <button
                      type="button"
                      className="btn btn-outline-primary w-100 text-start p-3"
                      onClick={() => handleSelectStaffRole(staffRole)}
                    >
                      <strong>{staffRole.name}</strong>
                      <div className="small text-muted">{staffRole.description}</div>
                    </button>
                  </div>
                ))}
                {departments.length === 0 && (
                  <p className="text-muted">No departments available right now.</p>
                )}
              </div>
            </>
          )}

          {!loading && step === 2 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Select a {providerLabel} in {selectedDepartment?.name}</h5>
                <button className="btn btn-link btn-sm" onClick={() => setStep(1)}>Change department</button>
              </div>
              <div className="row g-3">
                {providers.map((provider) => (
                  <div key={provider.id} className="col-md-6">
                    <button
                      type="button"
                      className="btn btn-outline-primary w-100 text-start p-3"
                      onClick={() => handleSelectProvider(provider)}
                    >
                      <strong>{provider.fullName}</strong>
                      <div className="small text-muted">{provider.subtitle}</div>
                      {provider.fee != null && (
                        <div className="small">Fee: ₹{provider.fee}</div>
                      )}
                    </button>
                  </div>
                ))}
                {providers.length === 0 && (
                  <p className="text-muted">No {providerLabel.toLowerCase()}s currently available in this department.</p>
                )}
              </div>
            </>
          )}

          {!loading && step === 3 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Choose Date & Time with {selectedProvider?.fullName}</h5>
                <button className="btn btn-link btn-sm" onClick={() => setStep(2)}>Change {providerLabel.toLowerCase()}</button>
              </div>

              <label className="form-label">Available Dates</label>
              <div className="d-flex flex-wrap gap-2 mb-4">
                {availableDates.map((date) => (
                  <button
                    key={date}
                    type="button"
                    className={`btn btn-sm ${selectedDate === date ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => handleSelectDate(date)}
                  >
                    {date}
                  </button>
                ))}
                {availableDates.length === 0 && <p className="text-muted">This provider has no upcoming availability.</p>}
              </div>

              {selectedDate && (
                <>
                  <label className="form-label">Available Slots on {selectedDate}</label>
                  <div className="d-flex flex-wrap gap-2 mb-4">
                    {slots.map((slot) => (
                      <button
                        key={`${slot.availabilityId}-${slot.slotStartTime}`}
                        type="button"
                        disabled={!slot.bookable}
                        className={`btn btn-sm ${
                          selectedSlot?.slotStartTime === slot.slotStartTime ? 'btn-success' : 'btn-outline-secondary'
                        }`}
                        onClick={() => setSelectedSlot(slot)}
                        title={!slot.bookable ? 'This slot is fully booked' : ''}
                      >
                        {formatTime12h(slot.slotStartTime)}
                      </button>
                    ))}
                    {slots.length > 0 && slots.every((s) => !s.bookable) && (
                      <p className="text-muted small w-100 mt-2">All slots on this date are fully booked - try another date.</p>
                    )}
                  </div>

                  <button className="btn btn-primary" onClick={handleProceedToConfirm}>
                    Continue
                  </button>
                </>
              )}
            </>
          )}

          {!loading && step === 4 && (
            <form
              onSubmit={(event) => {
                event.preventDefault();
                handleConfirmBooking();
              }}
              noValidate
            >
              <h5 className="mb-3">Confirm Your Appointment</h5>
              <ul className="list-group mb-3">
                <li className="list-group-item d-flex justify-content-between">
                  <span>Department</span><strong>{selectedDepartment?.name}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                  <span>{providerLabel}</span><strong>{selectedProvider?.fullName}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                  <span>Date</span><strong>{selectedDate}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                  <span>Time</span><strong>{formatTime12h(selectedSlot?.slotStartTime)}</strong>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                  <span>Mode</span><strong>{selectedSlot?.consultationMode}</strong>
                </li>
              </ul>

              <InputField
                label="Reason for Visit (optional)"
                name="reasonForVisit"
                as="textarea"
                placeholder="Briefly describe your symptoms or reason for the visit"
                value={reasonForVisit}
                onChange={handleReasonChange}
                error={reasonError}
              />

              <div className="d-flex gap-2">
                <button type="button" className="btn btn-outline-secondary" onClick={() => setStep(3)} disabled={submitting}>
                  Back
                </button>
                <div className="flex-fill">
                  <SubmitButton loading={submitting} className="btn-success">
                    Confirm & Book Appointment
                  </SubmitButton>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
