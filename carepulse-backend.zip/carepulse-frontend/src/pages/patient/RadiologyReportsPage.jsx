import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyRadiologyRequests, getRadiologyReportFile } from '../../api/hospitalApi';

const STATUS_BADGE = { REQUESTED: 'secondary', SAMPLE_COLLECTED: 'info', IN_PROGRESS: 'warning', READY: 'success', CANCELLED: 'dark' };

export default function RadiologyReportsPage() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [downloadingId, setDownloadingId] = useState(null);

  useEffect(() => {
    getMyRadiologyRequests()
      .then((res) => setRequests(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load radiology reports'))
      .finally(() => setLoading(false));
  }, []);

  const handleViewReport = async (req) => {
    setError('');
    setDownloadingId(req.id);
    try {
      const blob = await getRadiologyReportFile(req.id);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (err) {
      setError('Unable to open the report file');
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Radiology Reports</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : requests.length === 0 ? (
        <div className="alert alert-light border">No radiology requests on record.</div>
      ) : (
        requests.map((req) => (
          <div key={req.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start">
                <h6>{req.scanType}</h6>
                <span className={`badge bg-${STATUS_BADGE[req.status] || 'secondary'}`}>{req.status}</span>
              </div>
              <small className="text-muted d-block mb-2">
                Ordered by Dr. {req.requestingDoctorName} · Radiologist: {req.assignedRadiologistName}
              </small>

              {req.status === 'READY' && (
                <>
                  {req.resultSummary && <p className="mb-1"><strong>Summary:</strong> {req.resultSummary}</p>}
                  <div className="d-flex gap-2">
                    {req.imageUrl && (
                      <a href={req.imageUrl} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-secondary">
                        View Scan Images
                      </a>
                    )}
                    {req.reportAvailable && (
                      <button
                        className="btn btn-sm btn-outline-primary"
                        disabled={downloadingId === req.id}
                        onClick={() => handleViewReport(req)}
                      >
                        {downloadingId === req.id ? 'Opening...' : 'View Full Report'}
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
