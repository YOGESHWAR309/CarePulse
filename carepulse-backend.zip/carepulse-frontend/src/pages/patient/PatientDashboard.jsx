import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getMyBills } from '../../api/hospitalApi';

const QUICK_LINKS = [
  { to: '/patient/book-appointment', label: 'Book Appointment', icon: '📅', desc: 'Find a doctor and book a visit' },
  { to: '/patient/appointments', label: 'My Appointments', icon: '🗓️', desc: 'View, reschedule, or cancel' },
  { to: '/patient/medical-records', label: 'Medical Records', icon: '📋', desc: 'Past diagnoses and notes' },
  { to: '/patient/prescriptions', label: 'Prescriptions', icon: '💊', desc: 'View prescribed medicines' },
  { to: '/patient/lab-reports', label: 'Lab Reports', icon: '🧪', desc: 'Pathology test results' },
  { to: '/patient/radiology-reports', label: 'Radiology Reports', icon: '🩻', desc: 'Scan results' },
  { to: '/patient/diet-plans', label: 'Diet Plan', icon: '🥗', desc: 'From your Dietician' },
  { to: '/patient/nutrition-plans', label: 'Nutrition Plan', icon: '🍎', desc: 'From your Nutritionist' },
  { to: '/patient/bills', label: 'Bills & Payments', icon: '💳', desc: 'Pay outstanding bills' },
  { to: '/patient/profile', label: 'My Profile', icon: '👤', desc: 'Clinical & contact details' },
];

export default function PatientDashboard() {
  const { user } = useAuth();
  const [pendingBills, setPendingBills] = useState([]);

  useEffect(() => {
    // Best-effort only - a failure here shouldn't block the rest of the
    // dashboard, so errors are swallowed and the nudge just stays hidden.
    getMyBills()
      .then((res) => setPendingBills(res.data.filter((b) => b.status === 'PENDING')))
      .catch(() => {});
  }, []);

  const pendingTotal = pendingBills.reduce((sum, b) => sum + Number(b.amount), 0);

  return (
    <div className="container mt-4">
      <h2 className="mb-1">Welcome, {user?.firstName}!</h2>
      <p className="text-muted mb-4">What would you like to do today?</p>

      {pendingBills.length > 0 && (
        <div className="alert alert-warning d-flex justify-content-between align-items-center mb-4">
          <div>
            <strong>{pendingBills.length} bill{pendingBills.length > 1 ? 's' : ''} pending payment</strong>
            <span className="ms-2">Total due: ₹{pendingTotal.toFixed(2)}</span>
          </div>
          <Link to="/patient/bills" className="btn btn-sm btn-warning">Pay Now</Link>
        </div>
      )}

      <div className="row g-3">
        {QUICK_LINKS.map((link) => (
          <div key={link.to} className="col-md-4 col-sm-6">
            <Link to={link.to} className="text-decoration-none">
              <div className="card h-100 shadow-sm">
                <div className="card-body">
                  <div style={{ fontSize: '2rem' }}>{link.icon}</div>
                  <h6 className="mt-2 mb-1 text-dark">{link.label}</h6>
                  <p className="small text-muted mb-0">{link.desc}</p>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
