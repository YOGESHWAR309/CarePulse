import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyDietPlans } from '../../api/hospitalApi';

export default function DietPlansPage() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyDietPlans()
      .then((res) => setPlans(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load diet plans'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">My Diet Plans</h2>
        <Link to="/patient/book-consultation/DIETICIAN" className="btn btn-primary">
          Book Dietician Consultation
        </Link>
      </div>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : plans.length === 0 ? (
        <div className="alert alert-light border">
          No diet plans yet - book a consultation with a Dietician to get one.
        </div>
      ) : (
        plans.map((plan) => (
          <div key={plan.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <h6>From {plan.dieticianName}</h6>
                <small className="text-muted">{new Date(plan.createdAt).toLocaleDateString()}</small>
              </div>
              <p className="mb-0" style={{ whiteSpace: 'pre-wrap' }}>{plan.planDetails}</p>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
