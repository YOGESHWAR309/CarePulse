import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyPrescriptions } from '../../api/hospitalApi';

const STATUS_BADGE = { PENDING: 'warning', VERIFIED: 'info', DISPENSED: 'success', REJECTED: 'danger' };

export default function PrescriptionsPage() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyPrescriptions()
      .then((res) => setPrescriptions(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load prescriptions'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Prescriptions</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : prescriptions.length === 0 ? (
        <div className="alert alert-light border">No prescriptions yet.</div>
      ) : (
        prescriptions.map((rx) => (
          <div key={rx.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start">
                <h6>Dr. {rx.doctorName}</h6>
                <span className={`badge bg-${STATUS_BADGE[rx.status] || 'secondary'}`}>{rx.status}</span>
              </div>
              <small className="text-muted d-block mb-2">{new Date(rx.createdAt).toLocaleDateString()}</small>

              <table className="table table-sm mb-0">
                <thead>
                  <tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th><th>Instructions</th></tr>
                </thead>
                <tbody>
                  {rx.items?.map((item) => (
                    <tr key={item.id}>
                      <td>{item.medicineName}</td>
                      <td>{item.dosage}</td>
                      <td>{item.frequency}</td>
                      <td>{item.durationDays} day(s)</td>
                      <td>{item.instructions || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {rx.status === 'REJECTED' && rx.rejectionReason && (
                <div className="alert alert-danger mt-2 mb-0 py-2 small">Rejected: {rx.rejectionReason}</div>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
