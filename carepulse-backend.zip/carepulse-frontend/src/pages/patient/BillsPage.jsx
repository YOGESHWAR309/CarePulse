import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyBills, createPaymentOrder, verifyPayment, markPaymentFailed } from '../../api/hospitalApi';

const STATUS_BADGE = { PENDING: 'warning', PAID: 'success', FAILED: 'danger', REFUNDED: 'secondary' };

/** Dynamically loads Razorpay's checkout.js exactly once, reused by every "Pay Now" click. */
function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function BillsPage() {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [payingBillId, setPayingBillId] = useState(null);

  useEffect(() => {
    loadBills();
  }, []);

  const loadBills = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getMyBills();
      setBills(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load your bills');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Implements the exact backend workflow: create a Razorpay order server-side
   * (POST .../payment-order) -> open Razorpay Checkout with that order id ->
   * on success, send the three Razorpay callback values to
   * POST .../verify-payment, where the backend independently re-derives the
   * signature before trusting the payment - the frontend's "success" callback
   * alone is never treated as proof of payment.
   */
  const handlePayNow = async (bill) => {
    setError('');
    setSuccessMessage('');
    setPayingBillId(bill.id);

    const scriptLoaded = await loadRazorpayScript();
    if (!scriptLoaded) {
      setError('Unable to load the payment gateway. Please check your internet connection and try again.');
      setPayingBillId(null);
      return;
    }

    try {
      const orderRes = await createPaymentOrder(bill.id);
      const order = orderRes.data;

      const options = {
        key: order.razorpayKeyId,
        amount: order.amountInPaise,
        currency: order.currency,
        order_id: order.razorpayOrderId,
        name: 'CarePulse',
        description: `Invoice ${bill.invoiceNumber}`,
        handler: async (response) => {
          try {
            await verifyPayment(bill.id, {
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
            });
            setSuccessMessage('Payment successful! Thank you.');
            loadBills();
          } catch (verifyErr) {
            setError(verifyErr.response?.data?.message || 'Payment verification failed. Please contact support.');
          } finally {
            setPayingBillId(null);
          }
        },
        modal: {
          ondismiss: async () => {
            await markPaymentFailed(bill.id).catch(() => {});
            setPayingBillId(null);
            loadBills();
          },
        },
        theme: { color: '#0d6efd' },
      };

      const razorpayCheckout = new window.Razorpay(options);
      razorpayCheckout.open();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to start payment. Please try again.');
      setPayingBillId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Bills & Payments</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : bills.length === 0 ? (
        <div className="alert alert-light border">No bills yet.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead>
              <tr>
                <th>Invoice #</th><th>Amount</th><th>Status</th><th>Date</th><th></th>
              </tr>
            </thead>
            <tbody>
              {bills.map((bill) => (
                <tr key={bill.id}>
                  <td>{bill.invoiceNumber}</td>
                  <td>₹{bill.amount}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[bill.status] || 'secondary'}`}>{bill.status}</span></td>
                  <td>{new Date(bill.createdAt).toLocaleDateString()}</td>
                  <td>
                    {(bill.status === 'PENDING' || bill.status === 'FAILED') && (
                      <button
                        className="btn btn-sm btn-success"
                        disabled={payingBillId === bill.id}
                        onClick={() => handlePayNow(bill)}
                      >
                        {payingBillId === bill.id ? 'Processing...' : 'Pay Now'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
