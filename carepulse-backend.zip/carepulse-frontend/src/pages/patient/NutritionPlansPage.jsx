import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyNutritionPlans } from '../../api/hospitalApi';

export default function NutritionPlansPage() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyNutritionPlans()
      .then((res) => setPlans(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load nutrition plans'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">My Nutrition Plans</h2>
        <Link to="/patient/book-consultation/NUTRITIONIST" className="btn btn-primary">
          Book Nutritionist Consultation
        </Link>
      </div>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : plans.length === 0 ? (
        <div className="alert alert-light border">
          No nutrition plans yet - book a consultation with a Nutritionist to get one.
        </div>
      ) : (
        plans.map((plan) => (
          <div key={plan.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <h6>From {plan.nutritionistName}</h6>
                <small className="text-muted">{new Date(plan.createdAt).toLocaleDateString()}</small>
              </div>
              <p className="mb-0" style={{ whiteSpace: 'pre-wrap' }}>{plan.planDetails}</p>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
