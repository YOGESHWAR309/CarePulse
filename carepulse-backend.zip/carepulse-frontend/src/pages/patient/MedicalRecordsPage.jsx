import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyMedicalRecords } from '../../api/hospitalApi';

export default function MedicalRecordsPage() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyMedicalRecords()
      .then((res) => setRecords(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load medical records'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Medical Records</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : records.length === 0 ? (
        <div className="alert alert-light border">No medical records yet.</div>
      ) : (
        records.map((record) => (
          <div key={record.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <h6>Dr. {record.doctorName}</h6>
                <small className="text-muted">{new Date(record.createdAt).toLocaleDateString()}</small>
              </div>
              {record.symptoms && <p className="mb-1"><strong>Symptoms:</strong> {record.symptoms}</p>}
              <p className="mb-1"><strong>Diagnosis:</strong> {record.diagnosis}</p>
              {record.consultationNotes && <p className="mb-0"><strong>Notes:</strong> {record.consultationNotes}</p>}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
