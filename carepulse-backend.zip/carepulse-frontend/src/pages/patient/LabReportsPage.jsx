import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getMyLabTests, getLabReportFile } from '../../api/hospitalApi';

const STATUS_BADGE = { REQUESTED: 'secondary', SAMPLE_COLLECTED: 'info', IN_PROGRESS: 'warning', READY: 'success', CANCELLED: 'dark' };

export default function LabReportsPage() {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [downloadingId, setDownloadingId] = useState(null);

  useEffect(() => {
    getMyLabTests()
      .then((res) => setTests(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load lab reports'))
      .finally(() => setLoading(false));
  }, []);

  const handleViewReport = async (test) => {
    setError('');
    setDownloadingId(test.id);
    try {
      const blob = await getLabReportFile(test.id);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (err) {
      setError('Unable to open the report file');
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Lab Reports</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : tests.length === 0 ? (
        <div className="alert alert-light border">No lab tests on record.</div>
      ) : (
        tests.map((test) => (
          <div key={test.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start">
                <h6>{test.testName}</h6>
                <span className={`badge bg-${STATUS_BADGE[test.status] || 'secondary'}`}>{test.status}</span>
              </div>
              <small className="text-muted d-block mb-2">
                Ordered by Dr. {test.requestingDoctorName} · Pathologist: {test.assignedPathologistName}
              </small>

              {test.status === 'READY' && (
                <>
                  {test.resultSummary && <p className="mb-1"><strong>Summary:</strong> {test.resultSummary}</p>}
                  {test.reportAvailable && (
                    <button
                      className="btn btn-sm btn-outline-primary"
                      disabled={downloadingId === test.id}
                      onClick={() => handleViewReport(test)}
                    >
                      {downloadingId === test.id ? 'Opening...' : 'View Full Report'}
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
