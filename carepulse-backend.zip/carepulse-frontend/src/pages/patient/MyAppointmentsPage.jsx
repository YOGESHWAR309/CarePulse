import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getMyAppointments, cancelAppointment } from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';
import { formatTime12h } from '../../utils/formatters';

const STATUS_BADGE = {
  BOOKED: 'primary',
  RESCHEDULED: 'info',
  CHECKED_IN: 'warning',
  IN_CONSULTATION: 'warning',
  COMPLETED: 'success',
  CANCELLED: 'secondary',
  NO_SHOW: 'dark',
};

const CANCELLABLE_STATUSES = ['BOOKED', 'RESCHEDULED'];

export default function MyAppointmentsPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState(location.state?.message || '');

  const [cancellingId, setCancellingId] = useState(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelReasonError, setCancelReasonError] = useState('');
  const [cancelSubmitting, setCancelSubmitting] = useState(false);

  useEffect(() => {
    loadAppointments();
  }, []);

  const loadAppointments = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getMyAppointments();
      setAppointments(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load your appointments');
    } finally {
      setLoading(false);
    }
  };

  const openCancelModal = (appointmentId) => {
    setCancellingId(appointmentId);
    setCancelReason('');
    setCancelReasonError('');
  };

  const handleCancelReasonChange = (event) => {
    setCancelReason(event.target.value);
    if (cancelReasonError) setCancelReasonError('');
  };

  const handleConfirmCancel = async () => {
    const validationErrors = runValidators(
      { reason: cancelReason },
      {
        reason: (v) => validateRequired(v, 'Cancellation reason') || validateMaxLength(v, 'Cancellation reason', 500),
      }
    );
    setCancelReasonError(validationErrors.reason || '');
    if (hasErrors(validationErrors)) return;

    setCancelSubmitting(true);
    setError('');
    try {
      await cancelAppointment(cancellingId, { reason: cancelReason });
      setSuccessMessage('Appointment cancelled successfully');
      setCancellingId(null);
      loadAppointments();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to cancel this appointment');
    } finally {
      setCancelSubmitting(false);
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">My Appointments</h2>
        <button className="btn btn-primary" onClick={() => navigate('/patient/book-appointment')}>
          + Book New Appointment
        </button>
      </div>

      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : appointments.length === 0 ? (
        <div className="alert alert-light border text-center">
          You have no appointments yet.{' '}
          <button className="btn btn-link p-0" onClick={() => navigate('/patient/book-appointment')}>
            Book your first one
          </button>
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead>
              <tr>
                <th>Doctor</th>
                <th>Department</th>
                <th>Date</th>
                <th>Time</th>
                <th>Mode</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appt) => (
                <tr key={appt.id}>
                  <td>{appt.doctorName}</td>
                  <td>{appt.departmentName}</td>
                  <td>{appt.appointmentDate}</td>
                  <td>{formatTime12h(appt.startTime)}</td>
                  <td>{appt.consultationMode}</td>
                  <td>
                    <span className={`badge bg-${STATUS_BADGE[appt.status] || 'secondary'}`}>{appt.status}</span>
                  </td>
                  <td>
                    {CANCELLABLE_STATUSES.includes(appt.status) && (
                      <button className="btn btn-sm btn-outline-danger" onClick={() => openCancelModal(appt.id)}>
                        Cancel
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {cancellingId && (
        <div className="modal d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} role="dialog">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Cancel Appointment</h5>
                <button type="button" className="btn-close" onClick={() => setCancellingId(null)} />
              </div>
              <div className="modal-body">
                <InputField
                  label="Reason for cancellation" name="cancelReason" as="textarea" required
                  value={cancelReason} onChange={handleCancelReasonChange}
                  error={cancelReasonError}
                />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setCancellingId(null)} disabled={cancelSubmitting}>
                  Keep Appointment
                </button>
                <button className="btn btn-danger" onClick={handleConfirmCancel} disabled={cancelSubmitting}>
                  {cancelSubmitting ? 'Cancelling...' : 'Confirm Cancellation'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
