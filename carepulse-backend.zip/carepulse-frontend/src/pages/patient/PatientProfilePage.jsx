import React, { useEffect, useState } from 'react';
import InputField from '../../components/common/InputField';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import { getMyPatientProfile, updateMyPatientProfile } from '../../api/hospitalApi';
import { validateMaxLength, runValidators, hasErrors, PATTERNS } from '../../utils/validators';

const initialValues = {
  dateOfBirth: '',
  gender: '',
  bloodGroup: '',
  address: '',
  emergencyContactName: '',
  emergencyContactPhone: '',
};

/** Fills in the extended clinical fields Auth Service's registration form never collected - PUT /api/hospital/patients/me. */
export default function PatientProfilePage() {
  const [profile, setProfile] = useState(null);
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getMyPatientProfile();
      setProfile(res.data);
      setValues({
        dateOfBirth: res.data.dateOfBirth || '',
        gender: res.data.gender || '',
        bloodGroup: res.data.bloodGroup || '',
        address: res.data.address || '',
        emergencyContactName: res.data.emergencyContactName || '',
        emergencyContactPhone: res.data.emergencyContactPhone || '',
      });
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load your profile');
    } finally {
      setLoading(false);
    }
  };

  const validatorMap = {
    bloodGroup: (v) => validateMaxLength(v, 'Blood group', 10),
    address: (v) => validateMaxLength(v, 'Address', 500),
    emergencyContactName: (v) => validateMaxLength(v, 'Emergency contact name', 100),
    emergencyContactPhone: (v) => {
      if (!v) return '';
      return PATTERNS.PHONE.test(v) ? '' : 'Enter a valid 10-15 digit phone number';
    },
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({
      bloodGroup: true, address: true, emergencyContactName: true, emergencyContactPhone: true,
    });
    if (hasErrors(validationErrors)) return;

    setSaving(true);
    try {
      const res = await updateMyPatientProfile({
        ...values,
        dateOfBirth: values.dateOfBirth || null,
        gender: values.gender || null,
      });
      setProfile(res.data);
      setSuccessMessage('Profile updated successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update your profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="container mt-4" style={{ maxWidth: 700 }}>
      <h2 className="mb-4">My Profile</h2>

      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h6 className="text-muted">Account Information</h6>
          <p className="mb-1"><strong>Name:</strong> {profile?.fullName}</p>
          <p className="mb-1"><strong>Email:</strong> {profile?.email}</p>
          <p className="mb-0"><strong>Phone:</strong> {profile?.phoneNumber}</p>
          <div className="form-text mt-2">
            Name, email, and phone are managed in Account Settings, not here.
          </div>
        </div>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <h6 className="text-muted mb-3">Clinical Details</h6>
          <form onSubmit={handleSubmit} noValidate>
            <div className="row">
              <div className="col-md-6">
                <InputField
                  label="Date of Birth" name="dateOfBirth" type="date"
                  value={values.dateOfBirth} onChange={handleChange} onBlur={handleBlur}
                  error={touched.dateOfBirth && errors.dateOfBirth}
                />
              </div>
              <div className="col-md-6">
                <InputField
                  label="Gender" name="gender" as="select"
                  value={values.gender} onChange={handleChange} onBlur={handleBlur}
                  error={touched.gender && errors.gender}
                >
                  <option value="">Select...</option>
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </InputField>
              </div>
            </div>

            <InputField
              label="Blood Group" name="bloodGroup" placeholder="e.g. O+"
              value={values.bloodGroup} onChange={handleChange} onBlur={handleBlur}
              error={touched.bloodGroup && errors.bloodGroup}
            />

            <InputField
              label="Address" name="address" as="textarea"
              value={values.address} onChange={handleChange} onBlur={handleBlur}
              error={touched.address && errors.address}
            />

            <div className="row">
              <div className="col-md-6">
                <InputField
                  label="Emergency Contact Name" name="emergencyContactName"
                  value={values.emergencyContactName} onChange={handleChange} onBlur={handleBlur}
                  error={touched.emergencyContactName && errors.emergencyContactName}
                />
              </div>
              <div className="col-md-6">
                <InputField
                  label="Emergency Contact Phone" name="emergencyContactPhone" type="tel"
                  value={values.emergencyContactPhone} onChange={handleChange} onBlur={handleBlur}
                  error={touched.emergencyContactPhone && errors.emergencyContactPhone}
                />
              </div>
            </div>

            <SubmitButton loading={saving}>Save Changes</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
