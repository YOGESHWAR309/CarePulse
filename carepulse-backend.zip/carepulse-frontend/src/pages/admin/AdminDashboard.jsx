import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const QUICK_LINKS = [
  { to: '/admin/departments', label: 'Departments', icon: '🏥', desc: 'Create and manage hospital departments' },
  { to: '/admin/create-staff', label: 'Create Staff', icon: '➕', desc: 'Add a Doctor, Receptionist, Pharmacist, etc.' },
  { to: '/admin/doctors', label: 'Manage Doctors', icon: '👨‍⚕️', desc: 'Assign department, fee, specialization' },
  { to: '/admin/staff', label: 'Manage Staff Accounts', icon: '🧑‍💼', desc: 'Activate/deactivate, reset password' },
  { to: '/admin/staff-profiles', label: 'Staff Qualifications', icon: '🎓', desc: 'Qualification and department assignment' },
  { to: '/admin/patients', label: 'All Patients', icon: '🧑‍🤝‍🧑', desc: 'View every registered patient' },
  { to: '/admin/billing', label: 'Billing & Revenue', icon: '💰', desc: 'Reports and revenue dashboard' },
];

export default function AdminDashboard() {
  const { user } = useAuth();
  return (
    <div className="container mt-4">
      <h2 className="mb-1">Welcome, {user?.firstName}!</h2>
      <p className="text-muted mb-4">Hospital administration at a glance.</p>

      <div className="row g-3">
        {QUICK_LINKS.map((link) => (
          <div key={link.to} className="col-md-4 col-sm-6">
            <Link to={link.to} className="text-decoration-none">
              <div className="card h-100 shadow-sm">
                <div className="card-body">
                  <div style={{ fontSize: '2rem' }}>{link.icon}</div>
                  <h6 className="mt-2 mb-1 text-dark">{link.label}</h6>
                  <p className="small text-muted mb-0">{link.desc}</p>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
