import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getAllStaff, activateUser, deactivateUser } from '../../api/authApi';

export default function StaffListPage() {
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [actioningId, setActioningId] = useState(null);

  useEffect(() => {
    loadStaff();
  }, []);

  const loadStaff = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAllStaff();
      setStaff(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load staff');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActive = async (member) => {
    setActioningId(member.id);
    setError('');
    setSuccessMessage('');
    try {
      if (member.accountLocked) {
        await activateUser(member.id);
        setSuccessMessage(`${member.firstName} ${member.lastName}'s account activated`);
      } else {
        await deactivateUser(member.id);
        setSuccessMessage(`${member.firstName} ${member.lastName}'s account deactivated`);
      }
      loadStaff();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update account status');
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">All Staff</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : (
        <div className="table-responsive">
          <table className="table table-hover bg-white align-middle">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {staff.map((member) => (
                <tr key={member.id}>
                  <td>{member.firstName} {member.lastName}</td>
                  <td>{member.email}</td>
                  <td><span className="badge bg-info text-dark">{member.role}</span></td>
                  <td>
                    <span className={`badge bg-${member.accountLocked ? 'secondary' : 'success'}`}>
                      {member.accountLocked ? 'Deactivated' : 'Active'}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-sm btn-outline-secondary"
                      disabled={actioningId === member.id}
                      onClick={() => handleToggleActive(member)}
                    >
                      {member.accountLocked ? 'Activate' : 'Deactivate'}
                    </button>
                  </td>
                </tr>
              ))}
              {staff.length === 0 && (
                <tr><td colSpan={5} className="text-center text-muted">No staff created yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
