import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getAllPatientsHospital } from '../../api/hospitalApi';

export default function PatientListPage() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getAllPatientsHospital()
      .then((res) => setPatients(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load patients'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">All Patients</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : (
        <div className="table-responsive">
          <table className="table table-hover bg-white align-middle">
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Type</th></tr></thead>
            <tbody>
              {patients.map((patient) => (
                <tr key={patient.id}>
                  <td>{patient.fullName}</td>
                  <td>{patient.email || '-'}</td>
                  <td>{patient.phoneNumber}</td>
                  <td>
                    <span className={`badge bg-${patient.walkIn ? 'warning' : 'primary'}`}>
                      {patient.walkIn ? 'Walk-in' : 'Self-registered'}
                    </span>
                  </td>
                </tr>
              ))}
              {patients.length === 0 && <tr><td colSpan={4} className="text-center text-muted">No patients yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
