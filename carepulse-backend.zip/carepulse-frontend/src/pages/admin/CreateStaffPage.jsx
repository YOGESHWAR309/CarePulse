import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { createStaff } from '../../api/authApi';
import {
  validateName, validateEmail, validatePhone, validateMaxLength, runValidators, hasErrors,
} from '../../utils/validators';
import { STAFF_ROLES } from '../../utils/constants';

const initialValues = {
  firstName: '', lastName: '', email: '', phoneNumber: '', role: 'DOCTOR', qualification: '', specialization: '',
};

/**
 * POST /api/auth/admin/staff. Qualification is captured for every role;
 * specialization only makes sense for DOCTOR (department assignment
 * still happens as a separate follow-up step in Hospital Service, since
 * Auth Service has no knowledge of departments).
 */
export default function CreateStaffPage() {
  const navigate = useNavigate();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    firstName: (v) => validateName(v, 'First name', 100),
    lastName: (v) => validateName(v, 'Last name', 100),
    email: validateEmail,
    phoneNumber: validatePhone,
    qualification: (v) => validateMaxLength(v, 'Qualification', 200),
    specialization: (v) => validateMaxLength(v, 'Specialization', 150),
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');
    setSuccessMessage('');

    const fieldsToValidate = { ...values };
    if (values.role !== 'DOCTOR') delete fieldsToValidate.specialization;

    const validationErrors = runValidators(fieldsToValidate, validatorMap);
    setErrors(validationErrors);
    setTouched({
      firstName: true, lastName: true, email: true, phoneNumber: true, qualification: true, specialization: true,
    });
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      const payload = { ...values };
      if (values.role !== 'DOCTOR') delete payload.specialization;

      const res = await createStaff(payload);
      setSuccessMessage(`${values.role} account created for ${res.data.firstName} ${res.data.lastName}. Login credentials have been emailed.`);
      setValues(initialValues);
      setTouched({});

      if (values.role === 'DOCTOR') {
        setTimeout(() => navigate('/admin/doctors'), 1500);
      }
    } catch (err) {
      setServerError(err.response?.data?.message || 'Unable to create staff account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 600 }}>
      <h2 className="mb-4">Create Staff Account</h2>
      <Alert message={serverError} onClose={() => setServerError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      <div className="card shadow-sm">
        <div className="card-body">
          <form onSubmit={handleSubmit} noValidate>
            <InputField
              label="Role" name="role" as="select" required
              value={values.role} onChange={handleChange}
            >
              {STAFF_ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </InputField>

            <div className="row">
              <div className="col-6">
                <InputField label="First Name" name="firstName" required
                  value={values.firstName} onChange={handleChange} onBlur={handleBlur}
                  error={touched.firstName && errors.firstName} />
              </div>
              <div className="col-6">
                <InputField label="Last Name" name="lastName" required
                  value={values.lastName} onChange={handleChange} onBlur={handleBlur}
                  error={touched.lastName && errors.lastName} />
              </div>
            </div>

            <InputField label="Email" name="email" type="email" required
              value={values.email} onChange={handleChange} onBlur={handleBlur}
              error={touched.email && errors.email} />

            <InputField label="Phone Number" name="phoneNumber" type="tel" required
              value={values.phoneNumber} onChange={handleChange} onBlur={handleBlur}
              error={touched.phoneNumber && errors.phoneNumber} />

            <InputField label="Qualification / Education (optional)" name="qualification"
              placeholder='e.g. "MBBS, MD" or "B.Pharm"'
              value={values.qualification} onChange={handleChange} onBlur={handleBlur}
              error={touched.qualification && errors.qualification} />

            {values.role === 'DOCTOR' && (
              <InputField label="Specialization (optional)" name="specialization"
                placeholder="e.g. Cardiology"
                value={values.specialization} onChange={handleChange} onBlur={handleBlur}
                error={touched.specialization && errors.specialization} />
            )}

            {values.role === 'DOCTOR' && (
              <div className="form-text mb-3">
                Department, consultation fee, and years of experience are set in a follow-up step under "Manage Doctors" once this account is created.
              </div>
            )}

            <SubmitButton loading={loading}>Create Staff Account</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
