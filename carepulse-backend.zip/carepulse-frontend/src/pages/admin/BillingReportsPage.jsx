import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getAllBills } from '../../api/hospitalApi';

const STATUS_BADGE = { PENDING: 'warning', PAID: 'success', FAILED: 'danger', REFUNDED: 'secondary' };

export default function BillingReportsPage() {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getAllBills()
      .then((res) => setBills(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load bills'))
      .finally(() => setLoading(false));
  }, []);

  const totalRevenue = bills.filter((b) => b.status === 'PAID').reduce((sum, b) => sum + Number(b.amount), 0);
  const pendingAmount = bills.filter((b) => b.status === 'PENDING').reduce((sum, b) => sum + Number(b.amount), 0);

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Billing Reports & Revenue</h2>
      <Alert message={error} onClose={() => setError('')} />

      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="row mb-4">
            <div className="col-md-4">
              <div className="card shadow-sm bg-success text-white">
                <div className="card-body">
                  <h6>Total Revenue Collected</h6>
                  <h3>₹{totalRevenue.toFixed(2)}</h3>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card shadow-sm bg-warning">
                <div className="card-body">
                  <h6>Pending Payments</h6>
                  <h3>₹{pendingAmount.toFixed(2)}</h3>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card shadow-sm bg-light border">
                <div className="card-body">
                  <h6>Total Bills</h6>
                  <h3>{bills.length}</h3>
                </div>
              </div>
            </div>
          </div>

          <div className="table-responsive">
            <table className="table table-hover bg-white align-middle">
              <thead><tr><th>Invoice #</th><th>Patient</th><th>Amount</th><th>Status</th><th>Paid Via</th><th>Date</th></tr></thead>
              <tbody>
                {bills.map((bill) => (
                  <tr key={bill.id}>
                    <td>{bill.invoiceNumber}</td>
                    <td>{bill.patientName}</td>
                    <td>₹{bill.amount}</td>
                    <td><span className={`badge bg-${STATUS_BADGE[bill.status] || 'secondary'}`}>{bill.status}</span></td>
                    <td>{bill.paymentMethod || '-'}</td>
                    <td>{new Date(bill.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
                {bills.length === 0 && <tr><td colSpan={6} className="text-center text-muted">No bills yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
