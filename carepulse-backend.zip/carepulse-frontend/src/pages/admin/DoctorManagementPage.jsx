import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getAllDoctorsHospital, updateDoctorProfile, getAllDepartments } from '../../api/hospitalApi';
import { getAllDoctors, activateUser, deactivateUser } from '../../api/authApi';
import { validateRequired, validateMaxLength, validateMinNumber, runValidators, hasErrors } from '../../utils/validators';

const initialValues = { departmentId: '', specialization: '', qualification: '', experienceYears: '', consultationFee: '' };

export default function DoctorManagementPage() {
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [editingId, setEditingId] = useState(null);
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [actioningId, setActioningId] = useState(null);

  const validatorMap = {
    departmentId: (v) => validateRequired(v, 'Department'),
    specialization: (v) => validateMaxLength(v, 'Specialization', 150),
    qualification: (v) => validateMaxLength(v, 'Qualification', 200),
    experienceYears: (v) => (v === '' ? '' : validateMinNumber(v, 'Experience (years)', 0)),
    consultationFee: (v) => (v === '' ? '' : validateMinNumber(v, 'Consultation fee', 0)),
  };

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const [doctorsRes, deptRes] = await Promise.all([getAllDoctorsHospital(), getAllDepartments()]);

      // Account status (Active/Deactivated) lives in auth-service, a separate call from
      // the clinical doctor list above. Fetched best-effort and merged in by email (the
      // one guaranteed-unique key shared between the two services here): if auth-service
      // is unreachable, the doctor list/edit flow still works fine - only the Status
      // column and Activate/Deactivate button fall back to hidden for that row, instead
      // of the whole page failing.
      let accountsByEmail = new Map();
      try {
        const accountsRes = await getAllDoctors();
        accountsByEmail = new Map(accountsRes.data.map((acc) => [acc.email, acc]));
      } catch (accountErr) {
        console.warn('Unable to load doctor account status (auth-service unreachable?)', accountErr);
      }

      setDoctors(doctorsRes.data.map((doctor) => ({ ...doctor, account: accountsByEmail.get(doctor.email) || null })));
      setDepartments(deptRes.data.filter((d) => d.active));
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load doctors');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (doctor) => {
    setEditingId(doctor.id);
    setValues({
      departmentId: doctor.departmentId || '',
      specialization: doctor.specialization || '',
      qualification: doctor.qualification || '',
      experienceYears: doctor.experienceYears ?? '',
      consultationFee: doctor.consultationFee ?? '',
    });
    setErrors({});
  };

  const cancelEdit = () => {
    setEditingId(null);
    setValues(initialValues);
    setErrors({});
  };

  const handleToggleActive = async (doctor) => {
    if (!doctor.account) return;
    setActioningId(doctor.id);
    setError('');
    setSuccessMessage('');
    try {
      if (doctor.account.accountLocked) {
        await activateUser(doctor.account.id);
        setSuccessMessage(`${doctor.fullName}'s account activated`);
      } else {
        await deactivateUser(doctor.account.id);
        setSuccessMessage(`${doctor.fullName}'s account deactivated`);
      }
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update account status');
    } finally {
      setActioningId(null);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    try {
      await updateDoctorProfile(editingId, {
        departmentId: Number(values.departmentId),
        specialization: values.specialization || undefined,
        qualification: values.qualification || undefined,
        experienceYears: values.experienceYears === '' ? undefined : Number(values.experienceYears),
        consultationFee: values.consultationFee === '' ? undefined : Number(values.consultationFee),
      });
      setSuccessMessage('Doctor profile updated successfully');
      cancelEdit();
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update doctor profile');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Manage Doctors</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : (
        <div className="table-responsive mb-4">
          <table className="table table-hover bg-white align-middle">
            <thead><tr><th>Name</th><th>Department</th><th>Specialization</th><th>Fee</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {doctors.map((doctor) => (
                <tr key={doctor.id}>
                  <td>{doctor.fullName}</td>
                  <td>{doctor.departmentName || <span className="text-danger small">Not assigned</span>}</td>
                  <td>{doctor.specialization || '-'}</td>
                  <td>{doctor.consultationFee != null ? `₹${doctor.consultationFee}` : '-'}</td>
                  <td>
                    {doctor.account ? (
                      <span className={`badge bg-${doctor.account.accountLocked ? 'secondary' : 'success'}`}>
                        {doctor.account.accountLocked ? 'Deactivated' : 'Active'}
                      </span>
                    ) : (
                      <span className="text-muted small">-</span>
                    )}
                  </td>
                  <td className="d-flex gap-1">
                    <button className="btn btn-sm btn-outline-primary" onClick={() => startEdit(doctor)}>Edit</button>
                    {doctor.account && (
                      <button
                        className="btn btn-sm btn-outline-secondary"
                        disabled={actioningId === doctor.id}
                        onClick={() => handleToggleActive(doctor)}
                      >
                        {doctor.account.accountLocked ? 'Activate' : 'Deactivate'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {doctors.length === 0 && <tr><td colSpan={6} className="text-center text-muted">No doctors yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {editingId && (
        <div className="card shadow-sm">
          <div className="card-body">
            <h5 className="mb-3">Edit Doctor Profile</h5>
            <form onSubmit={handleSubmit} noValidate>
              <InputField
                label="Department" name="departmentId" as="select" required
                value={values.departmentId} onChange={handleChange} error={errors.departmentId}
              >
                <option value="">Select department...</option>
                {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </InputField>

              <InputField
                label="Specialization" name="specialization"
                value={values.specialization} onChange={handleChange} error={errors.specialization}
              />
              <InputField
                label="Qualification" name="qualification"
                value={values.qualification} onChange={handleChange} error={errors.qualification}
              />

              <div className="row">
                <div className="col-6">
                  <InputField
                    label="Experience (years)" name="experienceYears" type="number"
                    value={values.experienceYears} onChange={handleChange} error={errors.experienceYears}
                  />
                </div>
                <div className="col-6">
                  <InputField
                    label="Consultation Fee (₹)" name="consultationFee" type="number"
                    value={values.consultationFee} onChange={handleChange} error={errors.consultationFee}
                  />
                </div>
              </div>

              <div className="d-flex gap-2">
                <div className="flex-fill">
                  <SubmitButton loading={submitting}>Save Changes</SubmitButton>
                </div>
                <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit} disabled={submitting}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
