import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getAllDepartments, createDepartment, updateDepartment, deactivateDepartment } from '../../api/hospitalApi';
import { validateName, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const initialValues = { name: '', description: '' };

export default function DepartmentManagementPage() {
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [editingId, setEditingId] = useState(null); // null = create mode, else editing this department's id
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const validatorMap = {
    name: (v) => validateName(v, 'Department name', 100),
    description: (v) => validateMaxLength(v, 'Description', 500),
  };

  useEffect(() => {
    loadDepartments();
  }, []);

  const loadDepartments = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAllDepartments();
      setDepartments(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load departments');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const startEdit = (dept) => {
    setEditingId(dept.id);
    setValues({ name: dept.name, description: dept.description || '' });
    setErrors({});
  };

  const cancelEdit = () => {
    setEditingId(null);
    setValues(initialValues);
    setErrors({});
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    try {
      if (editingId) {
        const current = departments.find((d) => d.id === editingId);
        await updateDepartment(editingId, { ...values, active: current?.active ?? true });
        setSuccessMessage('Department updated successfully');
      } else {
        await createDepartment(values);
        setSuccessMessage('Department created successfully');
      }
      cancelEdit();
      loadDepartments();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to save department');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (dept) => {
    setError('');
    try {
      if (dept.active) {
        await deactivateDepartment(dept.id);
      } else {
        await updateDepartment(dept.id, { name: dept.name, description: dept.description, active: true });
      }
      loadDepartments();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update department status');
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Department Management</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h5 className="mb-3">{editingId ? 'Edit Department' : 'Create Department'}</h5>
          <form onSubmit={handleSubmit} noValidate>
            <InputField
              label="Name" name="name" required
              value={values.name} onChange={handleChange} error={errors.name}
            />
            <InputField
              label="Description" name="description" as="textarea"
              value={values.description} onChange={handleChange} error={errors.description}
            />
            <div className="d-flex gap-2">
              <div className="flex-fill">
                <SubmitButton loading={submitting}>{editingId ? 'Save Changes' : 'Create Department'}</SubmitButton>
              </div>
              {editingId && (
                <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit} disabled={submitting}>
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      <h5 className="mb-3">All Departments</h5>
      {loading ? (
        <Loader />
      ) : (
        <div className="table-responsive">
          <table className="table table-hover bg-white align-middle">
            <thead><tr><th>Name</th><th>Description</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {departments.map((dept) => (
                <tr key={dept.id}>
                  <td>{dept.name}</td>
                  <td className="small">{dept.description || '-'}</td>
                  <td><span className={`badge bg-${dept.active ? 'success' : 'secondary'}`}>{dept.active ? 'Active' : 'Inactive'}</span></td>
                  <td className="d-flex gap-1">
                    <button className="btn btn-sm btn-outline-primary" onClick={() => startEdit(dept)}>Edit</button>
                    <button className="btn btn-sm btn-outline-secondary" onClick={() => handleToggleActive(dept)}>
                      {dept.active ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
