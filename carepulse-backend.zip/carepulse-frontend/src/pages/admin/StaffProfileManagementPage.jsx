import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getStaffProfiles, updateStaffProfile, getAllDepartments } from '../../api/hospitalApi';
import { validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const initialValues = { qualification: '', departmentId: '' };

/** Manages Receptionist/Pharmacist/Pathologist/Radiologist/Dietician/Nutritionist clinical profiles - the non-Doctor counterpart to DoctorManagementPage. */
export default function StaffProfileManagementPage() {
  const [profiles, setProfiles] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [editingId, setEditingId] = useState(null);
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const validatorMap = {
    qualification: (v) => validateMaxLength(v, 'Qualification', 200),
  };

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const [profilesRes, deptRes] = await Promise.all([getStaffProfiles(), getAllDepartments()]);
      setProfiles(profilesRes.data);
      setDepartments(deptRes.data.filter((d) => d.active));
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load staff profiles');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (profile) => {
    setEditingId(profile.staffProfileId);
    setValues({ qualification: profile.qualification || '', departmentId: profile.departmentId || '' });
    setErrors({});
  };

  const cancelEdit = () => {
    setEditingId(null);
    setValues(initialValues);
    setErrors({});
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSuccessMessage('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    try {
      await updateStaffProfile(editingId, {
        qualification: values.qualification || undefined,
        departmentId: values.departmentId ? Number(values.departmentId) : null,
      });
      setSuccessMessage('Staff profile updated successfully');
      cancelEdit();
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to update staff profile');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Manage Staff Profiles</h2>
      <p className="text-muted">Receptionists, Pharmacists, Pathologists, Radiologists, Dieticians, and Nutritionists.</p>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : (
        <div className="table-responsive mb-4">
          <table className="table table-hover bg-white align-middle">
            <thead><tr><th>Name</th><th>Role</th><th>Qualification</th><th>Department</th><th></th></tr></thead>
            <tbody>
              {profiles.map((profile) => (
                <tr key={profile.staffProfileId}>
                  <td>{profile.fullName}</td>
                  <td><span className="badge bg-info text-dark">{profile.role}</span></td>
                  <td>{profile.qualification || '-'}</td>
                  <td>{profile.departmentName || '-'}</td>
                  <td>
                    <button className="btn btn-sm btn-outline-primary" onClick={() => startEdit(profile)}>Edit</button>
                  </td>
                </tr>
              ))}
              {profiles.length === 0 && <tr><td colSpan={5} className="text-center text-muted">No staff yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {editingId && (
        <div className="card shadow-sm">
          <div className="card-body">
            <h5 className="mb-3">Edit Staff Profile</h5>
            <form onSubmit={handleSubmit} noValidate>
              <InputField
                label="Qualification" name="qualification"
                value={values.qualification} onChange={handleChange} error={errors.qualification}
              />
              <InputField
                label="Department (optional)" name="departmentId" as="select"
                value={values.departmentId} onChange={handleChange}
              >
                <option value="">No department assignment</option>
                {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </InputField>

              <div className="d-flex gap-2">
                <div className="flex-fill">
                  <SubmitButton loading={submitting}>Save Changes</SubmitButton>
                </div>
                <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit} disabled={submitting}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
