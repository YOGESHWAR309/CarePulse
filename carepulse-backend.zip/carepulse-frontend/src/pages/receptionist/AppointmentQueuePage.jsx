import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Alert, Loader } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  getAppointmentQueue, receptionistCheckIn, receptionistCheckOut, receptionistCancelAppointment, generateBill,
} from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, validatePositiveAmount, runValidators, hasErrors } from '../../utils/validators';

const STATUS_BADGE = {
  BOOKED: 'primary', RESCHEDULED: 'info', CHECKED_IN: 'warning',
  IN_CONSULTATION: 'warning', COMPLETED: 'success', CANCELLED: 'secondary', NO_SHOW: 'dark',
};

function todayIso() {
  return new Date().toISOString().split('T')[0];
}

/** [Receptionist] "Manage Appointment Queue" - every appointment for a given day, across all doctors, with check-in/out and cancel. */
export default function AppointmentQueuePage() {
  const location = useLocation();
  const navigate = useNavigate();

  const [date, setDate] = useState(todayIso());
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState(location.state?.message || '');
  const [actioningId, setActioningId] = useState(null);

  const [cancellingId, setCancellingId] = useState(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelReasonError, setCancelReasonError] = useState('');

  const [billingAppointmentId, setBillingAppointmentId] = useState(null);
  const [billAmount, setBillAmount] = useState('');
  const [billAmountError, setBillAmountError] = useState('');
  const [billedAppointmentIds, setBilledAppointmentIds] = useState(new Set());

  useEffect(() => {
    loadQueue();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const loadQueue = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAppointmentQueue(date);
      setQueue(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load the appointment queue');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async (appointmentId) => {
    setActioningId(appointmentId);
    setError('');
    try {
      await receptionistCheckIn(appointmentId);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to check in this patient');
    } finally {
      setActioningId(null);
    }
  };

  const handleCheckOut = async (appointmentId) => {
    setActioningId(appointmentId);
    setError('');
    try {
      await receptionistCheckOut(appointmentId);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to check out this patient');
    } finally {
      setActioningId(null);
    }
  };

  const handleConfirmCancel = async () => {
    const validationErrors = runValidators(
      { reason: cancelReason },
      { reason: (v) => validateRequired(v, 'Cancellation reason') || validateMaxLength(v, 'Cancellation reason', 500) }
    );
    setCancelReasonError(validationErrors.reason || '');
    if (hasErrors(validationErrors)) return;

    setActioningId(cancellingId);
    setError('');
    try {
      await receptionistCancelAppointment(cancellingId, { reason: cancelReason });
      setSuccessMessage('Appointment cancelled');
      setCancellingId(null);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to cancel this appointment');
    } finally {
      setActioningId(null);
    }
  };

  const handleConfirmGenerateBill = async () => {
    const validationErrors = runValidators(
      { amount: billAmount },
      { amount: (v) => validateRequired(v, 'Amount') || validatePositiveAmount(v, 'Amount') }
    );
    setBillAmountError(validationErrors.amount || '');
    if (hasErrors(validationErrors)) return;

    setActioningId(billingAppointmentId);
    setError('');
    try {
      await generateBill({ appointmentId: billingAppointmentId, amount: billAmount });
      setBilledAppointmentIds((prev) => new Set(prev).add(billingAppointmentId));
      setSuccessMessage('Bill generated - the patient can now pay it from their Bills page.');
      setBillingAppointmentId(null);
    } catch (err) {
      // A bill may already exist for this appointment (e.g. generated earlier, or by
      // someone else) - the backend rejects that as a duplicate. Either way, hide the
      // button going forward so it can't be attempted again for this appointment.
      setBilledAppointmentIds((prev) => new Set(prev).add(billingAppointmentId));
      setError(err.response?.data?.message || 'Unable to generate bill for this appointment');
      setBillingAppointmentId(null);
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">Appointment Queue</h2>
        <button className="btn btn-primary" onClick={() => navigate('/receptionist/book-appointment')}>
          + Book Appointment
        </button>
      </div>

      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      <div style={{ maxWidth: 250 }}>
        <InputField label="Date" name="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </div>

      {loading ? (
        <Loader />
      ) : queue.length === 0 ? (
        <div className="alert alert-light border">No appointments for this date.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead>
              <tr><th>Time</th><th>Patient</th><th>Doctor</th><th>Department</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {queue.map((appt) => (
                <tr key={appt.id}>
                  <td>{appt.startTime}</td>
                  <td>{appt.patientName}</td>
                  <td>{appt.doctorName}</td>
                  <td>{appt.departmentName}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[appt.status] || 'secondary'}`}>{appt.status}</span></td>
                  <td className="d-flex gap-1">
                    {['BOOKED', 'RESCHEDULED'].includes(appt.status) && (
                      <button className="btn btn-sm btn-outline-warning" disabled={actioningId === appt.id} onClick={() => handleCheckIn(appt.id)}>
                        Check In
                      </button>
                    )}
                    {appt.status === 'CHECKED_IN' && (
                      <button className="btn btn-sm btn-outline-success" disabled={actioningId === appt.id} onClick={() => handleCheckOut(appt.id)}>
                        Check Out
                      </button>
                    )}
                    {['BOOKED', 'RESCHEDULED', 'CHECKED_IN'].includes(appt.status) && (
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => { setCancellingId(appt.id); setCancelReason(''); setCancelReasonError(''); }}
                      >
                        Cancel
                      </button>
                    )}
                    {appt.status === 'COMPLETED' && !billedAppointmentIds.has(appt.id) && (
                      <button
                        className="btn btn-sm btn-outline-primary"
                        disabled={actioningId === appt.id}
                        onClick={() => { setBillingAppointmentId(appt.id); setBillAmount(''); setBillAmountError(''); }}
                      >
                        Generate Bill
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {cancellingId && (
        <div className="modal d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} role="dialog">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Cancel Appointment</h5>
                <button type="button" className="btn-close" onClick={() => setCancellingId(null)} />
              </div>
              <div className="modal-body">
                <InputField
                  label="Reason for cancellation" name="cancelReason" as="textarea" required
                  value={cancelReason} onChange={(e) => { setCancelReason(e.target.value); setCancelReasonError(''); }}
                  error={cancelReasonError}
                />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setCancellingId(null)}>Keep Appointment</button>
                <button className="btn btn-danger" onClick={handleConfirmCancel} disabled={actioningId === cancellingId}>
                  {actioningId === cancellingId ? 'Cancelling...' : 'Confirm Cancellation'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {billingAppointmentId && (
        <div className="modal d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} role="dialog">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Generate Bill</h5>
                <button type="button" className="btn-close" onClick={() => setBillingAppointmentId(null)} />
              </div>
              <div className="modal-body">
                <InputField
                  label="Amount (₹)" name="billAmount" type="number" required
                  value={billAmount} onChange={(e) => { setBillAmount(e.target.value); setBillAmountError(''); }}
                  error={billAmountError}
                />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setBillingAppointmentId(null)}>Cancel</button>
                <button
                  className="btn btn-primary"
                  onClick={handleConfirmGenerateBill}
                  disabled={actioningId === billingAppointmentId}
                >
                  {actioningId === billingAppointmentId ? 'Generating...' : 'Generate Bill'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
