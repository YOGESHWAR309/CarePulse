import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import StepIndicator from '../../components/common/StepIndicator';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import {
  searchPatientsByName,
  getActiveDepartments,
  getDoctorsByDepartment,
  getDoctorAvailability,
  getAvailableSlots,
  bookAppointmentForPatient,
} from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const STEPS = ['Patient', 'Department', 'Doctor', 'Date & Slot', 'Confirm'];

/**
 * The Receptionist counterpart to the Patient's own BookAppointmentPage -
 * identical Department -> Doctor -> Availability -> Slot funnel, with one
 * extra step at the front: find (or just-registered) the patient this
 * booking is FOR. Confirms the earlier discussion: a Receptionist can
 * browse the full department-wise doctor directory and availability the
 * exact same way a patient does, then books via
 * POST /api/hospital/receptionist/appointments with an explicit patientId.
 */
export default function ReceptionistBookAppointmentPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const [step, setStep] = useState(location.state?.preSelectedPatient ? 2 : 1);
  const [infoMessage, setInfoMessage] = useState(location.state?.message || '');

  const [searchName, setSearchName] = useState('');
  const [searchNameError, setSearchNameError] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(location.state?.preSelectedPatient || null);

  const [departments, setDepartments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [availabilityBlocks, setAvailabilityBlocks] = useState([]);
  const [slots, setSlots] = useState([]);

  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [reasonError, setReasonError] = useState('');

  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (step === 2 && departments.length === 0) {
      loadDepartments();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const loadDepartments = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getActiveDepartments();
      setDepartments(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load departments');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (event) => {
    event.preventDefault();
    const requiredError = validateRequired(searchName, 'Patient name');
    setSearchNameError(requiredError);
    if (requiredError) return;

    setSearching(true);
    setError('');
    try {
      const res = await searchPatientsByName(searchName);
      setSearchResults(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to search patients');
    } finally {
      setSearching(false);
    }
  };

  const handleSelectPatient = (patient) => {
    setSelectedPatient(patient);
    setInfoMessage('');
    setStep(2);
  };

  const handleSelectDepartment = async (department) => {
    setSelectedDepartment(department);
    setSelectedDoctor(null);
    setLoading(true);
    setError('');
    try {
      const res = await getDoctorsByDepartment(department.id);
      setDoctors(res.data);
      setStep(3);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load doctors');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectDoctor = async (doctor) => {
    setSelectedDoctor(doctor);
    setSelectedDate('');
    setSlots([]);
    setLoading(true);
    setError('');
    try {
      const res = await getDoctorAvailability(doctor.id);
      setAvailabilityBlocks(res.data);
      setStep(4);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load availability');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectDate = async (date) => {
    setSelectedDate(date);
    setSelectedSlot(null);
    setLoading(true);
    setError('');
    try {
      const res = await getAvailableSlots(selectedDoctor.id, date);
      setSlots(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load slots');
    } finally {
      setLoading(false);
    }
  };

  const handleProceedToConfirm = () => {
    if (!selectedSlot) {
      setError('Please select a time slot before continuing');
      return;
    }
    setError('');
    setStep(5);
  };

  const handleConfirmBooking = async () => {
    const validationErrors = runValidators(
      { reasonForVisit },
      { reasonForVisit: (v) => validateMaxLength(v, 'Reason for visit', 500) }
    );
    setReasonError(validationErrors.reasonForVisit || '');
    if (hasErrors(validationErrors)) return;

    setSubmitting(true);
    setError('');
    try {
      await bookAppointmentForPatient({
        patientId: selectedPatient.id,
        doctorId: selectedDoctor.id,
        availabilityId: selectedSlot.availabilityId,
        appointmentDate: selectedDate,
        slotStartTime: selectedSlot.slotStartTime,
        reasonForVisit: reasonForVisit || undefined,
      });
      navigate('/receptionist/queue', { state: { message: 'Appointment booked successfully!' } });
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to book this appointment. Please pick another slot.');
    } finally {
      setSubmitting(false);
    }
  };

  const availableDates = [...new Set(availabilityBlocks.map((b) => b.availableDate))];

  return (
    <div className="container mt-4" style={{ maxWidth: 800 }}>
      <h2 className="mb-4">Book Appointment for Patient</h2>
      <StepIndicator steps={STEPS} currentStep={step} />
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={infoMessage} onClose={() => setInfoMessage('')} />

      <div className="card shadow-sm">
        <div className="card-body p-4">
          {loading && <Loader />}

          {!loading && step === 1 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Find a Patient</h5>
                <Link to="/receptionist/register-patient" className="btn btn-outline-primary btn-sm">
                  + Register New Walk-in
                </Link>
              </div>
              <form onSubmit={handleSearch} className="row g-2 mb-3" noValidate>
                <div className="col-8">
                  <InputField
                    label="" name="searchName" placeholder="Search by patient name..."
                    value={searchName} onChange={(e) => { setSearchName(e.target.value); setSearchNameError(''); }}
                    error={searchNameError}
                  />
                </div>
                <div className="col-4">
                  <button className="btn btn-primary w-100" disabled={searching}>{searching ? 'Searching...' : 'Search'}</button>
                </div>
              </form>

              {searchResults.map((patient) => (
                <button
                  key={patient.id}
                  type="button"
                  className="btn btn-outline-secondary w-100 text-start mb-2"
                  onClick={() => handleSelectPatient(patient)}
                >
                  <strong>{patient.fullName}</strong>
                  <div className="small text-muted">{patient.phoneNumber} {patient.email ? `· ${patient.email}` : ''}</div>
                </button>
              ))}
            </>
          )}

          {!loading && step === 2 && (
            <>
              <div className="alert alert-light border small mb-3">
                Booking for: <strong>{selectedPatient?.fullName}</strong>{' '}
                <button className="btn btn-link btn-sm p-0 ms-2" onClick={() => setStep(1)}>Change patient</button>
              </div>
              <h5 className="mb-3">Select a Department</h5>
              <div className="row g-3">
                {departments.map((dept) => (
                  <div key={dept.id} className="col-md-6">
                    <button type="button" className="btn btn-outline-primary w-100 text-start p-3" onClick={() => handleSelectDepartment(dept)}>
                      <strong>{dept.name}</strong>
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}

          {!loading && step === 3 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Select a Doctor in {selectedDepartment?.name}</h5>
                <button className="btn btn-link btn-sm" onClick={() => setStep(2)}>Change department</button>
              </div>
              <div className="row g-3">
                {doctors.map((doctor) => (
                  <div key={doctor.id} className="col-md-6">
                    <button type="button" className="btn btn-outline-primary w-100 text-start p-3" onClick={() => handleSelectDoctor(doctor)}>
                      <strong>{doctor.fullName}</strong>
                      <div className="small text-muted">{doctor.specialization || 'General'}</div>
                    </button>
                  </div>
                ))}
                {doctors.length === 0 && <p className="text-muted">No doctors in this department.</p>}
              </div>
            </>
          )}

          {!loading && step === 4 && (
            <>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Choose Date & Time with Dr. {selectedDoctor?.fullName}</h5>
                <button className="btn btn-link btn-sm" onClick={() => setStep(3)}>Change doctor</button>
              </div>

              <label className="form-label">Available Dates</label>
              <div className="d-flex flex-wrap gap-2 mb-4">
                {availableDates.map((date) => (
                  <button key={date} type="button" className={`btn btn-sm ${selectedDate === date ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => handleSelectDate(date)}>
                    {date}
                  </button>
                ))}
                {availableDates.length === 0 && <p className="text-muted">No upcoming availability.</p>}
              </div>

              {selectedDate && (
                <>
                  <label className="form-label">Available Slots</label>
                  <div className="d-flex flex-wrap gap-2 mb-4">
                    {slots.map((slot) => (
                      <button
                        key={`${slot.availabilityId}-${slot.slotStartTime}`} type="button" disabled={!slot.bookable}
                        className={`btn btn-sm ${selectedSlot?.slotStartTime === slot.slotStartTime ? 'btn-success' : 'btn-outline-secondary'}`}
                        onClick={() => setSelectedSlot(slot)}
                      >
                        {slot.slotStartTime}
                      </button>
                    ))}
                  </div>
                  <button className="btn btn-primary" onClick={handleProceedToConfirm}>Continue</button>
                </>
              )}
            </>
          )}

          {!loading && step === 5 && (
            <form onSubmit={(e) => { e.preventDefault(); handleConfirmBooking(); }} noValidate>
              <h5 className="mb-3">Confirm Appointment</h5>
              <ul className="list-group mb-3">
                <li className="list-group-item d-flex justify-content-between"><span>Patient</span><strong>{selectedPatient?.fullName}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Doctor</span><strong>{selectedDoctor?.fullName}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Date</span><strong>{selectedDate}</strong></li>
                <li className="list-group-item d-flex justify-content-between"><span>Time</span><strong>{selectedSlot?.slotStartTime}</strong></li>
              </ul>
              <InputField
                label="Reason for Visit (optional)" name="reasonForVisit" as="textarea"
                value={reasonForVisit} onChange={(e) => { setReasonForVisit(e.target.value); setReasonError(''); }}
                error={reasonError}
              />
              <div className="d-flex gap-2">
                <button type="button" className="btn btn-outline-secondary" onClick={() => setStep(4)} disabled={submitting}>Back</button>
                <div className="flex-fill">
                  <SubmitButton loading={submitting} className="btn-success">Confirm & Book</SubmitButton>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
