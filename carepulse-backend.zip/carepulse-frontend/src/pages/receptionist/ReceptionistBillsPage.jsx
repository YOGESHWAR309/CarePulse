import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import { getReceptionistBills, markBillPaidCash } from '../../api/hospitalApi';

const STATUS_BADGE = { PENDING: 'warning', PAID: 'success', FAILED: 'danger', REFUNDED: 'secondary' };

/**
 * [Receptionist] Front-desk billing: every bill in the system, with a
 * "Mark as Paid (Cash)" action for PENDING/FAILED bills - e.g. a walk-in
 * patient who pays in person rather than through the patient portal's
 * Razorpay checkout. This intentionally skips the online-payment machinery
 * entirely: the receptionist physically receiving the cash IS the
 * confirmation, which is why this action is restricted to Receptionist/Admin
 * and never exposed to the patient.
 */
export default function ReceptionistBillsPage() {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [markingBillId, setMarkingBillId] = useState(null);

  useEffect(() => {
    loadBills();
  }, []);

  const loadBills = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getReceptionistBills();
      setBills(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load bills');
    } finally {
      setLoading(false);
    }
  };

  const handleMarkPaidCash = async (bill) => {
    if (!window.confirm(`Confirm you have received ₹${bill.amount} in cash for invoice ${bill.invoiceNumber}?`)) {
      return;
    }
    setMarkingBillId(bill.id);
    setError('');
    setSuccessMessage('');
    try {
      await markBillPaidCash(bill.id);
      setSuccessMessage(`Invoice ${bill.invoiceNumber} marked as paid.`);
      loadBills();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to mark this bill as paid');
    } finally {
      setMarkingBillId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Bills</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : bills.length === 0 ? (
        <div className="alert alert-light border">No bills yet.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle bg-white">
            <thead>
              <tr>
                <th>Invoice #</th><th>Patient</th><th>Amount</th><th>Status</th><th>Paid Via</th><th>Date</th><th></th>
              </tr>
            </thead>
            <tbody>
              {bills.map((bill) => (
                <tr key={bill.id}>
                  <td>{bill.invoiceNumber}</td>
                  <td>{bill.patientName}</td>
                  <td>₹{bill.amount}</td>
                  <td><span className={`badge bg-${STATUS_BADGE[bill.status] || 'secondary'}`}>{bill.status}</span></td>
                  <td>{bill.paymentMethod || '-'}</td>
                  <td>{new Date(bill.createdAt).toLocaleDateString()}</td>
                  <td>
                    {(bill.status === 'PENDING' || bill.status === 'FAILED') && (
                      <button
                        className="btn btn-sm btn-success"
                        disabled={markingBillId === bill.id}
                        onClick={() => handleMarkPaidCash(bill)}
                      >
                        {markingBillId === bill.id ? 'Marking...' : 'Mark as Paid (Cash)'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
