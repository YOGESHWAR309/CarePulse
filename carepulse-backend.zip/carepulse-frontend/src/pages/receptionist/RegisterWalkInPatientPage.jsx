import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import InputField from '../../components/common/InputField';
import { Alert, SubmitButton } from '../../components/common/CommonUI';
import { registerWalkInPatient } from '../../api/hospitalApi';
import { validateName, validatePhone, validateMaxLength, PATTERNS, runValidators, hasErrors } from '../../utils/validators';

const initialValues = {
  fullName: '', email: '', phoneNumber: '', dateOfBirth: '', gender: '', bloodGroup: '', address: '',
};

/** [Receptionist] POST /api/hospital/receptionist/patients - registers a walk-in patient with no Auth Service login. */
export default function RegisterWalkInPatientPage() {
  const navigate = useNavigate();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const validatorMap = {
    fullName: (v) => validateName(v, 'Full name', 200),
    email: (v) => (v ? (PATTERNS.EMAIL.test(v) ? '' : 'Enter a valid email address') : ''),
    phoneNumber: validatePhone,
    bloodGroup: (v) => validateMaxLength(v, 'Blood group', 10),
    address: (v) => validateMaxLength(v, 'Address', 500),
  };

  const validateField = (name, value) => (validatorMap[name] ? validatorMap[name](value) : '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (event) => {
    const { name, value } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');

    const validationErrors = runValidators(values, validatorMap);
    setErrors(validationErrors);
    setTouched({ fullName: true, email: true, phoneNumber: true, bloodGroup: true, address: true });
    if (hasErrors(validationErrors)) return;

    setLoading(true);
    try {
      const res = await registerWalkInPatient({
        ...values,
        email: values.email || undefined,
        dateOfBirth: values.dateOfBirth || undefined,
        gender: values.gender || undefined,
      });
      navigate('/receptionist/book-appointment', {
        state: { message: `${res.data.fullName} registered successfully.`, preSelectedPatient: res.data },
      });
    } catch (err) {
      setServerError(err.response?.data?.message || 'Unable to register patient');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 600 }}>
      <h2 className="mb-4">Register Walk-in Patient</h2>
      <Alert message={serverError} onClose={() => setServerError('')} />

      <div className="card shadow-sm">
        <div className="card-body">
          <form onSubmit={handleSubmit} noValidate>
            <InputField
              label="Full Name" name="fullName" required
              value={values.fullName} onChange={handleChange} onBlur={handleBlur}
              error={touched.fullName && errors.fullName}
            />
            <InputField
              label="Phone Number" name="phoneNumber" type="tel" required
              value={values.phoneNumber} onChange={handleChange} onBlur={handleBlur}
              error={touched.phoneNumber && errors.phoneNumber}
            />
            <InputField
              label="Email (optional)" name="email" type="email"
              value={values.email} onChange={handleChange} onBlur={handleBlur}
              error={touched.email && errors.email}
            />
            <div className="row">
              <div className="col-6">
                <InputField
                  label="Date of Birth" name="dateOfBirth" type="date"
                  value={values.dateOfBirth} onChange={handleChange}
                />
              </div>
              <div className="col-6">
                <InputField
                  label="Gender" name="gender" as="select"
                  value={values.gender} onChange={handleChange}
                >
                  <option value="">Select...</option>
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </InputField>
              </div>
            </div>
            <InputField
              label="Blood Group" name="bloodGroup" placeholder="e.g. O+"
              value={values.bloodGroup} onChange={handleChange} onBlur={handleBlur}
              error={touched.bloodGroup && errors.bloodGroup}
            />
            <InputField
              label="Address" name="address" as="textarea"
              value={values.address} onChange={handleChange} onBlur={handleBlur}
              error={touched.address && errors.address}
            />

            <SubmitButton loading={loading}>Register Patient</SubmitButton>
          </form>
        </div>
      </div>
    </div>
  );
}
