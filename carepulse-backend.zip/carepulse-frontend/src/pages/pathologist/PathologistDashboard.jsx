import React, { useEffect, useState } from 'react';
import { Alert, Loader, SubmitButton } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getRequestedLabTests, collectLabSample, uploadLabReport, markLabReportReady } from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const STATUS_BADGE = { REQUESTED: 'secondary', SAMPLE_COLLECTED: 'info', IN_PROGRESS: 'warning', READY: 'success' };

export default function PathologistDashboard() {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [actioningId, setActioningId] = useState(null);

  const [uploadingId, setUploadingId] = useState(null);
  const [resultSummary, setResultSummary] = useState('');
  const [reportFile, setReportFile] = useState(null);
  const [reportErrors, setReportErrors] = useState({});

  useEffect(() => {
    loadQueue();
  }, []);

  const loadQueue = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getRequestedLabTests();
      setTests(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load lab requests');
    } finally {
      setLoading(false);
    }
  };

  const handleCollectSample = async (id) => {
    setActioningId(id);
    setError('');
    try {
      await collectLabSample(id);
      setSuccessMessage('Sample marked as collected');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to mark sample collected');
    } finally {
      setActioningId(null);
    }
  };

  const openUploadForm = (id) => {
    setUploadingId(id);
    setResultSummary('');
    setReportFile(null);
    setReportErrors({});
  };

  const handleReportFileChange = (event) => {
    const file = event.target.files[0] || null;
    setReportFile(file);
    if (file && file.type !== 'application/pdf') {
      setReportErrors((p) => ({ ...p, reportFile: 'Only PDF files are allowed' }));
    } else {
      setReportErrors((p) => ({ ...p, reportFile: '' }));
    }
  };

  const handleUploadReport = async (event) => {
    event.preventDefault();
    const validationErrors = runValidators(
      { resultSummary },
      { resultSummary: (v) => validateRequired(v, 'Result summary') || validateMaxLength(v, 'Result summary', 2000) }
    );
    if (!reportFile) {
      validationErrors.reportFile = 'A report PDF file is required';
    } else if (reportFile.type !== 'application/pdf') {
      validationErrors.reportFile = 'Only PDF files are allowed';
    }
    setReportErrors(validationErrors);
    if (hasErrors(validationErrors)) return;

    setActioningId(uploadingId);
    setError('');
    try {
      await uploadLabReport(uploadingId, { resultSummary, file: reportFile });
      setSuccessMessage('Report uploaded');
      setUploadingId(null);
      setResultSummary('');
      setReportFile(null);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to upload report');
    } finally {
      setActioningId(null);
    }
  };

  const handleMarkReady = async (id) => {
    setActioningId(id);
    setError('');
    try {
      await markLabReportReady(id);
      setSuccessMessage('Report marked as READY - the patient has been notified');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to mark this report ready');
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Lab Test Requests</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : tests.length === 0 ? (
        <div className="alert alert-light border">No lab requests awaiting pickup.</div>
      ) : (
        tests.map((test) => (
          <div key={test.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <h6 className="mb-0">{test.testName}</h6>
                  <small className="text-muted">Patient: {test.patientName} · Ordered by Dr. {test.requestingDoctorName}</small>
                </div>
                <span className={`badge bg-${STATUS_BADGE[test.status] || 'secondary'}`}>{test.status}</span>
              </div>

              {test.status === 'REQUESTED' && (
                <button className="btn btn-sm btn-primary" disabled={actioningId === test.id} onClick={() => handleCollectSample(test.id)}>
                  Mark Sample Collected
                </button>
              )}

              {test.status === 'SAMPLE_COLLECTED' && uploadingId !== test.id && (
                <button className="btn btn-sm btn-primary" onClick={() => openUploadForm(test.id)}>
                  Upload Report
                </button>
              )}

              {test.status === 'IN_PROGRESS' && !test.reportAvailable && uploadingId !== test.id && (
                <button className="btn btn-sm btn-primary" onClick={() => openUploadForm(test.id)}>
                  Upload Report
                </button>
              )}

              {test.status === 'IN_PROGRESS' && test.reportAvailable && (
                <button className="btn btn-sm btn-success" disabled={actioningId === test.id} onClick={() => handleMarkReady(test.id)}>
                  Mark Report Ready
                </button>
              )}

              {uploadingId === test.id && (
                <form onSubmit={handleUploadReport} noValidate className="mt-2 border-top pt-2">
                  <InputField
                    label="Result Summary" name="resultSummary" as="textarea" required
                    value={resultSummary} onChange={(e) => setResultSummary(e.target.value)}
                    error={reportErrors.resultSummary}
                  />
                  <div className="mb-2">
                    <label className="form-label">Report PDF File <span className="text-danger">*</span></label>
                    <input
                      type="file" accept="application/pdf"
                      className={`form-control ${reportErrors.reportFile ? 'is-invalid' : ''}`}
                      onChange={handleReportFileChange}
                    />
                    {reportErrors.reportFile && <div className="invalid-feedback">{reportErrors.reportFile}</div>}
                  </div>
                  <div className="d-flex gap-2">
                    <div className="flex-fill">
                      <SubmitButton loading={actioningId === test.id}>Save Report</SubmitButton>
                    </div>
                    <button type="button" className="btn btn-outline-secondary" onClick={() => setUploadingId(null)}>Cancel</button>
                  </div>
                </form>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
