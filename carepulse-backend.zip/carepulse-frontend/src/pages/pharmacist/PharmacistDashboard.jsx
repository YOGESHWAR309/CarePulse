import React, { useEffect, useState } from 'react';
import { Alert, Loader } from '../../components/common/CommonUI';
import InputField from '../../components/common/InputField';
import { getPendingPrescriptions, verifyPrescription, dispensePrescription, rejectPrescription } from '../../api/hospitalApi';
import { validateRequired, validateMaxLength, runValidators, hasErrors } from '../../utils/validators';

const STATUS_BADGE = { PENDING: 'warning', VERIFIED: 'info', DISPENSED: 'success', REJECTED: 'danger' };

/**
 * [Pharmacist] "View Prescriptions, Verify Prescription, Dispense
 * Medicines, Update Medicine Status" - one queue covering the full
 * PENDING -> VERIFIED -> DISPENSED (or REJECTED) lifecycle.
 */
export default function PharmacistDashboard() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [actioningId, setActioningId] = useState(null);

  const [rejectingId, setRejectingId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectReasonError, setRejectReasonError] = useState('');

  useEffect(() => {
    loadQueue();
  }, []);

  const loadQueue = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getPendingPrescriptions();
      setPrescriptions(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to load the prescription queue');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (id) => {
    setActioningId(id);
    setError('');
    try {
      await verifyPrescription(id);
      setSuccessMessage('Prescription verified');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to verify this prescription');
    } finally {
      setActioningId(null);
    }
  };

  const handleDispense = async (id) => {
    setActioningId(id);
    setError('');
    try {
      await dispensePrescription(id);
      setSuccessMessage('Medicines marked as dispensed');
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to dispense this prescription');
    } finally {
      setActioningId(null);
    }
  };

  const handleConfirmReject = async () => {
    const validationErrors = runValidators(
      { reason: rejectReason },
      { reason: (v) => validateRequired(v, 'Rejection reason') || validateMaxLength(v, 'Rejection reason', 500) }
    );
    setRejectReasonError(validationErrors.reason || '');
    if (hasErrors(validationErrors)) return;

    setActioningId(rejectingId);
    setError('');
    try {
      await rejectPrescription(rejectingId, { reason: rejectReason });
      setSuccessMessage('Prescription rejected');
      setRejectingId(null);
      loadQueue();
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to reject this prescription');
    } finally {
      setActioningId(null);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Prescription Queue</h2>
      <Alert message={error} onClose={() => setError('')} />
      <Alert type="success" message={successMessage} onClose={() => setSuccessMessage('')} />

      {loading ? (
        <Loader />
      ) : prescriptions.length === 0 ? (
        <div className="alert alert-light border">No pending prescriptions right now.</div>
      ) : (
        prescriptions.map((rx) => (
          <div key={rx.id} className="card shadow-sm mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <h6 className="mb-0">{rx.patientName}</h6>
                  <small className="text-muted">Prescribed by Dr. {rx.doctorName}</small>
                </div>
                <span className={`badge bg-${STATUS_BADGE[rx.status] || 'secondary'}`}>{rx.status}</span>
              </div>

              <table className="table table-sm mb-3">
                <thead><tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th></tr></thead>
                <tbody>
                  {rx.items?.map((item) => (
                    <tr key={item.id}>
                      <td>{item.medicineName}</td><td>{item.dosage}</td><td>{item.frequency}</td><td>{item.durationDays} day(s)</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="d-flex gap-2">
                {rx.status === 'PENDING' && (
                  <>
                    <button className="btn btn-sm btn-success" disabled={actioningId === rx.id} onClick={() => handleVerify(rx.id)}>
                      Verify
                    </button>
                    <button
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => { setRejectingId(rx.id); setRejectReason(''); setRejectReasonError(''); }}
                    >
                      Reject
                    </button>
                  </>
                )}
                {rx.status === 'VERIFIED' && (
                  <button className="btn btn-sm btn-primary" disabled={actioningId === rx.id} onClick={() => handleDispense(rx.id)}>
                    Dispense
                  </button>
                )}
              </div>
            </div>
          </div>
        ))
      )}

      {rejectingId && (
        <div className="modal d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} role="dialog">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Reject Prescription</h5>
                <button type="button" className="btn-close" onClick={() => setRejectingId(null)} />
              </div>
              <div className="modal-body">
                <InputField
                  label="Reason for rejection" name="rejectReason" as="textarea" required
                  value={rejectReason} onChange={(e) => { setRejectReason(e.target.value); setRejectReasonError(''); }}
                  error={rejectReasonError}
                />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setRejectingId(null)}>Cancel</button>
                <button className="btn btn-danger" onClick={handleConfirmReject} disabled={actioningId === rejectingId}>
                  {actioningId === rejectingId ? 'Rejecting...' : 'Confirm Rejection'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
