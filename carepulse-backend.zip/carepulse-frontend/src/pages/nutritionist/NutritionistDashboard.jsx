import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const QUICK_LINKS = [
  { to: '/nutritionist/consultations/today', label: "Today's Consultations", icon: '📅', desc: 'See who\'s booked in today' },
  { to: '/nutritionist/consultations/upcoming', label: 'Upcoming Consultations', icon: '🗓️', desc: 'Plan ahead' },
  { to: '/nutritionist/availability', label: 'Manage Availability', icon: '⏰', desc: 'Publish bookable time slots' },
];

export default function NutritionistDashboard() {
  const { user } = useAuth();
  return (
    <div className="container mt-4">
      <h2 className="mb-1">Welcome, {user?.firstName}!</h2>
      <p className="text-muted mb-4">Nutritionist workspace.</p>
      <div className="row g-3">
        {QUICK_LINKS.map((link) => (
          <div key={link.to} className="col-md-4 col-sm-6">
            <Link to={link.to} className="text-decoration-none">
              <div className="card h-100 shadow-sm">
                <div className="card-body">
                  <div style={{ fontSize: '2rem' }}>{link.icon}</div>
                  <h6 className="mt-2 mb-1 text-dark">{link.label}</h6>
                  <p className="small text-muted mb-0">{link.desc}</p>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
