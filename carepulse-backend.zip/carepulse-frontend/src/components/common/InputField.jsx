import React from 'react';

/**
 * Every form field in this app renders through this component, so error
 * display (red border + message below the field) is 100% consistent and
 * no page has to hand-roll its own "is this field invalid" markup.
 */
export default function InputField({
  label,
  name,
  type = 'text',
  value,
  onChange,
  onBlur,
  error,
  placeholder,
  required = false,
  disabled = false,
  as = 'input',
  children,
}) {
  const controlId = `field-${name}`;

  return (
    <div className="mb-3">
      {label && (
        <label htmlFor={controlId} className="form-label">
          {label} {required && <span className="text-danger">*</span>}
        </label>
      )}

      {as === 'select' ? (
        <select
          id={controlId}
          name={name}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          disabled={disabled}
          className={`form-select ${error ? 'is-invalid' : ''}`}
        >
          {children}
        </select>
      ) : as === 'textarea' ? (
        <textarea
          id={controlId}
          name={name}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          placeholder={placeholder}
          disabled={disabled}
          className={`form-control ${error ? 'is-invalid' : ''}`}
          rows={4}
        />
      ) : (
        <input
          id={controlId}
          name={name}
          type={type}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          placeholder={placeholder}
          disabled={disabled}
          className={`form-control ${error ? 'is-invalid' : ''}`}
          autoComplete={type === 'password' ? 'new-password' : 'on'}
        />
      )}

      {error && <div className="invalid-feedback d-block">{error}</div>}
    </div>
  );
}
