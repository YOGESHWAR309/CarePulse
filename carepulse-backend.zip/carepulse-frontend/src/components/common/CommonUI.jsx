import React from 'react';

export function Alert({ type = 'danger', message, onClose }) {
  if (!message) return null;
  return (
    <div className={`alert alert-${type} alert-dismissible fade show`} role="alert">
      {message}
      {onClose && (
        <button type="button" className="btn-close" aria-label="Close" onClick={onClose} />
      )}
    </div>
  );
}

export function SubmitButton({ children, loading, disabled, className = 'btn-primary' }) {
  return (
    <button type="submit" className={`btn ${className} w-100`} disabled={loading || disabled}>
      {loading ? (
        <>
          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true" />
          Please wait...
        </>
      ) : (
        children
      )}
    </button>
  );
}

export function Loader() {
  return (
    <div className="d-flex justify-content-center align-items-center py-5">
      <div className="spinner-border text-primary" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
    </div>
  );
}
