import React, { useState } from 'react';
import { searchStaffForDoctor } from '../../api/hospitalApi';

/**
 * [Doctor] Inline search-and-select control for picking a specific Radiologist
 * or Pathologist by name, used when ordering a scan / lab test - assignment
 * to a specific staff member is required, so a request can't be submitted
 * without a selection here.
 */
export default function StaffSearchPicker({ role, label, selected, onSelect, onClear }) {
  const [name, setName] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (event) => {
    event?.preventDefault();
    if (!name.trim()) {
      setError('Enter a name to search');
      return;
    }
    setError('');
    setSearching(true);
    try {
      const res = await searchStaffForDoctor(role, name.trim());
      setResults(res.data);
      setSearched(true);
    } catch (err) {
      setError(err.response?.data?.message || `Unable to search ${label.toLowerCase()}s`);
    } finally {
      setSearching(false);
    }
  };

  if (selected) {
    return (
      <div className="border rounded p-2 mb-2 d-flex justify-content-between align-items-center bg-light">
        <div>
          <small className="text-muted d-block">{label}</small>
          <strong>{selected.fullName}</strong>
        </div>
        <button type="button" className="btn btn-sm btn-outline-secondary" onClick={onClear}>
          Change
        </button>
      </div>
    );
  }

  return (
    <div className="border rounded p-2 mb-2">
      <small className="text-muted d-block mb-1">{label} <span className="text-danger">*</span></small>
      <div className="d-flex gap-2 mb-2">
        <input
          type="text"
          className="form-control form-control-sm"
          placeholder={`Search ${label.toLowerCase()} by name...`}
          value={name}
          onChange={(e) => { setName(e.target.value); setError(''); }}
          onKeyDown={(e) => {
            // This control always sits inside another <form> (order lab test /
            // order scan), so Enter must trigger our own search - not bubble up
            // and submit the outer form.
            if (e.key === 'Enter') {
              e.preventDefault();
              e.stopPropagation();
              handleSearch();
            }
          }}
        />
        <button type="button" className="btn btn-sm btn-outline-primary" disabled={searching} onClick={handleSearch}>
          {searching ? 'Searching...' : 'Search'}
        </button>
      </div>

      {error && <div className="text-danger small mb-2">{error}</div>}

      {searched && !searching && (
        results.length === 0 ? (
          <div className="text-muted small">No {label.toLowerCase()}s found matching "{name}".</div>
        ) : (
          <div className="list-group">
            {results.map((staff) => (
              <button
                key={staff.userId}
                type="button"
                className="list-group-item list-group-item-action py-1 px-2 small"
                onClick={() => onSelect(staff)}
              >
                {staff.fullName}
                {staff.departmentName && <span className="text-muted"> · {staff.departmentName}</span>}
              </button>
            ))}
          </div>
        )
      )}
    </div>
  );
}
