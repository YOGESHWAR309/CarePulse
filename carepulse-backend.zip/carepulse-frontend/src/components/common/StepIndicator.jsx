import React from 'react';

/** Simple numbered step indicator reused by both the Doctor and Dietician/Nutritionist booking wizards. */
export default function StepIndicator({ steps, currentStep }) {
  return (
    <div className="d-flex justify-content-between mb-4">
      {steps.map((label, index) => {
        const stepNumber = index + 1;
        const isActive = stepNumber === currentStep;
        const isDone = stepNumber < currentStep;
        return (
          <div key={label} className="text-center flex-fill">
            <div
              className={`mx-auto d-flex align-items-center justify-content-center rounded-circle mb-1 ${
                isDone ? 'bg-success text-white' : isActive ? 'bg-primary text-white' : 'bg-light text-muted border'
              }`}
              style={{ width: 32, height: 32 }}
            >
              {isDone ? '✓' : stepNumber}
            </div>
            <small className={isActive ? 'fw-bold' : 'text-muted'}>{label}</small>
          </div>
        );
      })}
    </div>
  );
}
