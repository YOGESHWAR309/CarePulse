import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { SESSION_ACTIVITY_KEY, SESSION_IDLE_TIMEOUT_MS, SESSION_WARNING_MS } from '../../utils/constants';

const ACTIVITY_EVENTS = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
const ACTIVITY_WRITE_THROTTLE_MS = 5000; // don't hammer localStorage on every mousemove

function readLastActivity() {
  const stored = Number(localStorage.getItem(SESSION_ACTIVITY_KEY));
  return stored && !Number.isNaN(stored) ? stored : Date.now();
}

function formatMmSs(ms) {
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
}

/**
 * Idle-session timer shown top-right in the Navbar. Tracks time since the
 * last user interaction (mouse/keyboard/scroll/touch), warns the user 60s
 * before auto-logout, and logs them out if they don't respond. Activity is
 * stored in localStorage so multiple tabs share one countdown and a logout
 * in one tab is reflected in every other tab.
 */
export default function SessionTimer() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [remainingMs, setRemainingMs] = useState(SESSION_IDLE_TIMEOUT_MS);
  const [showWarning, setShowWarning] = useState(false);

  // Mirrors showWarning so the activity listener (attached once) always sees
  // the current value instead of a stale closure.
  const warningActiveRef = useRef(false);
  const lastWriteRef = useRef(0);

  const recordActivity = useCallback(() => {
    const now = Date.now();
    localStorage.setItem(SESSION_ACTIVITY_KEY, String(now));
    lastWriteRef.current = now;
  }, []);

  const doLogout = useCallback((expired) => {
    logout();
    navigate('/login', expired ? { replace: true, state: { sessionExpired: true } } : { replace: true });
  }, [logout, navigate]);

  const handleActivity = useCallback(() => {
    // Once the warning modal is up, passive activity (a stray mouse move)
    // shouldn't silently dismiss it - the user has to explicitly choose to
    // stay logged in. This matches how banking/health-record apps behave.
    if (warningActiveRef.current) return;

    const now = Date.now();
    if (now - lastWriteRef.current > ACTIVITY_WRITE_THROTTLE_MS) {
      recordActivity();
    }
  }, [recordActivity]);

  const extendSession = () => {
    recordActivity();
    warningActiveRef.current = false;
    setShowWarning(false);
  };

  useEffect(() => {
    if (!user) return undefined;

    if (!localStorage.getItem(SESSION_ACTIVITY_KEY)) {
      recordActivity();
    }

    ACTIVITY_EVENTS.forEach((evt) => window.addEventListener(evt, handleActivity));

    // If another tab clears the activity key (logs out), mirror it here.
    const onStorage = (event) => {
      if (event.key === SESSION_ACTIVITY_KEY && event.newValue === null) {
        doLogout(false);
      }
    };
    window.addEventListener('storage', onStorage);

    const tick = setInterval(() => {
      const remaining = SESSION_IDLE_TIMEOUT_MS - (Date.now() - readLastActivity());

      if (remaining <= 0) {
        doLogout(true);
        return;
      }

      setRemainingMs(remaining);

      const shouldWarn = remaining <= SESSION_WARNING_MS;
      warningActiveRef.current = shouldWarn;
      setShowWarning(shouldWarn);
    }, 1000);

    return () => {
      ACTIVITY_EVENTS.forEach((evt) => window.removeEventListener(evt, handleActivity));
      window.removeEventListener('storage', onStorage);
      clearInterval(tick);
    };
  }, [user, handleActivity, recordActivity, doLogout]);

  if (!user) return null;

  const isLow = remainingMs <= SESSION_WARNING_MS;

  return (
    <>
      <span
        className={`badge ${isLow ? 'bg-danger' : 'bg-light text-primary'} me-3 px-2 py-1`}
        style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 500 }}
        title="Time remaining until you're auto-logged out due to inactivity"
      >
        ⏱ {formatMmSs(remainingMs)}
      </span>

      {showWarning && (
        <div
          className="modal d-block"
          tabIndex="-1"
          role="dialog"
          aria-modal="true"
          style={{ background: 'rgba(0,0,0,0.5)' }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Session About to Expire</h5>
              </div>
              <div className="modal-body">
                <p>
                  You've been inactive for a while. For your security, you'll be logged out in{' '}
                  <strong>{formatMmSs(remainingMs)}</strong>.
                </p>
                <p className="mb-0 text-muted small">Select "Stay Logged In" to continue your session.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-secondary" onClick={() => doLogout(false)}>
                  Log Out Now
                </button>
                <button type="button" className="btn btn-primary" onClick={extendSession}>
                  Stay Logged In
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
