import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import SessionTimer from '../common/SessionTimer';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">CarePulse</Link>

        {user && (
          <div className="d-flex align-items-center ms-auto">
            <SessionTimer />
            <span className="text-white me-3 small">
              {user.firstName} {user.lastName} <span className="badge bg-light text-primary ms-1">{user.role}</span>
            </span>
            <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
              Log Out
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
