import React, { createContext, useContext, useEffect, useState } from 'react';
import { SESSION_ACTIVITY_KEY } from '../utils/constants';

const AuthContext = createContext(null);

/**
 * Single source of truth for "who is logged in" across the whole app.
 * Hydrates from localStorage on first load (so a page refresh doesn't log
 * the user out), and every login/logout flows through this context so
 * every component re-renders consistently.
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const accessToken = localStorage.getItem('accessToken');
    if (storedUser && accessToken) {
      setUser(JSON.parse(storedUser));
    }
    setInitializing(false);
  }, []);

  /** Called right after a successful login/refresh - persists the session and updates context state together. */
  const loginSession = (authResponse) => {
    const sessionUser = {
      userId: authResponse.userId,
      email: authResponse.email,
      firstName: authResponse.firstName,
      lastName: authResponse.lastName,
      role: authResponse.role,
      firstLogin: authResponse.firstLogin,
    };

    localStorage.setItem('accessToken', authResponse.accessToken);
    localStorage.setItem('refreshToken', authResponse.refreshToken);
    localStorage.setItem('user', JSON.stringify(sessionUser));
    localStorage.setItem(SESSION_ACTIVITY_KEY, String(Date.now()));

    setUser(sessionUser);
  };

  const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    localStorage.removeItem(SESSION_ACTIVITY_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, initializing, loginSession, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
