/**
 * Formats a backend time string ("HH:mm" or "HH:mm:ss", 24-hour) into a
 * 12-hour clock with AM/PM, e.g. "11:30:00" -> "11:30 AM", "17:00:00" -> "5:00 PM".
 * Returns the original input unchanged if it isn't a recognizable time string,
 * so this is always safe to wrap around any value.
 */
export function formatTime12h(time) {
  if (!time || typeof time !== 'string') return time;

  const match = time.match(/^(\d{1,2}):(\d{2})/);
  if (!match) return time;

  const hour24 = parseInt(match[1], 10);
  const minute = match[2];
  const period = hour24 >= 12 ? 'PM' : 'AM';
  const hour12 = hour24 % 12 === 0 ? 12 : hour24 % 12;

  return `${hour12}:${minute} ${period}`;
}
