/**
 * Every validation rule here is a client-side mirror of a backend
 * @Valid/@Pattern/@Size annotation (see PatientRegisterRequest,
 * CreateStaffRequest, ChangePasswordRequest, etc. in Auth Service and
 * Hospital Service). Keeping the SAME regexes/limits on both sides means
 * the user sees an error instantly instead of round-tripping to the
 * server just to be told "password too weak" - but the backend remains
 * the source of truth and re-validates everything regardless.
 */

export const PATTERNS = {
  // Matches PatientRegisterRequest/CreateStaffRequest's @Email validation intent.
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  // Mirrors backend: min 8 chars, at least one lowercase, one uppercase, one digit, one special char.
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/,
  // Mirrors backend: optional leading +, 10-15 digits.
  PHONE: /^[+]?[0-9]{10,15}$/,
  // Mirrors VerifyOtpRequest: exactly 6 digits.
  OTP: /^[0-9]{6}$/,
};

/** Returns an error string, or '' if valid. Every validator follows this same contract for easy composition in forms. */
export function validateRequired(value, fieldLabel) {
  if (value === undefined || value === null || String(value).trim() === '') {
    return `${fieldLabel} is required`;
  }
  return '';
}

export function validateEmail(value) {
  const requiredError = validateRequired(value, 'Email');
  if (requiredError) return requiredError;
  if (!PATTERNS.EMAIL.test(value)) return 'Enter a valid email address';
  return '';
}

/** Mirrors PatientRegisterRequest.password / ResetPasswordRequest.newPassword / ChangePasswordRequest.newPassword exactly. */
export function validatePassword(value) {
  const requiredError = validateRequired(value, 'Password');
  if (requiredError) return requiredError;
  if (value.length < 8) return 'Password must be at least 8 characters long';
  if (!PATTERNS.PASSWORD.test(value)) {
    return 'Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character (@$!%*?&)';
  }
  return '';
}

export function validateConfirmPassword(password, confirmPassword) {
  const requiredError = validateRequired(confirmPassword, 'Confirm password');
  if (requiredError) return requiredError;
  if (password !== confirmPassword) return 'Passwords do not match';
  return '';
}

export function validatePhone(value) {
  const requiredError = validateRequired(value, 'Phone number');
  if (requiredError) return requiredError;
  if (!PATTERNS.PHONE.test(value)) return 'Enter a valid 10-15 digit phone number';
  return '';
}

export function validateOtp(value) {
  const requiredError = validateRequired(value, 'OTP');
  if (requiredError) return requiredError;
  if (!PATTERNS.OTP.test(value)) return 'OTP must be exactly 6 digits';
  return '';
}

/** Generic max-length check mirroring @Size(max=...) annotations sprinkled across every backend DTO. */
export function validateMaxLength(value, fieldLabel, max) {
  if (value && value.length > max) {
    return `${fieldLabel} must not exceed ${max} characters`;
  }
  return '';
}

export function validateName(value, fieldLabel, max = 100) {
  const requiredError = validateRequired(value, fieldLabel);
  if (requiredError) return requiredError;
  return validateMaxLength(value, fieldLabel, max);
}

/** Mirrors CreateAvailabilityRequest/BookAppointmentRequest's @FutureOrPresent - date cannot be in the past. */
export function validateFutureOrPresentDate(value, fieldLabel) {
  const requiredError = validateRequired(value, fieldLabel);
  if (requiredError) return requiredError;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const picked = new Date(value);
  if (picked < today) return `${fieldLabel} cannot be in the past`;
  return '';
}

/** Mirrors backend @Min constraints (e.g. slotDurationMinutes >= 5, maximumPatients >= 1, durationDays >= 1). */
export function validateMinNumber(value, fieldLabel, min) {
  const requiredError = validateRequired(value, fieldLabel);
  if (requiredError) return requiredError;
  const num = Number(value);
  if (Number.isNaN(num)) return `${fieldLabel} must be a number`;
  if (num < min) return `${fieldLabel} must be at least ${min}`;
  return '';
}

/** Mirrors GenerateBillRequest's @DecimalMin("0.01") - amount must be positive. */
export function validatePositiveAmount(value, fieldLabel = 'Amount') {
  const requiredError = validateRequired(value, fieldLabel);
  if (requiredError) return requiredError;
  const num = Number(value);
  if (Number.isNaN(num)) return `${fieldLabel} must be a number`;
  if (num <= 0) return `${fieldLabel} must be greater than zero`;
  return '';
}

/**
 * Runs a map of { fieldName: validatorFn } against a values object and
 * returns { fieldName: errorMessage } for every field that failed - the
 * shared engine every form in this app uses instead of hand-rolling
 * validation logic per page.
 */
export function runValidators(values, validatorMap) {
  const errors = {};
  Object.entries(validatorMap).forEach(([field, validatorFn]) => {
    const error = validatorFn(values[field]);
    if (error) errors[field] = error;
  });
  return errors;
}

export function hasErrors(errors) {
  return Object.keys(errors).length > 0;
}
