/** Mirrors com.carepulse.auth.enums.UserRole exactly. */
export const ROLES = {
  ADMIN: 'ADMIN',
  PATIENT: 'PATIENT',
  DOCTOR: 'DOCTOR',
  RECEPTIONIST: 'RECEPTIONIST',
  PHARMACIST: 'PHARMACIST',
  PATHOLOGIST: 'PATHOLOGIST',
  RADIOLOGIST: 'RADIOLOGIST',
  DIETICIAN: 'DIETICIAN',
  NUTRITIONIST: 'NUTRITIONIST',
};

/** Roles Admin can create via CreateStaffRequest - excludes ADMIN and PATIENT. */
export const STAFF_ROLES = [
  ROLES.DOCTOR,
  ROLES.RECEPTIONIST,
  ROLES.PHARMACIST,
  ROLES.PATHOLOGIST,
  ROLES.RADIOLOGIST,
  ROLES.DIETICIAN,
  ROLES.NUTRITIONIST,
];

/** Mirrors com.carepulse.hospital.enums.ConsultationMode. */
export const CONSULTATION_MODES = ['IN_PERSON', 'ONLINE'];

/** Mirrors com.carepulse.auth.enums.OtpPurpose. */
export const OTP_PURPOSE = {
  REGISTRATION: 'REGISTRATION',
  PASSWORD_RESET: 'PASSWORD_RESET',
};

/** Session idle-timeout config, used by SessionTimer. Auto-logs the user out
 *  after this many ms of no mouse/keyboard/scroll/touch activity, warning
 *  them shortly before it happens. */
export const SESSION_IDLE_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes
export const SESSION_WARNING_MS = 60 * 1000; // show the warning modal in the last 60s
export const SESSION_ACTIVITY_KEY = 'cp_last_activity'; // localStorage key, shared across tabs

/** Where each role lands after login - matches the route definitions in AppRoutes.jsx. */
export const ROLE_HOME_ROUTE = {
  [ROLES.ADMIN]: '/admin/dashboard',
  [ROLES.PATIENT]: '/patient/dashboard',
  [ROLES.DOCTOR]: '/doctor/dashboard',
  [ROLES.RECEPTIONIST]: '/receptionist/dashboard',
  [ROLES.PHARMACIST]: '/pharmacist/dashboard',
  [ROLES.PATHOLOGIST]: '/pathologist/dashboard',
  [ROLES.RADIOLOGIST]: '/radiologist/dashboard',
  [ROLES.DIETICIAN]: '/dietician/dashboard',
  [ROLES.NUTRITIONIST]: '/nutritionist/dashboard',
};
