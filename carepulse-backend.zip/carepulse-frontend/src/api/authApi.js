import axiosInstance from './axiosInstance';

/**
 * One function per Auth Service endpoint (see AuthController/ProfileController/
 * AdminUserController in carepulse-auth-service). Every function returns
 * the Axios response's `.data` (the ApiResponse<T> envelope) directly, so
 * callers destructure `{ data, message, success }` uniformly.
 */

export const registerPatient = (payload) =>
  axiosInstance.post('/api/auth/register', payload).then((res) => res.data);

export const login = (payload) =>
  axiosInstance.post('/api/auth/login', payload).then((res) => res.data);

export const refreshToken = (payload) =>
  axiosInstance.post('/api/auth/refresh-token', payload).then((res) => res.data);

export const forgotPassword = (payload) =>
  axiosInstance.post('/api/auth/forgot-password', payload).then((res) => res.data);

export const verifyOtp = (payload) =>
  axiosInstance.post('/api/auth/verify-otp', payload).then((res) => res.data);

export const resendOtp = (payload) =>
  axiosInstance.post('/api/auth/resend-otp', payload).then((res) => res.data);

export const resetPassword = (payload) =>
  axiosInstance.post('/api/auth/reset-password', payload).then((res) => res.data);

export const changePassword = (payload) =>
  axiosInstance.post('/api/auth/change-password', payload).then((res) => res.data);

export const getMyProfile = () =>
  axiosInstance.get('/api/auth/profile').then((res) => res.data);

export const updateMyProfile = (payload) =>
  axiosInstance.put('/api/auth/profile', payload).then((res) => res.data);

// ---------- Admin-only ----------

export const createStaff = (payload) =>
  axiosInstance.post('/api/auth/admin/staff', payload).then((res) => res.data);

export const activateUser = (userId) =>
  axiosInstance.patch(`/api/auth/admin/users/${userId}/activate`).then((res) => res.data);

export const deactivateUser = (userId) =>
  axiosInstance.patch(`/api/auth/admin/users/${userId}/deactivate`).then((res) => res.data);

export const resetStaffPassword = (userId) =>
  axiosInstance.post(`/api/auth/admin/users/${userId}/reset-password`).then((res) => res.data);

export const getAllPatients = () =>
  axiosInstance.get('/api/auth/admin/patients').then((res) => res.data);

export const getAllDoctors = () =>
  axiosInstance.get('/api/auth/admin/doctors').then((res) => res.data);

export const getAllStaff = () =>
  axiosInstance.get('/api/auth/admin/staff').then((res) => res.data);

export const getUserById = (userId) =>
  axiosInstance.get(`/api/auth/admin/users/${userId}`).then((res) => res.data);
