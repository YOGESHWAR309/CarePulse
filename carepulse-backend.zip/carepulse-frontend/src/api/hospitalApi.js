import axiosInstance from './axiosInstance';

/**
 * One function per Hospital Service endpoint this frontend calls. Grouped
 * by module to mirror the backend's controller layout exactly, so finding
 * "which function calls which endpoint" is always a 1:1 lookup.
 */

// ---------- Departments ----------

export const getActiveDepartments = () =>
  axiosInstance.get('/api/hospital/departments').then((res) => res.data);

export const getDepartmentById = (departmentId) =>
  axiosInstance.get(`/api/hospital/departments/${departmentId}`).then((res) => res.data);

// ---------- Doctors ----------

export const getDoctorsByDepartment = (departmentId) =>
  axiosInstance.get(`/api/hospital/departments/${departmentId}/doctors`).then((res) => res.data);

export const getDoctorById = (doctorId) =>
  axiosInstance.get(`/api/hospital/doctors/${doctorId}`).then((res) => res.data);

// ---------- Doctor Availability ----------

export const getDoctorAvailability = (doctorId) =>
  axiosInstance.get(`/api/hospital/doctors/${doctorId}/availability`).then((res) => res.data);

export const getAvailableSlots = (doctorId, date) =>
  axiosInstance
    .get(`/api/hospital/doctors/${doctorId}/availability/slots`, { params: { date } })
    .then((res) => res.data);

// ---------- Appointments (Patient) ----------

export const bookAppointment = (payload) =>
  axiosInstance.post('/api/hospital/patients/me/appointments', payload).then((res) => res.data);

export const getMyAppointments = () =>
  axiosInstance.get('/api/hospital/patients/me/appointments').then((res) => res.data);

export const rescheduleAppointment = (appointmentId, payload) =>
  axiosInstance.put(`/api/hospital/appointments/${appointmentId}/reschedule`, payload).then((res) => res.data);

export const cancelAppointment = (appointmentId, payload) =>
  axiosInstance.put(`/api/hospital/appointments/${appointmentId}/cancel`, payload).then((res) => res.data);

export const getAppointmentById = (appointmentId) =>
  axiosInstance.get(`/api/hospital/appointments/${appointmentId}`).then((res) => res.data);

// ---------- Patient Profile ----------

export const getMyPatientProfile = () =>
  axiosInstance.get('/api/hospital/patients/me').then((res) => res.data);

export const updateMyPatientProfile = (payload) =>
  axiosInstance.put('/api/hospital/patients/me', payload).then((res) => res.data);

// ---------- Medical Records / Prescriptions / Reports (Patient read-only) ----------

export const getMyMedicalRecords = () =>
  axiosInstance.get('/api/hospital/patients/me/medical-records').then((res) => res.data);

export const getMyPrescriptions = () =>
  axiosInstance.get('/api/hospital/patients/me/prescriptions').then((res) => res.data);

export const getMyLabTests = () =>
  axiosInstance.get('/api/hospital/patients/me/lab-tests').then((res) => res.data);

export const getMyRadiologyRequests = () =>
  axiosInstance.get('/api/hospital/patients/me/radiology').then((res) => res.data);

export const getMyDietPlans = () =>
  axiosInstance.get('/api/hospital/patients/me/diet-plans').then((res) => res.data);

export const getMyNutritionPlans = () =>
  axiosInstance.get('/api/hospital/patients/me/nutrition-plans').then((res) => res.data);

export const getMyBills = () =>
  axiosInstance.get('/api/hospital/patients/me/bills').then((res) => res.data);

// ---------- Billing / Razorpay ----------

export const createPaymentOrder = (billId) =>
  axiosInstance.post(`/api/hospital/billing/bills/${billId}/payment-order`).then((res) => res.data);

export const verifyPayment = (billId, payload) =>
  axiosInstance.post(`/api/hospital/billing/bills/${billId}/verify-payment`, payload).then((res) => res.data);

export const markPaymentFailed = (billId) =>
  axiosInstance.put(`/api/hospital/billing/bills/${billId}/payment-failed`).then((res) => res.data);

// ---------- Dietician/Nutritionist Consultation Booking (Patient) ----------

export const getBookableStaff = (role) =>
  axiosInstance.get('/api/hospital/staff', { params: { role } }).then((res) => res.data);

export const getStaffAvailability = (staffProfileId) =>
  axiosInstance.get(`/api/hospital/staff/${staffProfileId}/availability`).then((res) => res.data);

export const getStaffAvailableSlots = (staffProfileId, date) =>
  axiosInstance
    .get(`/api/hospital/staff/${staffProfileId}/availability/slots`, { params: { date } })
    .then((res) => res.data);

export const bookConsultation = (payload) =>
  axiosInstance.post('/api/hospital/patients/me/consultations', payload).then((res) => res.data);

export const getMyConsultations = () =>
  axiosInstance.get('/api/hospital/patients/me/consultations').then((res) => res.data);

export const cancelConsultation = (appointmentId, payload) =>
  axiosInstance.put(`/api/hospital/consultations/${appointmentId}/cancel`, payload).then((res) => res.data);

// ---------- Doctor: Profile ----------

export const getMyDoctorProfile = () =>
  axiosInstance.get('/api/hospital/doctors/me').then((res) => res.data);

// ---------- Doctor: Availability ----------

export const createAvailability = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/availability', payload).then((res) => res.data);

export const createBulkAvailability = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/availability/bulk', payload).then((res) => res.data);

export const updateAvailability = (availabilityId, payload) =>
  axiosInstance.put(`/api/hospital/doctors/me/availability/${availabilityId}`, payload).then((res) => res.data);

export const updateAvailabilityStatus = (availabilityId, status) =>
  axiosInstance.patch(`/api/hospital/doctors/me/availability/${availabilityId}/status`, { status }).then((res) => res.data);

export const deleteAvailability = (availabilityId) =>
  axiosInstance.delete(`/api/hospital/doctors/me/availability/${availabilityId}`).then((res) => res.data);

export const getMyAvailability = () =>
  axiosInstance.get('/api/hospital/doctors/me/availability').then((res) => res.data);

// ---------- Doctor: Appointments ----------

export const getDoctorTodayAppointments = () =>
  axiosInstance.get('/api/hospital/doctors/me/appointments/today').then((res) => res.data);

export const getDoctorUpcomingAppointments = () =>
  axiosInstance.get('/api/hospital/doctors/me/appointments/upcoming').then((res) => res.data);

export const completeConsultation = (appointmentId) =>
  axiosInstance.put(`/api/hospital/doctors/me/appointments/${appointmentId}/complete`).then((res) => res.data);

// ---------- Doctor: Medical Records ----------

export const createMedicalRecord = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/medical-records', payload).then((res) => res.data);

export const updateMedicalRecord = (medicalRecordId, payload) =>
  axiosInstance.put(`/api/hospital/doctors/me/medical-records/${medicalRecordId}`, payload).then((res) => res.data);

export const getPatientMedicalRecords = (patientId) =>
  axiosInstance.get(`/api/hospital/patients/${patientId}/medical-records`).then((res) => res.data);

export const getMedicalRecordById = (medicalRecordId) =>
  axiosInstance.get(`/api/hospital/medical-records/${medicalRecordId}`).then((res) => res.data);

export const getMedicalRecordByAppointmentId = (appointmentId) =>
  axiosInstance.get(`/api/hospital/appointments/${appointmentId}/medical-record`).then((res) => res.data);

// ---------- Doctor: Prescriptions ----------

export const createPrescription = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/prescriptions', payload).then((res) => res.data);

// ---------- Doctor: Lab Tests / Radiology Orders ----------

export const createLabTestRequest = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/lab-tests', payload).then((res) => res.data);

export const createRadiologyRequest = (payload) =>
  axiosInstance.post('/api/hospital/doctors/me/radiology', payload).then((res) => res.data);

// ---------- Patient lookup (used by Doctor/Receptionist for context) ----------

export const getPatientById = (patientId) =>
  axiosInstance.get(`/api/hospital/patients/${patientId}`).then((res) => res.data);

export const searchPatientsByNameForDoctor = (name) =>
  axiosInstance.get('/api/hospital/doctors/me/patients/search', { params: { name } }).then((res) => res.data);

/** [Doctor] Search Radiologist/Pathologist staff by name, to pick who a scan/lab test request is assigned to. */
export const searchStaffForDoctor = (role, name) =>
  axiosInstance.get('/api/hospital/doctors/me/staff/search', { params: { role, name } }).then((res) => res.data);

// ---------- Admin: Departments ----------

export const getAllDepartments = () =>
  axiosInstance.get('/api/hospital/admin/departments').then((res) => res.data);

export const createDepartment = (payload) =>
  axiosInstance.post('/api/hospital/admin/departments', payload).then((res) => res.data);

export const updateDepartment = (departmentId, payload) =>
  axiosInstance.put(`/api/hospital/admin/departments/${departmentId}`, payload).then((res) => res.data);

export const deactivateDepartment = (departmentId) =>
  axiosInstance.delete(`/api/hospital/admin/departments/${departmentId}`).then((res) => res.data);

// ---------- Admin: Doctors (clinical fields - identity fields live in Auth Service) ----------

export const getAllDoctorsHospital = () =>
  axiosInstance.get('/api/hospital/admin/doctors').then((res) => res.data);

export const updateDoctorProfile = (doctorId, payload) =>
  axiosInstance.put(`/api/hospital/admin/doctors/${doctorId}`, payload).then((res) => res.data);

// ---------- Admin: Non-Doctor Staff Profiles ----------

export const getStaffProfiles = (role) =>
  axiosInstance.get('/api/hospital/admin/staff', { params: role ? { role } : {} }).then((res) => res.data);

export const updateStaffProfile = (staffProfileId, payload) =>
  axiosInstance.put(`/api/hospital/admin/staff/${staffProfileId}`, payload).then((res) => res.data);

// ---------- Admin: Patients ----------

export const getAllPatientsHospital = () =>
  axiosInstance.get('/api/hospital/admin/patients').then((res) => res.data);

// ---------- Admin: Billing ----------

export const getAllBills = () =>
  axiosInstance.get('/api/hospital/admin/bills').then((res) => res.data);

export const generateBill = (payload) =>
  axiosInstance.post('/api/hospital/billing/bills', payload).then((res) => res.data);

// ---------- Receptionist: Billing ----------

export const getReceptionistBills = () =>
  axiosInstance.get('/api/hospital/receptionist/bills').then((res) => res.data);

export const markBillPaidCash = (billId) =>
  axiosInstance.put(`/api/hospital/billing/bills/${billId}/mark-paid-cash`).then((res) => res.data);

// ---------- Receptionist ----------

export const registerWalkInPatient = (payload) =>
  axiosInstance.post('/api/hospital/receptionist/patients', payload).then((res) => res.data);

export const searchPatientsByName = (name) =>
  axiosInstance.get('/api/hospital/receptionist/patients/search', { params: { name } }).then((res) => res.data);

export const bookAppointmentForPatient = (payload) =>
  axiosInstance.post('/api/hospital/receptionist/appointments', payload).then((res) => res.data);

export const receptionistCheckIn = (appointmentId) =>
  axiosInstance.put(`/api/hospital/receptionist/appointments/${appointmentId}/check-in`).then((res) => res.data);

export const receptionistCheckOut = (appointmentId) =>
  axiosInstance.put(`/api/hospital/receptionist/appointments/${appointmentId}/check-out`).then((res) => res.data);

export const getAppointmentQueue = (date) =>
  axiosInstance.get('/api/hospital/receptionist/appointments/queue', { params: { date } }).then((res) => res.data);

export const receptionistRescheduleAppointment = (appointmentId, payload) =>
  axiosInstance.put(`/api/hospital/appointments/${appointmentId}/reschedule`, payload).then((res) => res.data);

export const receptionistCancelAppointment = (appointmentId, payload) =>
  axiosInstance.put(`/api/hospital/appointments/${appointmentId}/cancel`, payload).then((res) => res.data);

// ---------- Pharmacist ----------

export const getPendingPrescriptions = () =>
  axiosInstance.get('/api/hospital/pharmacy/prescriptions/pending').then((res) => res.data);

export const verifyPrescription = (prescriptionId) =>
  axiosInstance.put(`/api/hospital/pharmacy/prescriptions/${prescriptionId}/verify`).then((res) => res.data);

export const dispensePrescription = (prescriptionId) =>
  axiosInstance.put(`/api/hospital/pharmacy/prescriptions/${prescriptionId}/dispense`).then((res) => res.data);

export const rejectPrescription = (prescriptionId, payload) =>
  axiosInstance.put(`/api/hospital/pharmacy/prescriptions/${prescriptionId}/reject`, payload).then((res) => res.data);

// ---------- Pathologist ----------

export const getRequestedLabTests = () =>
  axiosInstance.get('/api/hospital/pathology/lab-tests/requested').then((res) => res.data);

export const collectLabSample = (labTestId) =>
  axiosInstance.put(`/api/hospital/pathology/lab-tests/${labTestId}/collect-sample`).then((res) => res.data);

export const uploadLabReport = (labTestId, { resultSummary, file }) => {
  const formData = new FormData();
  formData.append('resultSummary', resultSummary);
  formData.append('file', file);
  return axiosInstance
    .put(`/api/hospital/pathology/lab-tests/${labTestId}/report`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    .then((res) => res.data);
};

export const markLabReportReady = (labTestId) =>
  axiosInstance.put(`/api/hospital/pathology/lab-tests/${labTestId}/mark-ready`).then((res) => res.data);

/** Downloads the lab report PDF as a Blob (auth header attached automatically). Access is limited server-side to the assigned pathologist, ordering doctor, or owning patient. */
export const getLabReportFile = (labTestId) =>
  axiosInstance.get(`/api/hospital/lab-tests/${labTestId}/report/file`, { responseType: 'blob' }).then((res) => res.data);

// ---------- Radiologist ----------

export const getRequestedScans = () =>
  axiosInstance.get('/api/hospital/radiology/scans/requested').then((res) => res.data);

export const uploadScanImages = (radiologyId, payload) =>
  axiosInstance.put(`/api/hospital/radiology/scans/${radiologyId}/images`, payload).then((res) => res.data);

export const uploadRadiologyReport = (radiologyId, { resultSummary, file }) => {
  const formData = new FormData();
  formData.append('resultSummary', resultSummary);
  formData.append('file', file);
  return axiosInstance
    .put(`/api/hospital/radiology/scans/${radiologyId}/report`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    .then((res) => res.data);
};

export const markRadiologyReportReady = (radiologyId) =>
  axiosInstance.put(`/api/hospital/radiology/scans/${radiologyId}/mark-ready`).then((res) => res.data);

/** Downloads the radiology report PDF as a Blob (auth header attached automatically). Access is limited server-side to the assigned radiologist, ordering doctor, or owning patient. */
export const getRadiologyReportFile = (radiologyId) =>
  axiosInstance.get(`/api/hospital/radiology-requests/${radiologyId}/report/file`, { responseType: 'blob' }).then((res) => res.data);

// ---------- Dietician / Nutritionist: my own profile + availability + consultations ----------

export const getMyStaffAvailability = () =>
  axiosInstance.get('/api/hospital/staff/me/availability').then((res) => res.data);

export const createStaffAvailability = (payload) =>
  axiosInstance.post('/api/hospital/staff/me/availability', payload).then((res) => res.data);

export const createBulkStaffAvailability = (payload) =>
  axiosInstance.post('/api/hospital/staff/me/availability/bulk', payload).then((res) => res.data);

export const updateStaffAvailability = (availabilityId, payload) =>
  axiosInstance.put(`/api/hospital/staff/me/availability/${availabilityId}`, payload).then((res) => res.data);

export const updateStaffAvailabilityStatus = (availabilityId, status) =>
  axiosInstance.patch(`/api/hospital/staff/me/availability/${availabilityId}/status`, { status }).then((res) => res.data);

export const deleteStaffAvailability = (availabilityId) =>
  axiosInstance.delete(`/api/hospital/staff/me/availability/${availabilityId}`).then((res) => res.data);

export const getStaffTodayConsultations = () =>
  axiosInstance.get('/api/hospital/staff/me/consultations/today').then((res) => res.data);

export const getStaffUpcomingConsultations = () =>
  axiosInstance.get('/api/hospital/staff/me/consultations/upcoming').then((res) => res.data);

export const completeStaffConsultation = (appointmentId) =>
  axiosInstance.put(`/api/hospital/staff/me/consultations/${appointmentId}/complete`).then((res) => res.data);

// ---------- Dietician: Diet Plans ----------

export const createDietPlan = (payload) =>
  axiosInstance.post('/api/hospital/diet-plans', payload).then((res) => res.data);

export const updateDietPlan = (dietPlanId, payload) =>
  axiosInstance.put(`/api/hospital/diet-plans/${dietPlanId}`, payload).then((res) => res.data);

export const getPatientDietPlans = (patientId) =>
  axiosInstance.get(`/api/hospital/patients/${patientId}/diet-plans`).then((res) => res.data);

// ---------- Nutritionist: Nutrition Plans ----------

export const createNutritionPlan = (payload) =>
  axiosInstance.post('/api/hospital/nutrition-plans', payload).then((res) => res.data);

export const updateNutritionPlan = (nutritionPlanId, payload) =>
  axiosInstance.put(`/api/hospital/nutrition-plans/${nutritionPlanId}`, payload).then((res) => res.data);

export const getPatientNutritionPlans = (patientId) =>
  axiosInstance.get(`/api/hospital/patients/${patientId}/nutrition-plans`).then((res) => res.data);
